package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey
    var id: String = "",
    var action: String = "",
    var performedByName: String = "",
    var performedById: String = "",
    var performedByEmail: String = "",
    var targetId: String = "",
    var details: String = "",
    var timestamp: Long = System.currentTimeMillis()
)
