package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "news_articles")
data class NewsArticle(
    @PrimaryKey
    var id: String = "",
    var title: String = "",
    var content: String = "",
    var category: String = "",
    var authorName: String = "",
    var reporterId: String = "",
    var mediaOutlet: String = "",
    var division: String = "",
    var district: String = "",
    var upazila: String = "",
    var imageUrl: String = "",
    var videoUrl: String = "",
    var status: String = STATUS_PENDING,
    var aiReviewReport: String = "",
    var timestamp: Long = System.currentTimeMillis(),
    var isVerified: Boolean = false
) {
    companion object {
        const val STATUS_PENDING = "অপেক্ষমাণ"
        const val STATUS_APPROVED = "অনুমোদিত"
        const val STATUS_REJECTED = "প্রত্যাখ্যাত"
    }
}
