package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "district_admin_seats")
data class DistrictAdminSeat(
    @PrimaryKey
    var districtId: String = "",         // e.g. "dhaka", "patuakhali"
    var seatNumber: Int = 0,             // 1 to 64
    var districtNameBn: String = "",     // e.g. "ঢাকা", "পটুয়াখালী"
    var divisionBn: String = "",         // e.g. "ঢাকা", "বরিশাল"
    var adminId: String = "",            // e.g. "BSN 002" or appointed member's ID
    var adminName: String = "",          // Name of appointed District Admin
    var adminPhone: String = "",         // Phone of appointed District Admin
    var adminEmail: String = "",         // Email of appointed District Admin
    var status: String = STATUS_VACANT,  // "Vacant", "Assigned", "Suspended"
    var appointedTimestamp: Long = 0L,
    var appointedBy: String = "BSN 001",
    var suspensionReason: String = "",
    var notes: String = ""
) {
    companion object {
        const val STATUS_VACANT = "Vacant"
        const val STATUS_ASSIGNED = "Assigned"
        const val STATUS_SUSPENDED = "Suspended"

        // The complete 64 districts of Bangladesh
        val ALL_64_DISTRICTS: List<DistrictAdminSeat> by lazy {
            val list = mutableListOf<DistrictAdminSeat>()
            var counter = 1

            // 1. Dhaka Division (13)
            val dhakaDistricts = listOf(
                "ঢাকা" to "dhaka", "গাজীপুর" to "gazipur", "নারায়ণগঞ্জ" to "narayanganj",
                "টাঙ্গাইল" to "tangail", "নরসিংদী" to "narsingdi", "মুন্সীগঞ্জ" to "munshiganj",
                "মানিকগঞ্জ" to "manikganj", "ফরিদপুর" to "faridpur", "মাদারীপুর" to "madaripur",
                "গোপালগঞ্জ" to "gopalganj", "রাজবাড়ী" to "rajbari", "শরীয়তপুর" to "shariatpur",
                "কিশোরগঞ্জ" to "kishoreganj"
            )
            for ((bn, id) in dhakaDistricts) {
                list.add(DistrictAdminSeat(districtId = id, seatNumber = counter++, districtNameBn = bn, divisionBn = "ঢাকা"))
            }

            // 2. Chattogram Division (11)
            val ctgDistricts = listOf(
                "চট্টগ্রাম" to "chattogram", "কক্সবাজার" to "coxsbazar", "কুমিল্লা" to "cumilla",
                "ফেনী" to "feni", "ব্রাহ্মণবাড়িয়া" to "brahmanbaria", "নোয়াখালী" to "noakhali",
                "চাঁদপুর" to "chandpur", "লক্ষ্মীপুর" to "lakshmipur", "রাঙ্গামাটি" to "rangamati",
                "খাগড়াছড়ি" to "khagrachhari", "বান্দরবান" to "bandarban"
            )
            for ((bn, id) in ctgDistricts) {
                list.add(DistrictAdminSeat(districtId = id, seatNumber = counter++, districtNameBn = bn, divisionBn = "চট্টগ্রাম"))
            }

            // 3. Rajshahi Division (8)
            val rajshahiDistricts = listOf(
                "রাজশাহী" to "rajshahi", "বগুড়া" to "bogura", "পাবনা" to "pabna",
                "সিরাজগঞ্জ" to "sirajganj", "নওগাঁ" to "naogaon", "নাটোর" to "natore",
                "চাঁপাইনবাবগঞ্জ" to "chapainawabganj", "জয়পুরহাট" to "joypurhat"
            )
            for ((bn, id) in rajshahiDistricts) {
                list.add(DistrictAdminSeat(districtId = id, seatNumber = counter++, districtNameBn = bn, divisionBn = "রাজশাহী"))
            }

            // 4. Khulna Division (10)
            val khulnaDistricts = listOf(
                "খুলনা" to "khulna", "যশোর" to "jashore", "বাগেরহাট" to "bagerhat",
                "সাতক্ষীরা" to "satkhira", "কুষ্টিয়া" to "kushtia", "ঝিনাইদহ" to "jhenaidah",
                "চুয়াডাঙ্গা" to "chuadanga", "মাগুরা" to "magura", "মেহেরপুর" to "meherpur",
                "নড়াইল" to "narail"
            )
            for ((bn, id) in khulnaDistricts) {
                list.add(DistrictAdminSeat(districtId = id, seatNumber = counter++, districtNameBn = bn, divisionBn = "খুলনা"))
            }

            // 5. Barishal Division (6)
            val barishalDistricts = listOf(
                "পটুয়াখালী" to "patuakhali", "বরিশাল" to "barishal", "ভোলা" to "bhola",
                "পিরোজপুর" to "pirojpur", "বরগুনা" to "barguna", "ঝালকাঠি" to "jhalakathi"
            )
            for ((bn, id) in barishalDistricts) {
                list.add(DistrictAdminSeat(districtId = id, seatNumber = counter++, districtNameBn = bn, divisionBn = "বরিশাল"))
            }

            // 6. Sylhet Division (4)
            val sylhetDistricts = listOf(
                "সিলেট" to "sylhet", "সুনামগঞ্জ" to "sunamganj",
                "মৌলভীবাজার" to "moulvibazar", "হবিগঞ্জ" to "habiganj"
            )
            for ((bn, id) in sylhetDistricts) {
                list.add(DistrictAdminSeat(districtId = id, seatNumber = counter++, districtNameBn = bn, divisionBn = "সিলেট"))
            }

            // 7. Rangpur Division (8)
            val rangpurDistricts = listOf(
                "রংপুর" to "rangpur", "দিনাজপুর" to "dinajpur", "কুড়িগ্রাম" to "kurigram",
                "গাইবান্ধা" to "gaibandha", "নীলফামারী" to "nilphamari", "লালমনিরহাট" to "lalmonirhat",
                "ঠাকুরগাঁও" to "thakurgaon", "পঞ্চগড়" to "panchagarh"
            )
            for ((bn, id) in rangpurDistricts) {
                list.add(DistrictAdminSeat(districtId = id, seatNumber = counter++, districtNameBn = bn, divisionBn = "রংপুর"))
            }

            // 8. Mymensingh Division (4)
            val mymensinghDistricts = listOf(
                "ময়মনসিংহ" to "mymensingh", "জামালপুর" to "jamalpur",
                "শেরপুর" to "sherpur", "নেত্রকোণা" to "netrokona"
            )
            for ((bn, id) in mymensinghDistricts) {
                list.add(DistrictAdminSeat(districtId = id, seatNumber = counter++, districtNameBn = bn, divisionBn = "ময়মনসিংহ"))
            }

            list
        }
    }
}
