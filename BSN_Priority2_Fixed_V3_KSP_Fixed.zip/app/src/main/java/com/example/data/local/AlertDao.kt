package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.EmergencyAlert
import kotlinx.coroutines.flow.Flow

@Dao
interface AlertDao {
    @Query("SELECT * FROM emergency_alerts ORDER BY timestamp DESC")
    fun getAllAlerts(): Flow<List<EmergencyAlert>>

    @Query("SELECT * FROM emergency_alerts WHERE status != 'সমাধান হয়েছে' AND status != 'বাতিলকৃত' ORDER BY timestamp DESC")
    fun getActiveAlerts(): Flow<List<EmergencyAlert>>

    @Query("SELECT * FROM emergency_alerts WHERE id = :id LIMIT 1")
    suspend fun getAlertById(id: String): EmergencyAlert?

    @Query("SELECT COUNT(*) FROM emergency_alerts")
    suspend fun getAlertCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: EmergencyAlert)

    @Update
    suspend fun updateAlert(alert: EmergencyAlert)
}
