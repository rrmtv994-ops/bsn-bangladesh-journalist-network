package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey
    var id: String = UUID.randomUUID().toString(),
    var type: String = TYPE_GROUP,         // "GROUP" or "PERSONAL"
    var chatId: String = GLOBAL_CHAT_ID,   // "bsn_global_chat" or "id1_id2"
    var senderId: String = "",
    var senderName: String = "",
    var senderRole: String = "সদস্য",
    var senderDistrict: String = "",
    var receiverId: String = "",
    var receiverName: String = "",
    var text: String = "",
    var mediaUrl: String = "",
    var isEmergency: Boolean = false,
    var timestamp: Long = System.currentTimeMillis()
) {
    companion object {
        const val TYPE_GROUP = "GROUP"
        const val TYPE_PERSONAL = "PERSONAL"
        const val GLOBAL_CHAT_ID = "bsn_global_chat"

        fun createPersonalChatId(id1: String, id2: String): String {
            return if (id1 <= id2) "${id1}_$id2" else "${id2}_$id1"
        }
    }
}
