package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Member
import kotlinx.coroutines.flow.Flow

@Dao
interface MemberDao {
    @Query("SELECT * FROM members ORDER BY isExecutive DESC, fullName ASC")
    fun getAllMembers(): Flow<List<Member>>

    @Query("SELECT * FROM members ORDER BY isExecutive DESC, fullName ASC")
    suspend fun getAllMembersList(): List<Member>

    @Query("SELECT * FROM members WHERE isVerified = 1 ORDER BY fullName ASC")
    fun getVerifiedMembers(): Flow<List<Member>>

    @Query("SELECT * FROM members WHERE isVerified = 0 ORDER BY joinedTimestamp DESC")
    fun getPendingMembers(): Flow<List<Member>>

    @Query("SELECT * FROM members WHERE id = :id LIMIT 1")
    suspend fun getMemberById(id: String): Member?

    @Query("SELECT * FROM members WHERE division = :division ORDER BY district ASC, fullName ASC")
    fun getMembersByDivision(division: String): Flow<List<Member>>

    @Query("SELECT COUNT(*) FROM members")
    suspend fun getMemberCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: Member)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMembers(members: List<Member>)

    @Update
    suspend fun updateMember(member: Member)

    @Query("DELETE FROM members WHERE id = :id")
    suspend fun deleteMemberById(id: String): Int

    @Query("DELETE FROM members")
    suspend fun clearAllMembers()
}
