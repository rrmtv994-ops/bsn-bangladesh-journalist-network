package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DistrictAdminSeat
import kotlinx.coroutines.flow.Flow

@Dao
interface DistrictSeatDao {
    @Query("SELECT * FROM district_admin_seats ORDER BY seatNumber ASC")
    fun getAllSeats(): Flow<List<DistrictAdminSeat>>

    @Query("SELECT * FROM district_admin_seats WHERE districtId = :districtId LIMIT 1")
    suspend fun getSeatByDistrictId(districtId: String): DistrictAdminSeat?

    @Query("SELECT * FROM district_admin_seats WHERE districtNameBn = :districtName LIMIT 1")
    suspend fun getSeatByDistrictName(districtName: String): DistrictAdminSeat?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSeats(seats: List<DistrictAdminSeat>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSeat(seat: DistrictAdminSeat)

    @Update
    suspend fun updateSeat(seat: DistrictAdminSeat)

    @Query("SELECT COUNT(*) FROM district_admin_seats")
    suspend fun getCount(): Int
}
