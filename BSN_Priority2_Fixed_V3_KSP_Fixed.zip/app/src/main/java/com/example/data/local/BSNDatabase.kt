package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.AuditLog
import com.example.data.model.ChatMessage
import com.example.data.model.DistrictAdminSeat
import com.example.data.model.EmergencyAlert
import com.example.data.model.Member
import com.example.data.model.NewsArticle
import com.example.data.model.Notice

@Database(
    entities = [
        Member::class,
        EmergencyAlert::class,
        NewsArticle::class,
        Notice::class,
        AuditLog::class,
        DistrictAdminSeat::class,
        ChatMessage::class
    ],
    version = 3,
    exportSchema = false
)
abstract class BSNDatabase : RoomDatabase() {
    abstract fun memberDao(): MemberDao
    abstract fun alertDao(): AlertDao
    abstract fun newsDao(): NewsDao
    abstract fun noticeDao(): NoticeDao
    abstract fun auditDao(): AuditDao
    abstract fun districtSeatDao(): DistrictSeatDao
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile
        private var INSTANCE: BSNDatabase? = null

        fun getDatabase(context: Context): BSNDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BSNDatabase::class.java,
                    "bsn_database.db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
