package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.ChatMessage
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages WHERE type = 'GROUP' ORDER BY timestamp ASC")
    fun getGroupMessages(): Flow<List<ChatMessage>>

    @Query("SELECT * FROM chat_messages WHERE type = 'PERSONAL' AND chatId = :chatId ORDER BY timestamp ASC")
    fun getPersonalMessages(chatId: String): Flow<List<ChatMessage>>

    @Query("SELECT * FROM chat_messages WHERE type = 'PERSONAL' AND (senderId = :userId OR receiverId = :userId) ORDER BY timestamp DESC")
    fun getAllPersonalMessagesForUser(userId: String): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<ChatMessage>)
}
