package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.BSNDatabase
import com.example.data.model.AuditLog
import com.example.data.model.EmergencyAlert
import com.example.data.model.Member
import com.example.data.model.NewsArticle
import com.example.data.model.Notice
import com.example.data.model.ChatMessage
import com.example.data.model.DistrictAdminSeat
import com.example.util.AlertSoundManager
import com.example.util.NotificationHelper
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.UUID

class BSNRepository(
    private val database: BSNDatabase,
    private val context: Context
) {
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val membersCollection by lazy { firestore.collection("members") }
    private val alertsCollection by lazy { firestore.collection("alerts") }
    private val newsCollection by lazy { firestore.collection("news") }
    private val noticesCollection by lazy { firestore.collection("notices") }
    private val auditCollection by lazy { firestore.collection("audit_logs") }
    private val districtSeatsCollection by lazy { firestore.collection("district_admin_seats") }
    private val chatCollection by lazy { firestore.collection("chat_messages") }

    private val scope = CoroutineScope(Dispatchers.IO)
    private val listeners = mutableListOf<ListenerRegistration>()

    val allMembers: Flow<List<Member>> = database.memberDao().getAllMembers()
    val allAlerts: Flow<List<EmergencyAlert>> = database.alertDao().getAllAlerts()
    val activeAlerts: Flow<List<EmergencyAlert>> = database.alertDao().getActiveAlerts()
    val allNews: Flow<List<NewsArticle>> = database.newsDao().getAllNews()
    val allNotices: Flow<List<Notice>> = database.noticeDao().getAllNotices()
    val pendingMembers: Flow<List<Member>> = database.memberDao().getPendingMembers()
    val allAuditLogs: Flow<List<AuditLog>> = database.auditDao().getAllAuditLogs()
    val allDistrictSeats: Flow<List<DistrictAdminSeat>> = database.districtSeatDao().getAllSeats()
    val groupMessages: Flow<List<ChatMessage>> = database.chatDao().getGroupMessages()

    fun getPersonalMessages(chatId: String): Flow<List<ChatMessage>> =
        database.chatDao().getPersonalMessages(chatId)

    init {
        startRealtimeSync()
        scope.launch {
            seedInitialDataIfEmpty()
        }
    }

    /**
     * Bidirectional Real-time Firestore synchronization.
     * When any phone creates an alert, registers, or posts news, all other phones receive it live!
     */
    fun startRealtimeSync() {
        try {
            // 1. Members Snapshot Listener
            val memberListener = membersCollection.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("BSNRepository", "Members sync error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null && !snapshot.isEmpty) {
                    val remoteMembers = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(Member::class.java)?.copy(id = doc.id)
                    }
                    scope.launch {
                        database.memberDao().insertMembers(remoteMembers)
                    }
                }
            }
            listeners.add(memberListener)

            // 2. High Alerts Snapshot Listener
            val alertListener = alertsCollection.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("BSNRepository", "Alerts sync error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val remoteAlerts = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(EmergencyAlert::class.java)?.copy(id = doc.id)
                    }
                    scope.launch {
                        for (alert in remoteAlerts) {
                            database.alertDao().insertAlert(alert)
                        }
                        // Check if there is any new active alert
                        val hasActiveUnresolved = remoteAlerts.any {
                            it.status == EmergencyAlert.STATUS_NEW || it.status == EmergencyAlert.STATUS_VERIFYING
                        }
                        if (hasActiveUnresolved && !AlertSoundManager.isSoundActive.value) {
                            AlertSoundManager.playAlertSound(context)
                        }
                    }
                }
            }
            listeners.add(alertListener)

            // 3. News Snapshot Listener
            val newsListener = newsCollection.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("BSNRepository", "News sync error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val remoteNews = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(NewsArticle::class.java)?.copy(id = doc.id)
                    }
                    scope.launch {
                        for (news in remoteNews) {
                            database.newsDao().insertNews(news)
                        }
                    }
                }
            }
            listeners.add(newsListener)

            // 4. Notices Snapshot Listener
            val noticeListener = noticesCollection.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("BSNRepository", "Notice sync error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val remoteNotices = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(Notice::class.java)?.copy(id = doc.id)
                    }
                    scope.launch {
                        for (notice in remoteNotices) {
                            database.noticeDao().insertNotice(notice)
                        }
                    }
                }
            }
            listeners.add(noticeListener)

            // 5. Audit Log Snapshot Listener
            val auditListener = auditCollection.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("BSNRepository", "Audit sync error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val remoteLogs = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(AuditLog::class.java)?.copy(id = doc.id)
                    }
                    scope.launch {
                        database.auditDao().insertAll(remoteLogs)
                    }
                }
            }
            listeners.add(auditListener)

            // 6. District Admin Seats Snapshot Listener (64 Districts)
            val seatsListener = districtSeatsCollection.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("BSNRepository", "District seats sync error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null && !snapshot.isEmpty) {
                    val remoteSeats = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(DistrictAdminSeat::class.java)?.copy(districtId = doc.id)
                    }
                    scope.launch {
                        database.districtSeatDao().insertSeats(remoteSeats)
                    }
                }
            }
            listeners.add(seatsListener)

            // 7. Chat Messages Snapshot Listener
            val chatListener = chatCollection.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("BSNRepository", "Chat sync error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null && !snapshot.isEmpty) {
                    val remoteMsgs = snapshot.documents.mapNotNull { doc ->
                        doc.toObject(ChatMessage::class.java)?.copy(id = doc.id)
                    }
                    scope.launch {
                        database.chatDao().insertMessages(remoteMsgs)
                    }
                }
            }
            listeners.add(chatListener)
        } catch (e: Exception) {
            Log.e("BSNRepository", "Failed to initialize Firestore listeners: ${e.message}")
        }
    }

    suspend fun getMemberById(id: String): Member? = database.memberDao().getMemberById(id)

    suspend fun getMemberByEmail(email: String): Member? = withContext(Dispatchers.IO) {
        val trimmed = email.trim()
        if (trimmed.equals("rrmrimonshikder@gmail.com", ignoreCase = true) ||
            trimmed.equals("bsnnewsnetwork@gmail.com", ignoreCase = true) ||
            trimmed.equals("rrmtv994@gmail.com", ignoreCase = true)) {
            val founder = database.memberDao().getMemberById("BSN 001")
            if (founder != null) return@withContext founder
        }

        // First check local room
        val members = database.memberDao().getAllMembersList()
        val local = members.find { it.email.trim().equals(trimmed, ignoreCase = true) }
        if (local != null) return@withContext local

        // Check remote firestore
        try {
            val query = membersCollection.whereEqualTo("email", email.trim()).limit(1).get().await()
            val doc = query.documents.firstOrNull()
            if (doc != null) {
                val member = doc.toObject(Member::class.java)?.copy(id = doc.id)
                if (member != null) {
                    database.memberDao().insertMember(member)
                    return@withContext member
                }
            }
        } catch (e: Exception) {
            Log.e("BSNRepository", "Error looking up member by email: ${e.message}")
        }
        null
    }

    suspend fun generateNextBsnId(): String = withContext(Dispatchers.IO) {
        val members = database.memberDao().getAllMembersList()
        var maxNum = 5
        for (m in members) {
            val digits = m.id.filter { it.isDigit() }
            val n = digits.toIntOrNull()
            if (n != null && n > maxNum) {
                maxNum = n
            }
        }
        val next = maxNum + 1
        String.format("BSN %03d", next)
    }

    suspend fun registerMember(member: Member) = withContext(Dispatchers.IO) {
        if (member.qrToken.isBlank()) {
            member.qrToken = UUID.randomUUID().toString().take(12)
        }
        database.memberDao().insertMember(member)
        try {
            membersCollection.document(member.id).set(member).await()
            Log.d("BSNRepository", "Member registered to Firestore: ${member.id}")
        } catch (e: Exception) {
            Log.e("BSNRepository", "Failed to sync member to Firestore: ${e.message}")
        }
    }

    suspend fun updateMember(member: Member) = withContext(Dispatchers.IO) {
        database.memberDao().updateMember(member)
        try {
            membersCollection.document(member.id).set(member).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Failed to update member in Firestore: ${e.message}")
        }
    }

    // ==========================================
    // 65 ADMIN MANAGEMENT & DISTRICT APPOINTMENTS
    // ==========================================

    suspend fun appointDistrictAdmin(
        districtId: String,
        targetMember: Member,
        performer: Member
    ): Boolean = withContext(Dispatchers.IO) {
        if (!performer.isSuperAdmin()) {
            Log.e("BSNRepository", "Only Super Admin BSN 001 can appoint District Admins")
            return@withContext false
        }

        val seat = database.districtSeatDao().getSeatByDistrictId(districtId) ?: return@withContext false

        val updatedSeat = seat.copy(
            adminId = targetMember.id,
            adminName = targetMember.fullName,
            adminPhone = targetMember.phone,
            adminEmail = targetMember.email,
            status = DistrictAdminSeat.STATUS_ASSIGNED,
            appointedTimestamp = System.currentTimeMillis(),
            appointedBy = performer.fullName,
            suspensionReason = ""
        )
        database.districtSeatDao().updateSeat(updatedSeat)
        try {
            districtSeatsCollection.document(districtId).set(updatedSeat).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Error syncing seat appointment: ${e.message}")
        }

        val updatedMember = targetMember.copy(
            role = Member.ROLE_DISTRICT_ADMIN,
            isAdmin = true,
            assignedDistrictSeat = seat.districtNameBn,
            isVerified = true
        )
        database.memberDao().updateMember(updatedMember)
        try {
            membersCollection.document(targetMember.id).set(updatedMember).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Error syncing appointed member: ${e.message}")
        }

        logAudit(
            action = "District Admin নিয়োগ",
            performedBy = performer,
            targetId = targetMember.id,
            details = "${seat.districtNameBn} জেলার এডমিন হিসেবে ${targetMember.fullName} (${targetMember.id}) কে নিয়োগ প্রদান করা হয়েছে।"
        )
        true
    }

    suspend fun suspendDistrictAdmin(
        districtId: String,
        reason: String,
        performer: Member
    ): Boolean = withContext(Dispatchers.IO) {
        if (!performer.isSuperAdmin()) return@withContext false

        val seat = database.districtSeatDao().getSeatByDistrictId(districtId) ?: return@withContext false
        val updatedSeat = seat.copy(
            status = DistrictAdminSeat.STATUS_SUSPENDED,
            suspensionReason = reason
        )
        database.districtSeatDao().updateSeat(updatedSeat)
        try {
            districtSeatsCollection.document(districtId).set(updatedSeat).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Error syncing seat suspension: ${e.message}")
        }

        val currentAdmin = database.memberDao().getMemberById(seat.adminId)
        if (currentAdmin != null) {
            val updatedMember = currentAdmin.copy(isAdmin = false)
            database.memberDao().updateMember(updatedMember)
            try {
                membersCollection.document(currentAdmin.id).set(updatedMember).await()
            } catch (e: Exception) {
                Log.e("BSNRepository", "Error syncing suspended member: ${e.message}")
            }
        }

        logAudit(
            action = "District Admin স্থগিতকরণ",
            performedBy = performer,
            targetId = seat.adminId,
            details = "${seat.districtNameBn} জেলার এডমিন ${seat.adminName} কে স্থগিত করা হয়েছে। কারণ: $reason"
        )
        true
    }

    suspend fun removeDistrictAdmin(
        districtId: String,
        performer: Member
    ): Boolean = withContext(Dispatchers.IO) {
        if (!performer.isSuperAdmin()) return@withContext false

        val seat = database.districtSeatDao().getSeatByDistrictId(districtId) ?: return@withContext false
        val previousAdminId = seat.adminId
        val previousAdminName = seat.adminName

        val vacantSeat = seat.copy(
            adminId = "",
            adminName = "",
            adminPhone = "",
            adminEmail = "",
            status = DistrictAdminSeat.STATUS_VACANT,
            suspensionReason = "",
            appointedTimestamp = 0L
        )
        database.districtSeatDao().updateSeat(vacantSeat)
        try {
            districtSeatsCollection.document(districtId).set(vacantSeat).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Error syncing vacant seat: ${e.message}")
        }

        if (previousAdminId.isNotBlank()) {
            val prevMember = database.memberDao().getMemberById(previousAdminId)
            if (prevMember != null && !prevMember.isSuperAdmin()) {
                val memberOnly = prevMember.copy(
                    role = Member.ROLE_MEMBER,
                    isAdmin = false,
                    assignedDistrictSeat = ""
                )
                database.memberDao().updateMember(memberOnly)
                try {
                    membersCollection.document(prevMember.id).set(memberOnly).await()
                } catch (e: Exception) {
                    Log.e("BSNRepository", "Error updating removed admin: ${e.message}")
                }
            }
        }

        logAudit(
            action = "District Admin অপসারণ",
            performedBy = performer,
            targetId = previousAdminId,
            details = "${seat.districtNameBn} জেলা এডমিন পদ থেকে $previousAdminName কে প্রত্যাহার করা হয়েছে। আসনটি এখন শূন্য (Vacant)।"
        )
        true
    }

    // ==========================================
    // MEMBERSHIP CANCEL / REVOKE SYSTEM
    // ==========================================

    suspend fun cancelMembership(
        memberId: String,
        reason: String,
        performer: Member
    ): Boolean = withContext(Dispatchers.IO) {
        val target = database.memberDao().getMemberById(memberId) ?: return@withContext false

        if (target.isSuperAdmin()) {
            Log.e("BSNRepository", "SECURITY VIOLATION: Super Admin BSN 001 can NEVER be cancelled or revoked!")
            return@withContext false
        }

        if (!performer.isSuperAdmin()) {
            if (!performer.isDistrictAdmin()) return@withContext false
            if (!performer.canManageDistrict(target.district)) {
                Log.e("BSNRepository", "District Admin ${performer.fullName} can only cancel members of ${performer.assignedDistrictSeat}")
                return@withContext false
            }
            if (target.isDistrictAdmin()) {
                Log.e("BSNRepository", "District Admin cannot cancel another District Admin!")
                return@withContext false
            }
        }

        val updated = target.copy(
            membershipStatus = Member.STATUS_REVOKED,
            cancellationReason = reason,
            cancelledBy = "${performer.fullName} (${performer.id})",
            cancelledTimestamp = System.currentTimeMillis()
        )
        database.memberDao().updateMember(updated)
        try {
            membersCollection.document(memberId).set(updated).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Firestore member cancellation error: ${e.message}")
        }

        logAudit(
            action = "সদস্যপদ বাতিল (Revoked)",
            performedBy = performer,
            targetId = memberId,
            details = "সদস্য ${target.fullName} (${target.id}) এর সদস্যপদ বাতিল করা হয়েছে। কারণ: $reason"
        )
        true
    }

    suspend fun reinstateMembership(
        memberId: String,
        performer: Member
    ): Boolean = withContext(Dispatchers.IO) {
        val target = database.memberDao().getMemberById(memberId) ?: return@withContext false
        if (!performer.isSuperAdmin() && !performer.canManageDistrict(target.district)) {
            return@withContext false
        }

        val updated = target.copy(
            membershipStatus = Member.STATUS_ACTIVE,
            cancellationReason = ""
        )
        database.memberDao().updateMember(updated)
        try {
            membersCollection.document(memberId).set(updated).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Firestore member reinstatement error: ${e.message}")
        }

        logAudit(
            action = "সদস্যপদ পুনর্বহাল",
            performedBy = performer,
            targetId = memberId,
            details = "সদস্য ${target.fullName} (${target.id}) এর সদস্যপদ পুনরায় সক্রিয় করা হয়েছে।"
        )
        true
    }

    // ==========================================
    // ID CARD APPROVAL & VERIFICATION
    // ==========================================

    suspend fun approveIdCard(memberId: String, performer: Member): Boolean = withContext(Dispatchers.IO) {
        if (!performer.isSuperAdmin()) return@withContext false

        val member = database.memberDao().getMemberById(memberId) ?: return@withContext false
        val token = if (member.qrToken.isNotBlank()) member.qrToken else UUID.randomUUID().toString().take(12)
        val updated = member.copy(
            idCardStatus = Member.ID_STATUS_APPROVED,
            isVerified = true,
            idCardApprovedBy = performer.fullName,
            idCardApprovedTimestamp = System.currentTimeMillis(),
            qrToken = token
        )
        database.memberDao().updateMember(updated)
        try {
            membersCollection.document(memberId).set(updated).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Firestore ID approve error: ${e.message}")
        }

        logAudit(
            action = "প্রেস আইডি কার্ড অনুমোদন",
            performedBy = performer,
            targetId = memberId,
            details = "${member.fullName} (${member.id}) এর ডিজিটাল আইডি কার্ড অনুমোদিত ও কিউআর যাচাইকৃত।"
        )
        true
    }

    suspend fun rejectIdCard(memberId: String, reason: String, performer: Member): Boolean = withContext(Dispatchers.IO) {
        if (!performer.isSuperAdmin()) return@withContext false

        val member = database.memberDao().getMemberById(memberId) ?: return@withContext false
        val updated = member.copy(
            idCardStatus = Member.ID_STATUS_REJECTED
        )
        database.memberDao().updateMember(updated)
        try {
            membersCollection.document(memberId).set(updated).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Firestore ID reject error: ${e.message}")
        }

        logAudit(
            action = "প্রেস আইডি কার্ড নামঞ্জুর",
            performedBy = performer,
            targetId = memberId,
            details = "${member.fullName} (${member.id}) এর আইডি কার্ড নামঞ্জুর। কারণ: $reason"
        )
        true
    }

    // ==========================================
    // GROUP & PERSONAL MESSAGING
    // ==========================================

    suspend fun sendChatMessage(message: ChatMessage) = withContext(Dispatchers.IO) {
        database.chatDao().insertMessage(message)
        try {
            chatCollection.document(message.id).set(message).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Firestore chat send error: ${e.message}")
        }
    }

    // Legacy method support
    suspend fun approveMember(memberId: String, admin: Member) = withContext(Dispatchers.IO) {
        approveIdCard(memberId, admin)
    }

    suspend fun promoteToAdmin(memberId: String, admin: Member): Boolean = withContext(Dispatchers.IO) {
        if (!admin.isSuperAdmin()) return@withContext false
        val member = database.memberDao().getMemberById(memberId)
        if (member != null) {
            val updated = member.copy(isAdmin = true, role = Member.ROLE_DISTRICT_ADMIN)
            database.memberDao().updateMember(updated)
            try {
                membersCollection.document(memberId).update("isAdmin", true, "role", Member.ROLE_DISTRICT_ADMIN).await()
            } catch (e: Exception) {
                Log.e("BSNRepository", "Firestore admin promote error: ${e.message}")
            }
            logAudit(
                action = "এডমিন নিয়োগ",
                performedBy = admin,
                targetId = memberId,
                details = "${member.fullName} (${member.id}) কে এডমিন হিসেবে দায়িত্ব প্রদান করা হয়েছে।"
            )
            return@withContext true
        }
        false
    }

    suspend fun revokeAdmin(memberId: String, admin: Member): Boolean = withContext(Dispatchers.IO) {
        if (!admin.isSuperAdmin()) return@withContext false
        val member = database.memberDao().getMemberById(memberId)
        if (member != null && !member.isSuperAdmin()) {
            val updated = member.copy(isAdmin = false, role = Member.ROLE_MEMBER, assignedDistrictSeat = "")
            database.memberDao().updateMember(updated)
            try {
                membersCollection.document(memberId).update(
                    "isAdmin", false,
                    "role", Member.ROLE_MEMBER,
                    "assignedDistrictSeat", ""
                ).await()
            } catch (e: Exception) {
                Log.e("BSNRepository", "Firestore admin revoke error: ${e.message}")
            }
            logAudit(
                action = "এডমিন ক্ষমতা প্রত্যাহার",
                performedBy = admin,
                targetId = memberId,
                details = "${member.fullName} (${member.id}) এর এডমিন ক্ষমতা প্রত্যাহার করা হয়েছে।"
            )
            return@withContext true
        }
        false
    }

    suspend fun deleteMember(memberId: String, admin: Member): Boolean = withContext(Dispatchers.IO) {
        cancelMembership(memberId, "সুপার এডমিন কর্তৃক অপসারণ", admin)
    }

    suspend fun refreshMembersFromFirestore() = withContext(Dispatchers.IO) {
        try {
            val snapshot = membersCollection.get().await()
            if (!snapshot.isEmpty) {
                val firestoreMembers = snapshot.documents.mapNotNull { doc ->
                    doc.toObject(Member::class.java)?.copy(id = doc.id)
                }
                if (firestoreMembers.isNotEmpty()) {
                    database.memberDao().clearAllMembers()
                    database.memberDao().insertMembers(firestoreMembers)
                    Log.d("BSNRepository", "Refreshed ${firestoreMembers.size} members from Firestore")
                }
            }
        } catch (e: Exception) {
            Log.e("BSNRepository", "Error refreshing members from Firestore: ${e.message}")
        }
    }

    suspend fun dispatchHighAlert(alert: EmergencyAlert) = withContext(Dispatchers.IO) {
        database.alertDao().insertAlert(alert)
        NotificationHelper.showEmergencyAlertNotification(context, alert)
        AlertSoundManager.playAlertSound(context)
        try {
            alertsCollection.document(alert.id).set(alert).await()
            Log.d("BSNRepository", "High alert synced to Firestore: ${alert.id}")
        } catch (e: Exception) {
            Log.e("BSNRepository", "Firestore alert save: ${e.message}")
        }
    }

    suspend fun updateAlertStatus(alertId: String, status: String, responderNotes: String = "") = withContext(Dispatchers.IO) {
        val alert = database.alertDao().getAlertById(alertId)
        if (alert != null) {
            val updated = alert.copy(
                status = status,
                responderNotes = if (responderNotes.isNotBlank()) responderNotes else alert.responderNotes
            )
            database.alertDao().updateAlert(updated)
            try {
                alertsCollection.document(alertId).set(updated).await()
            } catch (e: Exception) {
                Log.e("BSNRepository", "Firestore alert update: ${e.message}")
            }
        }
    }

    suspend fun cancelAlert(alertId: String, reason: String, admin: Member) = withContext(Dispatchers.IO) {
        val alert = database.alertDao().getAlertById(alertId)
        if (alert != null) {
            val updated = alert.copy(
                status = EmergencyAlert.STATUS_CANCELLED,
                isFalseAlarm = true,
                responderNotes = "প্রত্যাহারের কারণ: $reason (প্রত্যাহারকারী: ${admin.fullName} - ${admin.id})"
            )
            database.alertDao().updateAlert(updated)
            try {
                alertsCollection.document(alertId).set(updated).await()
            } catch (e: Exception) {
                Log.e("BSNRepository", "Firestore alert cancel: ${e.message}")
            }

            logAudit(
                action = "HIGH ALERT প্রত্যাহার",
                performedBy = admin,
                targetId = alertId,
                details = "বিপদ: ${alert.alertType}, স্থান: ${alert.district}। কারণ: $reason"
            )
        }
    }

    suspend fun submitNews(news: NewsArticle) = withContext(Dispatchers.IO) {
        database.newsDao().insertNews(news)
        try {
            newsCollection.document(news.id).set(news).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Firestore news save: ${e.message}")
        }
    }

    suspend fun approveNews(newsId: String, admin: Member) = withContext(Dispatchers.IO) {
        val news = database.newsDao().getNewsById(newsId)
        if (news != null) {
            val updated = news.copy(
                status = NewsArticle.STATUS_APPROVED,
                isVerified = true
            )
            database.newsDao().updateNews(updated)
            try {
                newsCollection.document(newsId).set(updated).await()
            } catch (e: Exception) {
                Log.e("BSNRepository", "Firestore news approve error: ${e.message}")
            }
            logAudit(
                action = "সংবাদ অনুমোদন",
                performedBy = admin,
                targetId = newsId,
                details = "শিরোনাম: ${news.title} (রিপোর্টার: ${news.authorName} - ${news.reporterId})"
            )
        }
    }

    suspend fun rejectNews(newsId: String, reason: String, admin: Member) = withContext(Dispatchers.IO) {
        val news = database.newsDao().getNewsById(newsId)
        if (news != null) {
            val updated = news.copy(
                status = NewsArticle.STATUS_REJECTED,
                isVerified = false,
                aiReviewReport = if (news.aiReviewReport.isNotBlank()) "${news.aiReviewReport}\nপ্রত্যাখ্যান নোট: $reason" else "প্রত্যাখ্যান নোট: $reason"
            )
            database.newsDao().updateNews(updated)
            try {
                newsCollection.document(newsId).set(updated).await()
            } catch (e: Exception) {
                Log.e("BSNRepository", "Firestore news reject error: ${e.message}")
            }
            logAudit(
                action = "সংবাদ প্রত্যাখ্যান",
                performedBy = admin,
                targetId = newsId,
                details = "শিরোনাম: ${news.title}। কারণ: $reason"
            )
        }
    }

    suspend fun publishNotice(notice: Notice, admin: Member? = null) = withContext(Dispatchers.IO) {
        database.noticeDao().insertNotice(notice)
        NotificationHelper.showNoticeNotification(context, notice)
        try {
            noticesCollection.document(notice.id).set(notice).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Firestore notice save: ${e.message}")
        }
        if (admin != null) {
            logAudit(
                action = "নোটিশ প্রকাশ",
                performedBy = admin,
                targetId = notice.id,
                details = "নোটিশ: ${notice.title} (${notice.priority})"
            )
        }
    }

    suspend fun logAudit(action: String, performedBy: Member, targetId: String, details: String) = withContext(Dispatchers.IO) {
        val log = AuditLog(
            id = "AUD-" + UUID.randomUUID().toString().take(8).uppercase(),
            action = action,
            performedByName = performedBy.fullName,
            performedById = performedBy.id,
            performedByEmail = performedBy.email,
            targetId = targetId,
            details = details,
            timestamp = System.currentTimeMillis()
        )
        database.auditDao().insertAuditLog(log)
        try {
            auditCollection.document(log.id).set(log).await()
        } catch (e: Exception) {
            Log.e("BSNRepository", "Firestore audit log save: ${e.message}")
        }
    }

    suspend fun seedInitialDataIfEmpty() = withContext(Dispatchers.IO) {
        if (database.memberDao().getMemberCount() == 0) {
            val initialMembers = listOf(
                Member(
                    id = "BSN 001",
                    fullName = "মোঃ রিমন শিকদার",
                    phone = "01989888856",
                    email = "rrmrimonshikder@gmail.com",
                    profession = "প্রতিষ্ঠাতা ও কর্ণধার",
                    organization = "বাংলাদেশ সাংবাদিক নেটওয়ার্ক (BSN)",
                    division = "ঢাকা",
                    district = "ঢাকা",
                    upazila = "ঢাকা সদর",
                    address = "ঢাকা, বাংলাদেশ",
                    bloodGroup = "O+",
                    bio = "BSN 001 — প্রতিষ্ঠাতা ও কর্ণধার। বাংলাদেশ সাংবাদিক নেটওয়ার্ক (BSN) এর সর্বোচ্চ নীতিনির্ধারণী ও প্রধান নিয়ন্ত্রক।",
                    emergencyContact = "01989888856",
                    isVerified = true,
                    isExecutive = true,
                    isAdmin = true,
                    role = "Super Admin",
                    membershipStatus = Member.STATUS_ACTIVE,
                    idCardStatus = Member.ID_STATUS_APPROVED,
                    qrToken = "BSN-001-FOUNDER-VERIFIED"
                ),
                Member(
                    id = "BSN 002",
                    fullName = "তাহমিদ হাসান",
                    phone = "01711223344",
                    email = "tahmid.press@gmail.com",
                    profession = "সাংবাদিক ও ব্যুরো প্রধান",
                    organization = "দৈনিক বাংলার বার্তা",
                    division = "ঢাকা",
                    district = "ঢাকা",
                    upazila = "মিরপুর",
                    address = "মিরপুর-১০, ঢাকা",
                    bloodGroup = "B+",
                    bio = "১০ বছরের সাংবাদিকতার অভিজ্ঞতা, অপরাধ ও আদালত বিষয়ক সিনিয়র রিপোর্টার।",
                    emergencyContact = "01722334455",
                    isVerified = true,
                    isExecutive = false,
                    isAdmin = false,
                    role = "সদস্য"
                ),
                Member(
                    id = "BSN 003",
                    fullName = "মাহমুদুল হক রাজিব",
                    phone = "01822334455",
                    email = "rajib.tv@gmail.com",
                    profession = "সিনিয়র ক্যামেরাপারসন ও ভিডিও জার্নালিস্ট",
                    organization = "এনটিভি নিউজ",
                    division = "চট্টগ্রাম",
                    district = "চট্টগ্রাম",
                    upazila = "পটিয়া",
                    address = "জিইসি মোড়, চট্টগ্রাম",
                    bloodGroup = "A+",
                    bio = "টেলিভিশন সংবাদ ও সংঘাতপূর্ণ এলাকার সরেজমিন চিত্রগ্রাহক।",
                    emergencyContact = "01833445566",
                    isVerified = true,
                    isExecutive = false,
                    isAdmin = false,
                    role = "সদস্য"
                ),
                Member(
                    id = "BSN 004",
                    fullName = "ফারহানা আকতার নিপা",
                    phone = "01933445566",
                    email = "nipa.patuakhali@gmail.com",
                    profession = "স্টাফ রিপোর্টার",
                    organization = "উপকূল বার্তা",
                    division = "বরিশাল",
                    district = "পটুয়াখালী",
                    upazila = "কলাপাড়া",
                    address = "কলাপাড়া প্রেস ক্লাব সংলগ্ন, পটুয়াখালী",
                    bloodGroup = "AB+",
                    bio = "উপকূলীয় নারী ও মানবাধিকার বিষয়ে সক্রিয় সাংবাদিকতা।",
                    emergencyContact = "01999887766",
                    isVerified = true,
                    isExecutive = true,
                    isAdmin = false,
                    role = "সদস্য"
                ),
                Member(
                    id = "BSN 005",
                    fullName = "সাইফুল ইসলাম মজুমদার",
                    phone = "01611122233",
                    email = "saiful.majumder@gmail.com",
                    profession = "প্রশাসন ও সমন্বয়ক",
                    organization = "জেলা মিডিয়া সেল",
                    division = "রাজশাহী",
                    district = "রাজশাহী",
                    upazila = "রাজশাহী মেট্রো",
                    address = "আলুপট্টি, রাজশাহী",
                    bloodGroup = "O+",
                    bio = "আইনশৃঙ্খলা ও গণমাধ্যম সংযোগ কর্মকর্তা।",
                    emergencyContact = "01600000000",
                    isVerified = true,
                    isExecutive = false,
                    isAdmin = false,
                    role = "সদস্য"
                )
            )
            database.memberDao().insertMembers(initialMembers)
            try {
                for (m in initialMembers) {
                    membersCollection.document(m.id).set(m)
                }
            } catch (e: Exception) {
                Log.e("BSNRepository", "Initial Firestore seed error: ${e.message}")
            }
        }

        if (database.noticeDao().getNoticeCount() == 0) {
            val initialNotices = listOf(
                Notice(
                    id = "NOT-101",
                    title = "🚨 ফিল্ডে কর্তব্যরত সাংবাদিকদের জন্য জরুরি নিরাপত্তা গাইডলাইন",
                    body = "যেকোনো ঝুঁকি বা হামলার মুখে তাৎক্ষণিক BSN HIGH ALERT বোতাম চেপে অবস্থান জানান। একই সাথে স্থানীয় প্রেস ক্লাব ও জাতীয় জরুরি সেবা ৯৯৯ এ কল দিয়ে পরিস্থিতি নিশ্চিত করুন।",
                    priority = "জরুরি",
                    issuedBy = "কেন্দ্রীয় সচিবালয়, BSN",
                    isPinned = true
                ),
                Notice(
                    id = "NOT-102",
                    title = "জাতীয় সম্মেলন ও ডিজিটাল সদস্য আইডি কার্ড নবায়ন",
                    body = "বাংলাদেশ সাংবাদিক নেটওয়ার্কের বার্ষিক সমন্বয় সভা অনুষ্ঠিত হবে। সকল সদস্যকে অ্যাপের প্রোফাইল থেকে ডিজিটাল প্রেস কার্ড সংগ্রহ করার অনুরোধ জানানো যাচ্ছে।",
                    priority = "সাধারণ",
                    issuedBy = "মোঃ রিমন শিকদার, Founder & Super Admin",
                    isPinned = false
                )
            )
            database.noticeDao().insertAllNotices(initialNotices)
        }

        if (database.newsDao().getNewsCount() == 0) {
            val initialNews = listOf(
                NewsArticle(
                    id = "NEWS-201",
                    title = "উপকূলীয় চরাঞ্চলের সত্য উদঘাটনে সাংবাদিকদের ঐক্যবদ্ধ ভূমিকা রাখার আহ্বান",
                    content = "পটুয়াখালী ও বরগুনার দূরবর্তী চরাঞ্চলে সংবাদ সংগ্রহের সময় সাংবাদিকদের সার্বিক নিরাপত্তা নিশ্চিতের তাগিদ দিয়েছেন বিশিষ্ট সাংবাদিক নেতৃবৃন্দ। BSN প্ল্যাটফর্মের মাধ্যমে দ্রুত সুরক্ষা সেবা নিশ্চিতের ওপর গুরুত্বারোপ করা হয়।",
                    category = "সাংবাদিক সুরক্ষা",
                    authorName = "মোঃ রিমন শিকদার",
                    reporterId = "BSN 001",
                    mediaOutlet = "BSN সেন্ট্রাল নিউজ",
                    division = "বরিশাল",
                    district = "পটুয়াখালী",
                    upazila = "রাঙ্গাবালী",
                    status = NewsArticle.STATUS_APPROVED,
                    isVerified = true
                ),
                NewsArticle(
                    id = "NEWS-202",
                    title = "সাংবাদিকদের পেশাগত নিরাপত্তা সুরক্ষায় কার্যকর ডিজিটাল মনিটরিং সেল চালু",
                    content = "দেশব্যাপী তৃণমূল থেকে জাতীয় পর্যায় পর্যন্ত গণমাধ্যমকর্মীদের যেকোনো সংকট মুহূর্তে জরুরি সংকেত প্রেরণের ব্যবস্থা হিসেবে BSN High Alert সক্রিয় রয়েছে।",
                    category = "জরুরি সংবাদ",
                    authorName = "তাহমিদ হাসান",
                    reporterId = "BSN 002",
                    mediaOutlet = "দৈনিক বাংলার বার্তা",
                    division = "ঢাকা",
                    district = "ঢাকা",
                    upazila = "মিরপুর",
                    status = NewsArticle.STATUS_APPROVED,
                    isVerified = true
                )
            )
            database.newsDao().insertAllNews(initialNews)
        }

        if (database.alertDao().getAlertCount() == 0) {
            val sampleAlert = EmergencyAlert(
                id = "ALT-" + UUID.randomUUID().toString().take(6).uppercase(),
                alertType = "৪. সাংবাদিকের ওপর হামলা",
                description = "রাঙ্গাবালী উপজেলার একটি স্থানে তথ্য সংগ্রহের সময় অবরুদ্ধ ও হামলার হুমকি। জরুরি সমন্বয় ও সহায়তা প্রয়োজন।",
                reporterName = "মোঃ রিমন শিকদার",
                reporterPhone = "01700000000",
                reporterRole = "প্রতিষ্ঠাতা ও সুপার এডমিন",
                latitude = 21.9167,
                longitude = 90.4667,
                locationAccuracy = 12f,
                division = "বরিশাল",
                district = "পটুয়াখালী",
                upazila = "রাঙ্গাবালী",
                spotAddress = "রাঙ্গাবালী প্রেস ক্লাব সংলগ্ন এলাকা",
                googleMapsUrl = "https://maps.google.com/?q=21.9167,90.4667",
                status = EmergencyAlert.STATUS_VERIFYING,
                responderNotes = "স্থানীয় প্রশাসন ও সাংবাদিকদের সাথে প্রাথমিক যোগাযোগ সম্পন্ন হয়েছে।"
            )
            database.alertDao().insertAlert(sampleAlert)
        }

        if (database.districtSeatDao().getCount() == 0) {
            val allSeats = DistrictAdminSeat.ALL_64_DISTRICTS
            database.districtSeatDao().insertSeats(allSeats)
            try {
                for (seat in allSeats) {
                    districtSeatsCollection.document(seat.districtId).set(seat)
                }
            } catch (e: Exception) {
                Log.e("BSNRepository", "Initial district seats seeding error: ${e.message}")
            }
        }

        refreshMembersFromFirestore()
    }
}
