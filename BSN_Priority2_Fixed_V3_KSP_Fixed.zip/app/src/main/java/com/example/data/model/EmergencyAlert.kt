package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "emergency_alerts")
data class EmergencyAlert(
    @PrimaryKey
    var id: String = "",
    var alertType: String = "",
    var description: String = "",
    var reporterName: String = "",
    var reporterPhone: String = "",
    var reporterRole: String = "",
    var latitude: Double = 0.0,
    var longitude: Double = 0.0,
    var locationAccuracy: Float = 0f,
    var division: String = "",
    var district: String = "",
    var upazila: String = "",
    var spotAddress: String = "",
    var googleMapsUrl: String = "",
    var timestamp: Long = System.currentTimeMillis(),
    var status: String = STATUS_NEW,
    var responderNotes: String = "",
    var isFalseAlarm: Boolean = false,
    var isLocalGenerated: Boolean = true
) {
    companion object {
        const val STATUS_NEW = "নতুন সংকেত"
        const val STATUS_VERIFYING = "যাচাই চলছে"
        const val STATUS_COORDINATING = "সহায়তা সমন্বয় চলছে"
        const val STATUS_RESOLVED = "সমাধান হয়েছে"
        const val STATUS_CANCELLED = "বাতিলকৃত"
    }
}
