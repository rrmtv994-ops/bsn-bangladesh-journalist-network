package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.NewsArticle
import kotlinx.coroutines.flow.Flow

@Dao
interface NewsDao {
    @Query("SELECT * FROM news_articles ORDER BY timestamp DESC")
    fun getAllNews(): Flow<List<NewsArticle>>

    @Query("SELECT * FROM news_articles WHERE id = :id LIMIT 1")
    suspend fun getNewsById(id: String): NewsArticle?

    @Query("SELECT COUNT(*) FROM news_articles")
    suspend fun getNewsCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNews(news: NewsArticle)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllNews(news: List<NewsArticle>)

    @Update
    suspend fun updateNews(news: NewsArticle)

    @Query("DELETE FROM news_articles WHERE id = :id")
    suspend fun deleteNewsById(id: String): Int
}
