package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "members")
data class Member(
    @PrimaryKey
    var id: String = "",
    var fullName: String = "",
    var phone: String = "",
    var email: String = "",
    var profession: String = "",
    var organization: String = "",
    var division: String = "",
    var district: String = "",
    var upazila: String = "",
    var address: String = "",
    var bloodGroup: String = "",
    var photoUrl: String = "",
    var nidOrBirthCert: String = "",
    var pressCardNumber: String = "",
    var emergencyContact: String = "",
    var bio: String = "",
    var isVerified: Boolean = false,
    var isExecutive: Boolean = false,
    var role: String = "সদস্য",
    var isAdmin: Boolean = false,
    var joinedTimestamp: Long = System.currentTimeMillis(),
    
    // Status management (Active, Suspended, Revoked)
    var membershipStatus: String = STATUS_ACTIVE,
    var cancellationReason: String = "",
    var cancelledBy: String = "",
    var cancelledTimestamp: Long = 0L,
    
    // Official ID Card Verification
    var idCardStatus: String = ID_STATUS_PENDING,
    var idCardApprovedBy: String = "",
    var idCardApprovedTimestamp: Long = 0L,
    
    // District Admin Assignment (for 64 district seats)
    var assignedDistrictSeat: String = "",
    var qrToken: String = ""
) {
    companion object {
        const val STATUS_ACTIVE = "Active"
        const val STATUS_SUSPENDED = "Suspended"
        const val STATUS_REVOKED = "Revoked"

        const val ID_STATUS_PENDING = "Pending"
        const val ID_STATUS_APPROVED = "Approved"
        const val ID_STATUS_REJECTED = "Rejected"

        const val ROLE_SUPER_ADMIN = "Super Admin"
        const val ROLE_DISTRICT_ADMIN = "District Admin"
        const val ROLE_MEMBER = "সদস্য"
    }

    fun isSuperAdmin(): Boolean {
        val trimmedId = id.trim()
        val trimmedEmail = email.trim()
        val trimmedPhone = phone.trim()
        return trimmedId.equals("BSN 001", ignoreCase = true) ||
                trimmedId.equals("BSN-001", ignoreCase = true) ||
                trimmedPhone == "01989888856" ||
                trimmedEmail.equals("rrmrimonshikder@gmail.com", ignoreCase = true) ||
                trimmedEmail.equals("rrmtv994@gmail.com", ignoreCase = true) ||
                trimmedEmail.equals("bsnnewsnetwork@gmail.com", ignoreCase = true)
    }

    fun isDistrictAdmin(): Boolean {
        return (isAdmin || role == ROLE_DISTRICT_ADMIN) && assignedDistrictSeat.isNotBlank() && !isSuperAdmin()
    }

    fun isAnyAdmin(): Boolean {
        return isSuperAdmin() || isDistrictAdmin() || isAdmin
    }

    fun canManageDistrict(targetDistrict: String): Boolean {
        if (isSuperAdmin()) return true
        if (isDistrictAdmin() && assignedDistrictSeat.trim().equals(targetDistrict.trim(), ignoreCase = true)) {
            return true
        }
        return false
    }

    fun maskedEmail(): String {
        if (!email.contains("@")) return email
        val parts = email.split("@")
        val name = parts[0]
        val domain = parts[1]
        val maskedName = if (name.length <= 2) "${name.first()}***" else "${name.take(2)}***${name.takeLast(1)}"
        return "$maskedName@$domain"
    }

    fun maskedPhone(): String {
        if (phone.length <= 6) return phone
        val prefix = phone.take(3)
        val suffix = phone.takeLast(3)
        return "$prefix*****$suffix"
    }
}
