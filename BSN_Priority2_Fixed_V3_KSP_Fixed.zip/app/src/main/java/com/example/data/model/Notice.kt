package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notices")
data class Notice(
    @PrimaryKey
    var id: String = "",
    var title: String = "",
    var body: String = "",
    var priority: String = "সাধারণ",
    var issuedBy: String = "কেন্দ্রীয় সচিবালয়, BSN",
    var timestamp: Long = System.currentTimeMillis(),
    var isPinned: Boolean = false
)
