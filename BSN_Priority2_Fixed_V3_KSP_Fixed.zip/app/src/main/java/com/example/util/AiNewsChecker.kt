package com.example.util

data class AiCheckResult(
    val hasRisk: Boolean,
    val riskLevel: String, // "নিরাপদ", "সতর্কতা", "উচ্চ ঝুঁকি"
    val legalRiskNotes: List<String>,
    val grammarSpellingNotes: List<String>,
    val policyComplianceScore: Int // 0 to 100
)

object AiNewsChecker {

    fun analyzeReport(title: String, content: String): AiCheckResult {
        val legalRisks = mutableListOf<String>()
        val grammarNotes = mutableListOf<String>()

        val combinedText = "$title $content".trim()

        // 1. Defamation & Unsubstantiated Accusations Check
        val accusationKeywords = listOf("চোর", "ডাকাত", "দুর্নীতিবাজ", "খুনি", "প্রতারক", "ভণ্ড")
        val foundAccusations = accusationKeywords.filter { combinedText.contains(it) }
        if (foundAccusations.isNotEmpty()) {
            legalRisks.add("আইনি সতর্কতা (মানহানি ঝুঁকি): '${foundAccusations.joinToString(", ")}' শব্দগুলো আদালতের রায় বা মামলার এফআইআর ব্যতীত সরাসরি উল্লেখ করা মানহানিকর হতে পারে। 'অভিযুক্ত' বা 'অভিযোগ উঠেছে' শব্দ প্রয়োগ করুন।")
        }

        // 2. Sub judice & Contempt of Court Check
        val courtKeywords = listOf("আদালত", "বিচারক", "রায়", "মামলা", "রিমান্ড")
        if (courtKeywords.any { combinedText.contains(it) } && (combinedText.contains("পক্ষপাত") || combinedText.contains("অন্যায়"))) {
            legalRisks.add("আইনি সতর্কতা (আদালত অবমাননা ঝুঁকি): বিচারাধীন কোনো বিষয়ে আদালতের নিরপেক্ষতা প্রশ্নবিদ্ধ করা আদালত অবমাননার আওতাভুক্ত হতে পারে।")
        }

        // 3. Child/Minor & Victim Identity Protection
        val sensitiveKeywords = listOf("ধর্ষণ", "যৌন নিপীড়ন", "শিশু নির্যাতন", "নাবালিকা", "অপহরণ")
        if (sensitiveKeywords.any { combinedText.contains(it) }) {
            legalRisks.add("প্রেস কাউন্সিল আচরণবিধি: নারী ও শিশু নির্যাতন সংক্রান্ত সংবাদের ক্ষেত্রে ভিকটিমের পরিচয়, ছবি বা পিতা-মাতার নাম প্রকাশ আইনত দণ্ডনীয়।")
        }

        // 4. Source Verification
        val sourceIndicators = listOf("জানা গেছে", "সূত্রে প্রকাশ", "পুলিশ জানায়", "প্রত্যক্ষদর্শী", "প্রেস ক্লাব", "কর্মকর্তা")
        if (!sourceIndicators.any { combinedText.contains(it) }) {
            legalRisks.add("সাংবাদিকতা বস্তুনিষ্ঠতা: সংবাদে সুনির্দিষ্ট কোনো সূত্রের (যেমন: পুলিশ, প্রত্যক্ষদর্শী, স্থানীয় প্রশাসন) স্পষ্ট উল্লেখ পাওয়া যায়নি। সূত্র যোগ করুন।")
        }

        // 5. Bengali Spelling & Style checks
        if (combinedText.contains("দাবী")) {
            grammarNotes.add("বানান সংশোধন: 'দাবী' এর প্রমিত বাংলা বানান 'দাবি'।")
        }
        if (combinedText.contains("সরকারী")) {
            grammarNotes.add("বানান সংশোধন: 'সরকারী' এর প্রমিত বাংলা বানান 'সরকারি'।")
        }
        if (combinedText.contains("আইন শৃঙ্খলা")) {
            grammarNotes.add("বানান সংশোধন: 'আইন শৃঙ্খলা' হাইফেনসহ 'আইন-শৃঙ্খলা' লেখা শ্রেয়।")
        }
        if (combinedText.contains("স্বাক্ষী")) {
            grammarNotes.add("বানান সংশোধন: 'স্বাক্ষী' (সইকারী) এর পরিবর্তে ঘটনার ক্ষেত্রে 'সাক্ষী' ব্যবহার করুন।")
        }
        if (combinedText.contains("দুর্বৃত্তরা পালিয়ে যাওয়ার সময়")) {
            grammarNotes.add("বাক্য গঠন: 'পালিয়ে যাওয়ার সময়' পরিশীলিত বাংলায় 'পলায়নের সময়' লেখা যায়।")
        }

        if (title.length < 10) {
            grammarNotes.add("শিরোনাম শৈলী: সংবাদের শিরোনামটি সংক্ষিপ্ত, স্পষ্ট ও তথ্যবহুল হওয়া বাঞ্ছনীয় (কমপক্ষে ১০ অক্ষর)।")
        }
        if (content.length < 50) {
            grammarNotes.add("বিস্তারিত তথ্য: সংবাদের বিস্তারিত বিবরণ অত্যন্ত সংক্ষিপ্ত। ঘটনা, স্থান ও সময়ের পুঙ্খানুপুঙ্খ তথ্য দিন।")
        }

        val riskLevel = when {
            legalRisks.size >= 2 -> "উচ্চ ঝুঁকি"
            legalRisks.isNotEmpty() -> "সতর্কতা"
            else -> "নিরাপদ"
        }

        val score = (100 - (legalRisks.size * 25) - (grammarNotes.size * 5)).coerceIn(20, 100)

        return AiCheckResult(
            hasRisk = legalRisks.isNotEmpty(),
            riskLevel = riskLevel,
            legalRiskNotes = legalRisks,
            grammarSpellingNotes = grammarNotes,
            policyComplianceScore = score
        )
    }
}
