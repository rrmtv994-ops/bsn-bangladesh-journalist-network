package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.data.model.EmergencyAlert
import com.example.data.model.Notice

object NotificationHelper {
    const val CHANNEL_HIGH_ALERT = "bsn_high_alert_channel"
    const val CHANNEL_NOTICES = "bsn_notices_channel"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val alertChannel = NotificationChannel(
                CHANNEL_HIGH_ALERT,
                "BSN জরুরি বিপদ সংকেত (High Alert)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "সাংবাদিক ও সদস্যদের ওপর হামলা ও জরুরি বিপদের সার্বক্ষণিক সংকেত"
                enableVibration(true)
            }

            val noticeChannel = NotificationChannel(
                CHANNEL_NOTICES,
                "BSN সাধারণ নোটিশ ও সংবাদ",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "কেন্দ্রীয় নোটিশ ও সাংগঠনিক তথ্য প্রবাহ"
            }

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(alertChannel)
            manager.createNotificationChannel(noticeChannel)
        }
    }

    fun showEmergencyAlertNotification(context: Context, alert: EmergencyAlert) {
        try {
            val builder = NotificationCompat.Builder(context, CHANNEL_HIGH_ALERT)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("🚨 BSN HIGH ALERT: ${alert.alertType}")
                .setContentText("${alert.reporterName}: ${alert.spotAddress}, ${alert.district}")
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .bigText("বিপদ: ${alert.alertType}\nস্থান: ${alert.spotAddress}, ${alert.upazila}, ${alert.district}\nবর্ণনা: ${alert.description}\nফোন: ${alert.reporterPhone}")
                )
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setAutoCancel(true)

            NotificationManagerCompat.from(context).notify(alert.id.hashCode(), builder.build())
        } catch (_: SecurityException) {
        }
    }

    fun showNoticeNotification(context: Context, notice: Notice) {
        try {
            val builder = NotificationCompat.Builder(context, CHANNEL_NOTICES)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(notice.title)
                .setContentText(notice.body)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)

            NotificationManagerCompat.from(context).notify(notice.id.hashCode(), builder.build())
        } catch (_: SecurityException) {
        }
    }
}
