package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Member
import com.example.ui.components.BSNBottomBar
import com.example.ui.components.BSNScreen
import com.example.ui.components.BSNTopBar
import com.example.ui.components.DigitalIdCardDialog
import com.example.ui.components.QuickSosDialog
import com.example.ui.components.RegisterMemberDialog
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HighAlertScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MembersScreen
import com.example.ui.screens.NewsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.theme.BSNTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            BSNTheme {
                BSNApp()
            }
        }
    }
}

@Composable
fun BSNApp() {
    val context = LocalContext.current
    val app = BSNApplication.instance
    val repository = app.repository
    val scope = rememberCoroutineScope()

    // Collect data streams from Room + Firestore
    val members by repository.allMembers.collectAsStateWithLifecycle(initialValue = emptyList())
    val activeAlerts by repository.activeAlerts.collectAsStateWithLifecycle(initialValue = emptyList())
    val allAlerts by repository.allAlerts.collectAsStateWithLifecycle(initialValue = emptyList())
    val newsList by repository.allNews.collectAsStateWithLifecycle(initialValue = emptyList())
    val noticesList by repository.allNotices.collectAsStateWithLifecycle(initialValue = emptyList())
    val auditLogs by repository.allAuditLogs.collectAsStateWithLifecycle(initialValue = emptyList())
    val districtSeats by repository.allDistrictSeats.collectAsStateWithLifecycle(initialValue = emptyList())

    // Default Founder & Super Admin (BSN 001)
    val defaultFounder = remember {
        Member(
            id = "BSN 001",
            fullName = "মোঃ রিমন শিকদার",
            phone = "01989888856",
            email = "rrmrimonshikder@gmail.com",
            profession = "প্রতিষ্ঠাতা ও কর্ণধার",
            organization = "বাংলাদেশ সাংবাদিক নেটওয়ার্ক (BSN)",
            division = "ঢাকা",
            district = "ঢাকা",
            upazila = "ঢাকা সদর",
            address = "ঢাকা, বাংলাদেশ",
            bloodGroup = "O+",
            bio = "BSN 001 — প্রতিষ্ঠাতা ও কর্ণধার। বাংলাদেশ সাংবাদিক নেটওয়ার্ক (BSN) এর সর্বোচ্চ নীতিনির্ধারণী ও প্রধান নিয়ন্ত্রক।",
            emergencyContact = "01989888856",
            isVerified = true,
            isExecutive = true,
            isAdmin = true,
            role = "Super Admin",
            membershipStatus = Member.STATUS_ACTIVE,
            idCardStatus = Member.ID_STATUS_APPROVED,
            qrToken = "BSN-001-FOUNDER-VERIFIED"
        )
    }

    var currentMember by remember { mutableStateOf(defaultFounder) }
    var isLoggedIn by remember { mutableStateOf(true) }
    var isAdminAppMode by remember { mutableStateOf(false) }

    // Navigation and dialog states
    var currentScreen by remember { mutableStateOf(BSNScreen.HOME) }
    var showSosDialog by remember { mutableStateOf(false) }
    var showRegisterDialog by remember { mutableStateOf(false) }
    var registerInitialEmail by remember { mutableStateOf("") }
    var registerInitialName by remember { mutableStateOf("") }
    var suggestedNextBsnId by remember { mutableStateOf("BSN 006") }
    var selectedMemberForCard by remember { mutableStateOf<Member?>(null) }

    // Handle Back Button correctly for nested dialogs & secondary screens
    BackHandler(
        enabled = selectedMemberForCard != null || showSosDialog || showRegisterDialog || currentScreen != BSNScreen.HOME
    ) {
        when {
            selectedMemberForCard != null -> selectedMemberForCard = null
            showSosDialog -> showSosDialog = false
            showRegisterDialog -> showRegisterDialog = false
            currentScreen != BSNScreen.HOME -> currentScreen = BSNScreen.HOME
        }
    }

    if (!isLoggedIn) {
        LoginScreen(
            repository = repository,
            onLoginSuccess = { loggedInMember ->
                currentMember = loggedInMember
                isLoggedIn = true
                currentScreen = BSNScreen.HOME
            },
            onNeedsRegistration = { googleEmail, googleName ->
                registerInitialEmail = googleEmail
                registerInitialName = googleName
                scope.launch {
                    suggestedNextBsnId = repository.generateNextBsnId()
                    showRegisterDialog = true
                }
            }
        )
    } else {
        Scaffold(
            topBar = {
                BSNTopBar(
                    activeAlertsCount = activeAlerts.size,
                    isAdminAppMode = isAdminAppMode,
                    onToggleAppMode = {
                        isAdminAppMode = !isAdminAppMode
                        if (isAdminAppMode) {
                            currentScreen = BSNScreen.ADMIN
                        } else {
                            currentScreen = BSNScreen.HOME
                        }
                    },
                    onAlertBadgeClick = { currentScreen = BSNScreen.HIGH_ALERT },
                    onEmergencyCallClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:999"))
                        context.startActivity(intent)
                    }
                )
            },
            bottomBar = {
                BSNBottomBar(
                    currentScreen = currentScreen,
                    onScreenSelected = { currentScreen = it },
                    activeAlertsCount = activeAlerts.size
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    BSNScreen.HOME -> {
                        HomeScreen(
                            currentMember = currentMember,
                            activeAlerts = activeAlerts,
                            membersCount = members.size,
                            latestNews = newsList,
                            latestNotices = noticesList,
                            onTriggerSos = { showSosDialog = true },
                            onNavigate = { currentScreen = it },
                            onViewIdCard = { selectedMemberForCard = currentMember },
                            onViewAlertDetails = { currentScreen = BSNScreen.HIGH_ALERT }
                        )
                    }

                    BSNScreen.MEMBERS -> {
                        MembersScreen(
                            members = members,
                            onSelectMember = { member -> selectedMemberForCard = member },
                            onRegisterNewMemberClick = {
                                registerInitialEmail = ""
                                registerInitialName = ""
                                scope.launch {
                                    suggestedNextBsnId = repository.generateNextBsnId()
                                    showRegisterDialog = true
                                }
                            }
                        )
                    }

                    BSNScreen.HIGH_ALERT -> {
                        HighAlertScreen(
                            currentMember = currentMember,
                            alerts = allAlerts,
                            onTriggerSos = { showSosDialog = true },
                            onUpdateStatus = { alertId, status ->
                                scope.launch {
                                    repository.updateAlertStatus(alertId, status)
                                }
                            },
                            onCancelAlert = { alertId, reason ->
                                scope.launch {
                                    repository.cancelAlert(alertId, reason, currentMember)
                                }
                            }
                        )
                    }

                    BSNScreen.NEWS -> {
                        NewsScreen(
                            newsList = newsList,
                            noticesList = noticesList,
                            currentMember = currentMember,
                            onSubmitNews = { article ->
                                scope.launch {
                                    repository.submitNews(article)
                                    val toastMsg = if (currentMember.isSuperAdmin()) {
                                        "সংবাদ সরাসরি অনুমোদিত ও প্রকাশিত হয়েছে"
                                    } else {
                                        "সংবাদ সফলভাবে জমা হয়েছে (BSN 001 এর অনুমোদনের পর প্রকাশিত হবে)"
                                    }
                                    Toast.makeText(context, toastMsg, Toast.LENGTH_LONG).show()
                                }
                            }
                        )
                    }

                    BSNScreen.CHAT -> {
                        ChatScreen(
                            currentMember = currentMember,
                            allMembers = members,
                            repository = repository
                        )
                    }

                    BSNScreen.ADMIN -> {
                        AdminScreen(
                            currentMember = currentMember,
                            members = members,
                            activeAlerts = activeAlerts,
                            allAlerts = allAlerts,
                            allNews = newsList,
                            notices = noticesList,
                            auditLogs = auditLogs,
                            districtSeats = districtSeats,
                            onAppointDistrictAdmin = { districtId, member ->
                                scope.launch {
                                    repository.appointDistrictAdmin(districtId, member, currentMember)
                                    Toast.makeText(context, "জেলা এডমিন নিয়োগ সফল", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onSuspendDistrictAdmin = { districtId, reason ->
                                scope.launch {
                                    repository.suspendDistrictAdmin(districtId, reason, currentMember)
                                    Toast.makeText(context, "জেলা এডমিন স্থগিত করা হয়েছে", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onRemoveDistrictAdmin = { districtId ->
                                scope.launch {
                                    repository.removeDistrictAdmin(districtId, currentMember)
                                    Toast.makeText(context, "জেলা এডমিন পদ শূন্য করা হয়েছে", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onCancelMemberWithReason = { memberId, reason ->
                                scope.launch {
                                    val success = repository.cancelMembership(memberId, reason, currentMember)
                                    Toast.makeText(
                                        context,
                                        if (success) "সদস্যপদ বাতিল করা হয়েছে" else "বাতিল করতে ব্যর্থ বা অনুমতি নেই",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            onApproveMember = { memberId ->
                                scope.launch {
                                    repository.approveMember(memberId, currentMember)
                                    Toast.makeText(context, "সদস্য ভেরিফিকেশন সফল", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onDeleteMember = { memberId ->
                                scope.launch {
                                    val success = repository.deleteMember(memberId, currentMember)
                                    Toast.makeText(
                                        context,
                                        if (success) "সদস্য ফায়ারস্টোর ও অ্যাপ থেকে সফলভাবে অপসারিত হয়েছে"
                                        else "অপসারণে ব্যর্থ বা অনুমতি নেই",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            },
                            onPromoteToAdmin = { memberId ->
                                scope.launch {
                                    val success = repository.promoteToAdmin(memberId, currentMember)
                                    Toast.makeText(
                                        context,
                                        if (success) "সদস্যকে এডমিন হিসেবে নিয়োগ দেওয়া হয়েছে"
                                        else "অনুমতি নেই",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            onRevokeAdmin = { memberId ->
                                scope.launch {
                                    val success = repository.revokeAdmin(memberId, currentMember)
                                    Toast.makeText(
                                        context,
                                        if (success) "এডমিন ক্ষমতা প্রত্যাহার করা হয়েছে"
                                        else "অনুমতি নেই",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            onRefreshMembers = {
                                scope.launch {
                                    repository.refreshMembersFromFirestore()
                                    Toast.makeText(context, "সার্ভার থেকে সদস্য তালিকা রিফ্রেশ করা হয়েছে", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onApproveNews = { newsId ->
                                scope.launch {
                                    repository.approveNews(newsId, currentMember)
                                    Toast.makeText(context, "সংবাদ অনুমোদিত ও প্রকাশিত হয়েছে", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onRejectNews = { newsId, reason ->
                                scope.launch {
                                    repository.rejectNews(newsId, reason, currentMember)
                                }
                            },
                            onCancelAlert = { alertId, reason ->
                                scope.launch {
                                    repository.cancelAlert(alertId, reason, currentMember)
                                }
                            },
                            onPublishNotice = { notice ->
                                scope.launch {
                                    repository.publishNotice(notice, currentMember)
                                }
                            },
                            onUpdateAlertStatus = { alertId, status ->
                                scope.launch {
                                    repository.updateAlertStatus(alertId, status)
                                }
                            },
                            onViewIdCard = { member ->
                                selectedMemberForCard = member
                            },
                            onAddNewMember = {
                                registerInitialEmail = ""
                                registerInitialName = ""
                                scope.launch {
                                    suggestedNextBsnId = repository.generateNextBsnId()
                                    showRegisterDialog = true
                                }
                            }
                        )
                    }

                    BSNScreen.PROFILE -> {
                        ProfileScreen(
                            currentMember = currentMember,
                            onUpdateMember = { updated ->
                                currentMember = updated
                                scope.launch {
                                    repository.updateMember(updated)
                                }
                            },
                            onViewIdCard = { member ->
                                selectedMemberForCard = member
                            },
                            onTriggerSos = {
                                showSosDialog = true
                            },
                            onLogout = {
                                isLoggedIn = false
                                Toast.makeText(context, "লগআউট সম্পন্ন হয়েছে", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }

                // Quick SOS Dialog (15 Danger Types)
                if (showSosDialog) {
                    QuickSosDialog(
                        currentMember = currentMember,
                        onDismiss = { showSosDialog = false },
                        onSendAlert = { alert ->
                            scope.launch {
                                repository.dispatchHighAlert(alert)
                                showSosDialog = false
                                currentScreen = BSNScreen.HIGH_ALERT
                                Toast.makeText(
                                    context,
                                    "🚨 জরুরি বিপদ সংকেত সার্ভারে সম্প্রচারিত হয়েছে!",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    )
                }

                // Register Member Dialog (Sequential BSN ID, Duplicate Gmail Guard)
                if (showRegisterDialog) {
                    RegisterMemberDialog(
                        initialEmail = registerInitialEmail,
                        initialName = registerInitialName,
                        suggestedId = suggestedNextBsnId,
                        existingMembers = members,
                        onDismiss = { showRegisterDialog = false },
                        onRegister = { newMember ->
                            scope.launch {
                                repository.registerMember(newMember)
                                currentMember = newMember
                                isLoggedIn = true
                                showRegisterDialog = false
                                Toast.makeText(
                                    context,
                                    "নিবন্ধন সম্পন্ন! আইডি: ${newMember.id} BSN সার্ভারে সংরক্ষিত হয়েছে।",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    )
                }

                // Digital Press ID Card Modal Dialog
                selectedMemberForCard?.let { member ->
                    DigitalIdCardDialog(
                        member = member,
                        onDismiss = { selectedMemberForCard = null }
                    )
                }
            }
        }
    }
}
