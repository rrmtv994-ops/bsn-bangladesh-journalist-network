package com.example

import android.app.Application
import com.example.data.local.BSNDatabase
import com.example.data.repository.BSNRepository
import com.example.util.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class BSNApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val database by lazy { BSNDatabase.getDatabase(this) }
    val repository by lazy { BSNRepository(database, this) }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Initialize Notification Channels
        NotificationHelper.createNotificationChannels(this)

        // Prepopulate seed data and sync with Firestore in background
        applicationScope.launch(Dispatchers.IO) {
            repository.seedInitialDataIfEmpty()
        }
    }

    companion object {
        lateinit var instance: BSNApplication
            private set
    }
}
