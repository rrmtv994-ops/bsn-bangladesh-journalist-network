package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.GpsNotFixed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.EmergencyAlert
import com.example.data.model.LocationData
import com.example.data.model.Member
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert
import com.example.util.BSNLocationResult
import com.example.util.LocationHelper
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun QuickSosDialog(
    currentMember: Member,
    onDismiss: () -> Unit,
    onSendAlert: (EmergencyAlert) -> Unit
) {
    val context = LocalContext.current

    var selectedDangerType by remember { mutableStateOf(LocationData.dangerTypes[1]) }
    var dangerDropdownExpanded by remember { mutableStateOf(false) }

    var description by remember { mutableStateOf(LocationData.quickDescriptions[0]) }
    var spotAddress by remember { mutableStateOf("${currentMember.upazila}, ${currentMember.district}") }
    var division by remember { mutableStateOf(currentMember.division.ifBlank { "বরিশাল" }) }
    var district by remember { mutableStateOf(currentMember.district.ifBlank { "পটুয়াখালী" }) }
    var upazila by remember { mutableStateOf(currentMember.upazila.ifBlank { "রাঙ্গাবালী" }) }

    var latitude by remember { mutableDoubleStateOf(21.9167) }
    var longitude by remember { mutableDoubleStateOf(90.4667) }
    var accuracy by remember { mutableFloatStateOf(10f) }
    var isLocating by remember { mutableStateOf(false) }
    var locationFetched by remember { mutableStateOf(false) }

    val locationHelper = remember { LocationHelper(context) }

    // Runtime Permission for Location
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[android.Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[android.Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            isLocating = true
        }
    }

    LaunchedEffect(isLocating) {
        if (isLocating) {
            val result: BSNLocationResult? = locationHelper.getCurrentLocation()
            if (result != null) {
                latitude = result.latitude
                longitude = result.longitude
                accuracy = result.accuracy
                locationFetched = true
            }
            isLocating = false
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 680.dp)
                .testTag("quick_sos_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(2.dp, BSNRedAlert)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Header (Red Emergency)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BSNRedAlert)
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = BSNRedAlert,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "🚨 BSN HIGH ALERT সংকেত প্রেরণ",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "তাৎক্ষণিক অবস্থান ও বার্তা নেটওয়ার্কে সম্প্রচারিত হবে",
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }

                Column(modifier = Modifier.padding(16.dp)) {
                    // Reporter Brief Card
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFFBF4F4),
                        border = BorderStroke(1.dp, BSNRedAlert.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "সংকেত প্রেরক: ${currentMember.fullName}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = BSNGreenDark
                                )
                                Text(
                                    text = "পদবি: ${currentMember.profession} • আইডি: ${currentMember.id}",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                                Text(
                                    text = "মোবাইল: ${currentMember.phone}",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }

                            // Emergency 999 Direct Call
                            Button(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:999"))
                                    context.startActivity(intent)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("৯৯৯", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Danger Category Selector
                    Text(
                        text = "বিপদের ধরন নির্ধারণ করুন:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF191C1A)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    ExposedDropdownMenuBox(
                        expanded = dangerDropdownExpanded,
                        onExpandedChange = { dangerDropdownExpanded = !dangerDropdownExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedDangerType,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dangerDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                                .testTag("danger_type_dropdown"),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BSNRedAlert,
                                unfocusedBorderColor = Color.LightGray
                            )
                        )

                        ExposedDropdownMenu(
                            expanded = dangerDropdownExpanded,
                            onDismissRequest = { dangerDropdownExpanded = false }
                        ) {
                            LocationData.dangerTypes.forEach { danger ->
                                DropdownMenuItem(
                                    text = { Text(danger, fontSize = 13.sp) },
                                    onClick = {
                                        selectedDangerType = danger
                                        dangerDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Descriptions Chips
                    Text(
                        text = "দ্রুত বার্তা নির্বাচন:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.DarkGray
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        LocationData.quickDescriptions.take(3).forEach { quick ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (description == quick) BSNRedAlert.copy(alpha = 0.15f) else Color(0xFFF0F4F1),
                                border = BorderStroke(
                                    1.dp,
                                    if (description == quick) BSNRedAlert else Color.LightGray
                                ),
                                modifier = Modifier.clickable { description = quick }
                            ) {
                                Text(
                                    text = quick.take(24) + "...",
                                    fontSize = 11.sp,
                                    color = if (description == quick) BSNRedAlert else Color.DarkGray,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Detailed Description
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("ঘটনার সংক্ষিপ্ত বিবরণ ও সহায়তা বার্তা") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(88.dp)
                            .testTag("sos_description_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Incident Location details
                    OutlinedTextField(
                        value = spotAddress,
                        onValueChange = { spotAddress = it },
                        label = { Text("ঘটনাস্থলের ঠিকানা ও পরিচিতি") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sos_spot_address_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // GPS Location Card
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = if (locationFetched) Color(0xFFE8F5E9) else Color(0xFFFFF8E1),
                        border = BorderStroke(1.dp, if (locationFetched) BSNGreenPrimary else Color(0xFFFFB300))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (locationFetched) Icons.Default.GpsFixed else Icons.Default.GpsNotFixed,
                                        contentDescription = null,
                                        tint = if (locationFetched) BSNGreenPrimary else Color(0xFFFF8F00),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (locationFetched) "লাইভ GPS অবস্থান সংগৃহীত" else "GPS অবস্থান যাচাই করা হয়নি",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (locationFetched) BSNGreenDark else Color(0xFF795548)
                                    )
                                }
                                Text(
                                    text = "অক্ষাংশ: %.4f • দ্রাঘিমাংশ: %.4f".format(latitude, longitude),
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }

                            Button(
                                onClick = {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            android.Manifest.permission.ACCESS_FINE_LOCATION,
                                            android.Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                    isLocating = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                                shape = RoundedCornerShape(8.dp),
                                enabled = !isLocating
                            ) {
                                if (isLocating) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                } else {
                                    Text("GPS আপডেট", fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Broadcast Button
                    Button(
                        onClick = {
                            if (description.isBlank()) {
                                Toast.makeText(context, "অনুগ্রহ করে বিপদের বিবরণ লিখুন", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val alert = EmergencyAlert(
                                id = "ALT-" + UUID.randomUUID().toString().take(6).uppercase(),
                                alertType = selectedDangerType,
                                description = description.trim(),
                                reporterName = currentMember.fullName,
                                reporterPhone = currentMember.phone,
                                reporterRole = currentMember.profession,
                                latitude = latitude,
                                longitude = longitude,
                                locationAccuracy = accuracy,
                                division = division,
                                district = district,
                                upazila = upazila,
                                spotAddress = spotAddress.trim(),
                                googleMapsUrl = "https://maps.google.com/?q=$latitude,$longitude",
                                timestamp = System.currentTimeMillis(),
                                status = EmergencyAlert.STATUS_NEW
                            )

                            onSendAlert(alert)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("send_high_alert_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "🚨 বিপদ সংকেত এখনই সম্প্রচার করুন",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
