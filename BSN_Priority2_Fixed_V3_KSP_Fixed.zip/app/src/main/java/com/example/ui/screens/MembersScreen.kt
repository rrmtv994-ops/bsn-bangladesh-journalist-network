package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LocationData
import com.example.data.model.Member
import com.example.ui.theme.BSNGold
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MembersScreen(
    members: List<Member>,
    onSelectMember: (Member) -> Unit,
    onRegisterNewMemberClick: () -> Unit
) {
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var selectedDivision by remember { mutableStateOf("সকল বিভাগ") }
    var selectedDistrict by remember { mutableStateOf("সকল জেলা") }
    var selectedProfession by remember { mutableStateOf("সকল পেশা") }

    var divisionExpanded by remember { mutableStateOf(false) }
    var districtExpanded by remember { mutableStateOf(false) }

    val professions = listOf("সকল পেশা", "সাংবাদিক", "ফটোসাংবাদিক", "ব্যুরো প্রধান", "সম্পাদক", "প্রশাসন", "আইনশৃঙ্খলা")

    val divisionOptions = listOf("সকল বিভাগ") + LocationData.divisions
    val districtOptions = if (selectedDivision == "সকল বিভাগ") {
        listOf("সকল জেলা")
    } else {
        listOf("সকল জেলা") + LocationData.getDistrictsForDivision(selectedDivision)
    }

    val filteredMembers = remember(members, searchQuery, selectedDivision, selectedDistrict, selectedProfession) {
        members.filter { member ->
            val matchSearch = searchQuery.isBlank() ||
                member.fullName.contains(searchQuery, ignoreCase = true) ||
                member.organization.contains(searchQuery, ignoreCase = true) ||
                member.phone.contains(searchQuery) ||
                member.upazila.contains(searchQuery, ignoreCase = true) ||
                member.district.contains(searchQuery, ignoreCase = true)

            val matchDivision = selectedDivision == "সকল বিভাগ" || member.division == selectedDivision
            val matchDistrict = selectedDistrict == "সকল জেলা" || member.district == selectedDistrict
            val matchProfession = selectedProfession == "সকল পেশা" || member.profession.contains(selectedProfession)

            matchSearch && matchDivision && matchDistrict && matchProfession
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("members_screen_content"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "সদস্য ডিরেক্টরি",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Text(
                        text = "মোট নিবন্ধিত সদস্য: ${members.size} জন",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                Button(
                    onClick = onRegisterNewMemberClick,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                    contentPadding = ButtonDefaults.TextButtonContentPadding,
                    modifier = Modifier.testTag("register_new_member_button")
                ) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("নতুন নিবন্ধন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("member_search_input"),
                placeholder = { Text("নাম, ফোন, গণমাধ্যম বা উপজেলা খুঁজুন...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BSNGreenPrimary) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BSNGreenPrimary,
                    unfocusedBorderColor = Color.Gray.copy(alpha = 0.4f)
                )
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExposedDropdownMenuBox(
                    expanded = divisionExpanded,
                    onExpandedChange = { divisionExpanded = !divisionExpanded },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = selectedDivision,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("বিভাগ", fontSize = 11.sp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = divisionExpanded) },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                            .fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BSNGreenPrimary,
                            unfocusedBorderColor = Color.Gray.copy(alpha = 0.4f)
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = divisionExpanded,
                        onDismissRequest = { divisionExpanded = false }
                    ) {
                        divisionOptions.forEach { div ->
                            DropdownMenuItem(
                                text = { Text(div, fontSize = 12.sp) },
                                onClick = {
                                    selectedDivision = div
                                    selectedDistrict = "সকল জেলা"
                                    divisionExpanded = false
                                }
                            )
                        }
                    }
                }

                ExposedDropdownMenuBox(
                    expanded = districtExpanded,
                    onExpandedChange = { districtExpanded = !districtExpanded },
                    modifier = Modifier.weight(1f)
                ) {
                    OutlinedTextField(
                        value = selectedDistrict,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("জেলা", fontSize = 11.sp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = districtExpanded) },
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                            .fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BSNGreenPrimary,
                            unfocusedBorderColor = Color.Gray.copy(alpha = 0.4f)
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = districtExpanded,
                        onDismissRequest = { districtExpanded = false }
                    ) {
                        districtOptions.forEach { dist ->
                            DropdownMenuItem(
                                text = { Text(dist, fontSize = 12.sp) },
                                onClick = {
                                    selectedDistrict = dist
                                    districtExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        item {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                professions.forEach { prof ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (selectedProfession == prof) BSNGreenPrimary else Color.White,
                        border = BorderStroke(1.dp, if (selectedProfession == prof) BSNGreenPrimary else Color(0xFFD0D7D2)),
                        modifier = Modifier.clickable { selectedProfession = prof }
                    ) {
                        Text(
                            text = prof,
                            fontSize = 11.sp,
                            fontWeight = if (selectedProfession == prof) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedProfession == prof) Color.White else Color(0xFF2E3330),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ফলাফল: ${filteredMembers.size} জন সদস্য পাওয়া গেছে",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.DarkGray
                )
                if (selectedDivision != "সকল বিভাগ" || selectedDistrict != "সকল জেলা" || selectedProfession != "সকল পেশা" || searchQuery.isNotBlank()) {
                    Text(
                        text = "রিসেট করুন",
                        fontSize = 11.sp,
                        color = BSNRedAlert,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            searchQuery = ""
                            selectedDivision = "সকল বিভাগ"
                            selectedDistrict = "সকল জেলা"
                            selectedProfession = "সকল পেশা"
                        }
                    )
                }
            }
        }

        if (filteredMembers.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "কোনো সদস্য পাওয়া যায়নি",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "অনুসন্ধানের শর্ত পরিবর্তন করে দেখুন",
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                    }
                }
            }
        } else {
            items(filteredMembers, key = { it.id }) { member ->
                MemberCardItem(
                    member = member,
                    onClick = { onSelectMember(member) },
                    onCall = {
                        val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                            data = Uri.parse("tel:${member.phone}")
                        }
                        context.startActivity(dialIntent)
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun MemberCardItem(
    member: Member,
    onClick: () -> Unit,
    onCall: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(
            1.dp,
            if (member.isExecutive) BSNGold.copy(alpha = 0.8f) else Color(0xFFEEEEEE)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        if (member.isExecutive) BSNGold.copy(alpha = 0.2f) else BSNGreenPrimary.copy(alpha = 0.12f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = member.fullName.take(2),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (member.isExecutive) Color(0xFF7A5900) else BSNGreenDark
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = member.fullName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                    if (member.isVerified) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = "Verified",
                            tint = BSNGreenPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    if (member.isExecutive) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = BSNGold.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "কর্ণধার",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF7A5900),
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }

                Text(
                    text = member.profession + if (member.organization.isNotBlank()) " • ${member.organization}" else "",
                    fontSize = 12.sp,
                    color = BSNGreenDark,
                    fontWeight = FontWeight.Medium
                )

                Text(
                    text = "এলাকা: ${member.upazila}, ${member.district} • রক্ত: ${member.bloodGroup}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            IconButton(
                onClick = onCall,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE8F5E9))
            ) {
                Icon(
                    Icons.Default.Call,
                    contentDescription = "Call Member",
                    tint = BSNGreenPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            IconButton(
                onClick = onClick,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFF8E1))
            ) {
                Icon(
                    Icons.Default.Badge,
                    contentDescription = "View ID Card",
                    tint = BSNGold,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
