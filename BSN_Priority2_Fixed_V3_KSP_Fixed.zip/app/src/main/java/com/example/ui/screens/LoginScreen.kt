package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import com.example.R
import com.example.data.model.Member
import com.example.data.repository.BSNRepository
import com.example.ui.theme.BSNGold
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    repository: BSNRepository,
    onLoginSuccess: (Member) -> Unit,
    onNeedsRegistration: (googleEmail: String, googleName: String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }
    var showDirectEmailLogin by remember { mutableStateOf(false) }
    var manualEmail by remember { mutableStateOf("") }
    var manualName by remember { mutableStateOf("") }
    var manualPassword by remember { mutableStateOf("") }
    val firebaseAuth = remember { FirebaseAuth.getInstance() }

    val credentialManager = remember { CredentialManager.create(context) }

    suspend fun handleEmailAuth(email: String, displayName: String) {
        val authenticatedEmail = firebaseAuth.currentUser?.email
        if (authenticatedEmail.isNullOrBlank() || !authenticatedEmail.equals(email, ignoreCase = true)) {
            Toast.makeText(context, "আগে Firebase Authentication সম্পন্ন করুন", Toast.LENGTH_LONG).show()
            return
        }
        isLoading = true
        try {
            val existingMember = repository.getMemberByEmail(authenticatedEmail)
            if (existingMember != null) {
                Toast.makeText(context, "স্বাগতম, ${existingMember.fullName}! (${existingMember.id})", Toast.LENGTH_SHORT).show()
                onLoginSuccess(existingMember)
            } else {
                onNeedsRegistration(authenticatedEmail, displayName)
            }
        } catch (e: Exception) {
            Toast.makeText(context, "সদস্য তথ্য যাচাই করা যায়নি: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        } finally {
            isLoading = false
        }
    }

    fun initiateGoogleSignIn() {
        scope.launch {
            isLoading = true
            try {
                val googleIdOption = GetSignInWithGoogleOption.Builder(
                    serverClientId = "320796438662-pft9mntftp3j53n9mf7cq5vrqr2k59ab.apps.googleusercontent.com"
                ).build()
                val request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build()
                val result = credentialManager.getCredential(request = request, context = context as Activity)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleToken = GoogleIdTokenCredential.createFrom(credential.data)
                    val firebaseCredential = GoogleAuthProvider.getCredential(googleToken.idToken, null)
                    val authResult = firebaseAuth.signInWithCredential(firebaseCredential).await()
                    val user = authResult.user ?: throw IllegalStateException("Firebase user পাওয়া যায়নি")
                    handleEmailAuth(user.email ?: googleToken.id, user.displayName ?: googleToken.displayName ?: "সাংবাদিক সদস্য")
                } else {
                    Toast.makeText(context, "Google credential পাওয়া যায়নি", Toast.LENGTH_LONG).show()
                    isLoading = false
                }
            } catch (e: Exception) {
                isLoading = false
                Toast.makeText(context, "Google/Firebase সাইন-ইন ব্যর্থ: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun initiateEmailSignIn() {
        scope.launch {
            if (!manualEmail.contains("@") || manualPassword.length < 6) {
                Toast.makeText(context, "সঠিক ইমেইল ও কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন", Toast.LENGTH_LONG).show()
                return@launch
            }
            isLoading = true
            try {
                val result = try {
                    firebaseAuth.signInWithEmailAndPassword(manualEmail.trim(), manualPassword).await()
                } catch (signInError: FirebaseAuthInvalidUserException) {
                    firebaseAuth.createUserWithEmailAndPassword(manualEmail.trim(), manualPassword).await()
                } catch (signInError: com.google.firebase.auth.FirebaseAuthException) {
                    if (signInError.errorCode == "ERROR_USER_NOT_FOUND") {
                        firebaseAuth.createUserWithEmailAndPassword(manualEmail.trim(), manualPassword).await()
                    } else throw signInError
                }
                val user = result.user ?: firebaseAuth.currentUser ?: throw IllegalStateException("Firebase user পাওয়া যায়নি")
                handleEmailAuth(user.email ?: manualEmail.trim(), user.displayName ?: manualName.ifBlank { "সাংবাদিক সদস্য" })
            } catch (e: Exception) {
                isLoading = false
                Toast.makeText(context, "ইমেইল Authentication ব্যর্থ: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0F3B20),
                        BSNGreenDark,
                        Color(0xFF051D10)
                    )
                )
            )
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .testTag("bsn_login_card"),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // BSN Logo
                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    border = BorderStroke(2.dp, BSNGold),
                    modifier = Modifier.size(80.dp),
                    shadowElevation = 4.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Image(
                            painter = painterResource(id = R.drawable.bsn_logo),
                            contentDescription = "BSN Logo",
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "বাংলাদেশ সাংবাদিক নেটওয়ার্ক",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = BSNGreenDark,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "BANGLADESH JOURNALIST NETWORK (BSN)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = BSNGold,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F8F4),
                    border = BorderStroke(1.dp, BSNGreenPrimary.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = "🔒 জাতীয় সমন্বয় ও জরুরি HIGH ALERT বিপদ সংকেত প্ল্যাটফর্ম",
                        fontSize = 11.sp,
                        color = BSNGreenDark,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Super Admin Info Banner
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFFFBEA),
                    border = BorderStroke(1.dp, BSNGold.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = BSNGold,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Founder & Super Admin: মোঃ রিমন শিকদার",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF6B4E00)
                            )
                            Text(
                                text = "BSN ID: BSN 001 • rrmrimonshikder@gmail.com",
                                fontSize = 10.sp,
                                color = Color(0xFF7A5900)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                if (isLoading) {
                    CircularProgressIndicator(color = BSNGreenPrimary)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("সার্ভার যাচাইকরণ চলছে...", fontSize = 12.sp, color = Color.Gray)
                } else {
                    // Google Sign-In Main Button
                    Button(
                        onClick = { initiateGoogleSignIn() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BSNGreenDark,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("google_signin_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Login,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "গুগল দিয়ে সাইন-ইন করুন (Google Sign-In)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Direct Founder One-Click Login for মোঃ রিমন শিকদার (BSN 001)
                    OutlinedButton(
                        onClick = { initiateGoogleSignIn() },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.5.dp, BSNGold),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = BSNGreenDark),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("founder_login_button")
                    ) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = BSNGold, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "প্রতিষ্ঠাতা প্রবেশ (BSN 001 - মোঃ রিমন শিকদার)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Email / Account entry option for testing 2 phones / 2 accounts
                    if (!showDirectEmailLogin) {
                        TextButton(
                            onClick = { showDirectEmailLogin = true }
                        ) {
                            Text(
                                text = "অন্যান্য Gmail / সদস্য একাউন্ট দিয়ে প্রবেশ",
                                fontSize = 12.sp,
                                color = BSNGreenPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    } else {
                        HorizontalDivider(color = Color(0xFFEEEEEE))
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Gmail আইডি বা ইমেইল লিখুন:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.DarkGray,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = manualEmail,
                            onValueChange = { manualEmail = it },
                            placeholder = { Text("example@gmail.com", fontSize = 13.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("manual_email_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = manualPassword,
                            onValueChange = { manualPassword = it },
                            placeholder = { Text("পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)", fontSize = 13.sp) },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = manualName,
                            onValueChange = { manualName = it },
                            placeholder = { Text("আপনার নাম (নতুন সদস্যের ক্ষেত্রে)", fontSize = 13.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("manual_name_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { initiateEmailSignIn() },
                            colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("একাউন্টে প্রবেশ / নিবন্ধন এগিয়ে যান", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "সার্ভার-সাইড ফায়ারস্টোর ও এনক্রিপ্টেড ক্লাউড সিঙ্ক সক্রিয়",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}
