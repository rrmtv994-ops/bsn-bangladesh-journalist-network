package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Member
import com.example.data.model.NewsArticle
import com.example.data.model.Notice
import com.example.ui.theme.BSNGold
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert
import com.example.util.AiCheckResult
import com.example.util.AiNewsChecker
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsScreen(
    newsList: List<NewsArticle>,
    noticesList: List<Notice>,
    currentMember: Member,
    onSubmitNews: (NewsArticle) -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("প্রকাশিত সংবাদ", "নোটিশ বোর্ড", "+ সংবাদ জমা দিন")

    var newsTitle by remember { mutableStateOf("") }
    var newsContent by remember { mutableStateOf("") }
    var newsCategory by remember { mutableStateOf("সাংবাদিক সুরক্ষা") }
    var newsDistrict by remember { mutableStateOf(currentMember.district.ifBlank { "পটুয়াখালী" }) }
    var newsUpazila by remember { mutableStateOf(currentMember.upazila.ifBlank { "রাঙ্গাবালী" }) }
    var videoUrl by remember { mutableStateOf("") }
    var categoryExpanded by remember { mutableStateOf(false) }

    var aiAnalysisResult by remember { mutableStateOf<AiCheckResult?>(null) }
    var isCheckingAi by remember { mutableStateOf(false) }

    val categories = listOf("সাংবাদিক সুরক্ষা", "জরুরি সংবাদ", "অনুসন্ধানী রিপোর্ট", "জাতীয় সংবাদ", "প্রেস ক্লাব ও কর্মসূচি")

    // Filter verified/approved news for general flow
    val publishedNews = remember(newsList) {
        newsList.filter { it.status == NewsArticle.STATUS_APPROVED || it.isVerified }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            edgePadding = 14.dp,
            divider = {}
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) BSNGreenPrimary else Color.Gray,
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        when (selectedTab) {
            0 -> {
                // Published News Flow
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = BSNGreenDark
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BSNGold, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "BSN কেন্দ্রীয় নিউজ ফিড",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "সকল সংবাদ BSN 001 (সুপার এডমিন) দ্বারা অনুমোদিত ও বস্তুনিষ্ঠ",
                                        fontSize = 11.sp,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }
                    }

                    if (publishedNews.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "বর্তমানে কোনো প্রকাশিত সংবাদ নেই। নতুন সংবাদ জমা দিতে '+ সংবাদ জমা দিন' ট্যাবে যান।",
                                    fontSize = 13.sp,
                                    color = Color.Gray,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    } else {
                        items(publishedNews, key = { it.id }) { news ->
                            NewsCard(news = news)
                        }
                    }
                }
            }

            1 -> {
                // Notices Board
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(noticesList, key = { it.id }) { notice ->
                        NoticeCard(notice = notice)
                    }
                }
            }

            2 -> {
                // Submit News Form
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "সাংবাদিক সংবাদ জমা ফর্ম",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BSNGreenDark
                                )
                                Text(
                                    text = "সংবাদ প্রেরক: ${currentMember.fullName} (আইডি: ${currentMember.id})",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = newsTitle,
                                    onValueChange = {
                                        newsTitle = it
                                        aiAnalysisResult = null
                                    },
                                    label = { Text("সংবাদের শিরোনাম *") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("news_title_input"),
                                    shape = RoundedCornerShape(10.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OutlinedTextField(
                                        value = newsDistrict,
                                        onValueChange = { newsDistrict = it },
                                        label = { Text("জেলা *") },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    OutlinedTextField(
                                        value = newsUpazila,
                                        onValueChange = { newsUpazila = it },
                                        label = { Text("উপজেলা *") },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                ExposedDropdownMenuBox(
                                    expanded = categoryExpanded,
                                    onExpandedChange = { categoryExpanded = !categoryExpanded },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    OutlinedTextField(
                                        value = newsCategory,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("সংবাদ বিভাগ") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                                        modifier = Modifier
                                            .menuAnchor(MenuAnchorType.PrimaryNotEditable, true)
                                            .fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    ExposedDropdownMenu(
                                        expanded = categoryExpanded,
                                        onDismissRequest = { categoryExpanded = false }
                                    ) {
                                        categories.forEach { cat ->
                                            DropdownMenuItem(
                                                text = { Text(cat) },
                                                onClick = {
                                                    newsCategory = cat
                                                    categoryExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = newsContent,
                                    onValueChange = {
                                        newsContent = it
                                        aiAnalysisResult = null
                                    },
                                    label = { Text("সংবাদের বিস্তারিত বিবরণ *") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("news_content_input"),
                                    minLines = 5,
                                    maxLines = 10,
                                    shape = RoundedCornerShape(10.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = videoUrl,
                                    onValueChange = { videoUrl = it },
                                    label = { Text("ছবি বা ভিডিও লিংক / ড্রাইভ লিংক (যদি থাকে)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                // AI Editorial & Legal Risk Checker Button
                                OutlinedButton(
                                    onClick = {
                                        if (newsTitle.isBlank() || newsContent.isBlank()) {
                                            Toast.makeText(context, "বিশ্লেষণের জন্য আগে শিরোনাম ও বিবরণ লিখুন", Toast.LENGTH_SHORT).show()
                                            return@OutlinedButton
                                        }
                                        aiAnalysisResult = AiNewsChecker.analyzeReport(newsTitle, newsContent)
                                        Toast.makeText(context, "AI আইনি ও বানান নিরীক্ষা সম্পন্ন", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, BSNGreenDark),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("ai_news_check_button")
                                ) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = BSNGold, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "AI বানান/ব্যাকরণ ও আইনি ঝুঁকি নিরীক্ষা করুন",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = BSNGreenDark
                                    )
                                }

                                // AI Check Results Box
                                aiAnalysisResult?.let { result ->
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (result.hasRisk) Color(0xFFFFF8E1) else Color(0xFFE8F5E9),
                                        border = BorderStroke(1.dp, if (result.hasRisk) Color(0xFFFFB300) else BSNGreenPrimary),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        if (result.hasRisk) Icons.Default.Warning else Icons.Default.CheckCircle,
                                                        contentDescription = null,
                                                        tint = if (result.hasRisk) Color(0xFFE65100) else BSNGreenDark,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "AI নিরীক্ষা ফলাফল: ${result.riskLevel}",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = if (result.hasRisk) Color(0xFFE65100) else BSNGreenDark
                                                    )
                                                }
                                                Text(
                                                    text = "স্কোর: ${result.policyComplianceScore}/১০০",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = BSNGreenDark
                                                )
                                            }

                                            if (result.legalRiskNotes.isNotEmpty()) {
                                                Spacer(modifier = Modifier.height(6.dp))
                                                result.legalRiskNotes.forEach { note ->
                                                    Text("• $note", fontSize = 11.sp, color = Color(0xFF7A5900), lineHeight = 15.sp)
                                                }
                                            }

                                            if (result.grammarSpellingNotes.isNotEmpty()) {
                                                Spacer(modifier = Modifier.height(6.dp))
                                                result.grammarSpellingNotes.forEach { gNote ->
                                                    Text("• $gNote", fontSize = 11.sp, color = Color(0xFF2E7D32), lineHeight = 15.sp)
                                                }
                                            }

                                            Text(
                                                text = "🔒 প্রেস নীতি: AI নিজে থেকে কোনো তথ্য বা উদ্ধৃতি বানাবে না।",
                                                fontSize = 9.sp,
                                                color = Color.Gray,
                                                modifier = Modifier.padding(top = 6.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Surface(
                                    color = Color(0xFFF7FBF8),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, Color(0xFFE0E5E1))
                                ) {
                                    Text(
                                        text = "ℹ️ সংবাদ জমা দেওয়ার পর তা প্রথমে 'অপেক্ষমাণ' (Pending) অবস্থায় থাকবে। BSN 001 (সুপার এডমিন) অনুমোদন করলে প্রকাশিত হবে।",
                                        fontSize = 11.sp,
                                        color = BSNGreenDark,
                                        modifier = Modifier.padding(10.dp),
                                        lineHeight = 15.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        if (newsTitle.isBlank() || newsContent.isBlank()) {
                                            Toast.makeText(context, "শিরোনাম ও বিবরণ আবশ্যক", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }

                                        val isSuper = currentMember.isSuperAdmin()
                                        val aiReportText = buildString {
                                            aiAnalysisResult?.let {
                                                append("ঝুঁকি স্তর: ${it.riskLevel} (স্কোর: ${it.policyComplianceScore}/১০০)\n")
                                                it.legalRiskNotes.forEach { n -> append("- $n\n") }
                                                it.grammarSpellingNotes.forEach { g -> append("- $g\n") }
                                            }
                                        }

                                        val article = NewsArticle(
                                            id = "NWS-" + UUID.randomUUID().toString().take(6).uppercase(),
                                            title = newsTitle.trim(),
                                            content = newsContent.trim(),
                                            category = newsCategory,
                                            authorName = currentMember.fullName,
                                            reporterId = currentMember.id,
                                            mediaOutlet = currentMember.organization,
                                            division = currentMember.division,
                                            district = newsDistrict.trim(),
                                            upazila = newsUpazila.trim(),
                                            imageUrl = "",
                                            videoUrl = videoUrl.trim(),
                                            status = if (isSuper) NewsArticle.STATUS_APPROVED else NewsArticle.STATUS_PENDING,
                                            aiReviewReport = aiReportText,
                                            timestamp = System.currentTimeMillis(),
                                            isVerified = isSuper
                                        )

                                        onSubmitNews(article)

                                        // Reset fields
                                        newsTitle = ""
                                        newsContent = ""
                                        videoUrl = ""
                                        aiAnalysisResult = null
                                        selectedTab = 0
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("submit_news_button")
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("সংবাদ জমা দিন (ক্লাউড সার্ভারে প্রেরণ)", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NewsCard(news: NewsArticle) {
    val context = LocalContext.current
    val formattedDate = remember(news.timestamp) {
        SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date(news.timestamp))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, Color(0xFFEEEEEE))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = BSNGreenPrimary.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = news.category,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BSNGreenDark,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = "Approved",
                        tint = BSNGreenPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "অনুমোদিত ও যাচাইকৃত",
                        fontSize = 11.sp,
                        color = BSNGreenPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = news.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF191C1A),
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = news.content,
                fontSize = 13.sp,
                color = Color(0xFF333333),
                lineHeight = 18.sp
            )

            if (news.videoUrl.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFF1F8F4),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "সংযুক্ত মিডিয়া: ${news.videoUrl}",
                        fontSize = 11.sp,
                        color = BSNGreenDark,
                        modifier = Modifier.padding(6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFF0F0F0))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "রিপোর্টার: ${news.authorName} (${news.reporterId.ifBlank { "BSN" }})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BSNGreenDark
                    )
                    Text(
                        text = "ঘটনাস্থল: ${news.upazila}, ${news.district} • $formattedDate",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }

                IconButton(
                    onClick = {
                        val shareText = """
                            📰 ${news.title}
                            স্থান: ${news.upazila}, ${news.district}
                            ${news.content}
                            রিপোর্টার: ${news.authorName} (${news.reporterId})
                            সূত্র: বাংলাদেশ সাংবাদিক নেটওয়ার্ক (BSN)
                        """.trimIndent()
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, shareText)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "সংবাদ শেয়ার করুন"))
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share News", tint = Color.Gray)
                }
            }
        }
    }
}

@Composable
private fun NoticeCard(notice: Notice) {
    val formattedDate = remember(notice.timestamp) {
        SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date(notice.timestamp))
    }

    val isUrgent = notice.priority == "জরুরি"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUrgent) Color(0xFFFFF7F7) else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(
            1.dp,
            if (isUrgent) BSNRedAlert.copy(alpha = 0.5f) else Color(0xFFEEEEEE)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isUrgent) BSNRedAlert else BSNGold
                ) {
                    Text(
                        text = if (isUrgent) "🚨 জরুরি নোটিশ" else "📌 কেন্দ্রীয় নোটিশ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Text(
                    text = formattedDate,
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = notice.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (isUrgent) BSNRedAlert else Color.Black,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = notice.body,
                fontSize = 13.sp,
                color = Color(0xFF333333),
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "জারীকারক: ${notice.issuedBy}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = BSNGreenDark
            )
        }
    }
}
