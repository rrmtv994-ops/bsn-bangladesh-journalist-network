package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert

enum class BSNScreen(val title: String) {
    HOME("হোম"),
    MEMBERS("সদস্য"),
    HIGH_ALERT("HIGH ALERT"),
    NEWS("সংবাদ"),
    CHAT("বার্তা"),
    ADMIN("অ্যাডমিন"),
    PROFILE("প্রোফাইল")
}

@Composable
fun BSNBottomBar(
    currentScreen: BSNScreen,
    onScreenSelected: (BSNScreen) -> Unit,
    activeAlertsCount: Int = 0
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
    ) {
        NavigationBarItem(
            selected = currentScreen == BSNScreen.HOME,
            onClick = { onScreenSelected(BSNScreen.HOME) },
            icon = { Icon(Icons.Default.Home, contentDescription = "হোম") },
            label = { Text("হোম", fontSize = 11.sp, maxLines = 1) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BSNGreenPrimary,
                selectedTextColor = BSNGreenPrimary,
                indicatorColor = BSNGreenPrimary.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_home")
        )

        NavigationBarItem(
            selected = currentScreen == BSNScreen.MEMBERS,
            onClick = { onScreenSelected(BSNScreen.MEMBERS) },
            icon = { Icon(Icons.Default.People, contentDescription = "সদস্যবৃন্দ") },
            label = { Text("সদস্য", fontSize = 11.sp, maxLines = 1) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BSNGreenPrimary,
                selectedTextColor = BSNGreenPrimary,
                indicatorColor = BSNGreenPrimary.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_members")
        )

        NavigationBarItem(
            selected = currentScreen == BSNScreen.HIGH_ALERT,
            onClick = { onScreenSelected(BSNScreen.HIGH_ALERT) },
            icon = {
                if (activeAlertsCount > 0) {
                    BadgedBox(
                        badge = {
                            Badge(containerColor = BSNRedAlert, contentColor = Color.White) {
                                Text("$activeAlertsCount")
                            }
                        }
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "বিপদ সংকেত")
                    }
                } else {
                    Icon(Icons.Default.Warning, contentDescription = "বিপদ সংকেত")
                }
            },
            label = {
                Text(
                    "ALERT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BSNRedAlert,
                selectedTextColor = BSNRedAlert,
                unselectedIconColor = BSNRedAlert,
                unselectedTextColor = BSNRedAlert.copy(alpha = 0.8f),
                indicatorColor = BSNRedAlert.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_high_alert")
        )

        NavigationBarItem(
            selected = currentScreen == BSNScreen.NEWS,
            onClick = { onScreenSelected(BSNScreen.NEWS) },
            icon = { Icon(Icons.AutoMirrored.Filled.Article, contentDescription = "সংবাদ") },
            label = { Text("সংবাদ", fontSize = 11.sp, maxLines = 1) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BSNGreenPrimary,
                selectedTextColor = BSNGreenPrimary,
                indicatorColor = BSNGreenPrimary.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_news")
        )

        NavigationBarItem(
            selected = currentScreen == BSNScreen.CHAT,
            onClick = { onScreenSelected(BSNScreen.CHAT) },
            icon = { Icon(androidx.compose.material.icons.Icons.Default.Forum, contentDescription = "বার্তা") },
            label = { Text("বার্তা", fontSize = 11.sp, maxLines = 1) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BSNGreenPrimary,
                selectedTextColor = BSNGreenPrimary,
                indicatorColor = BSNGreenPrimary.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_chat")
        )

        NavigationBarItem(
            selected = currentScreen == BSNScreen.ADMIN,
            onClick = { onScreenSelected(BSNScreen.ADMIN) },
            icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "অ্যাডমিন") },
            label = { Text("প্যানেল", fontSize = 11.sp, maxLines = 1) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BSNGreenPrimary,
                selectedTextColor = BSNGreenPrimary,
                indicatorColor = BSNGreenPrimary.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_admin")
        )

        NavigationBarItem(
            selected = currentScreen == BSNScreen.PROFILE,
            onClick = { onScreenSelected(BSNScreen.PROFILE) },
            icon = { Icon(Icons.Default.Person, contentDescription = "প্রোফাইল") },
            label = { Text("প্রোফাইল", fontSize = 11.sp, maxLines = 1) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = BSNGreenPrimary,
                selectedTextColor = BSNGreenPrimary,
                indicatorColor = BSNGreenPrimary.copy(alpha = 0.15f)
            ),
            modifier = Modifier.testTag("nav_profile")
        )
    }
}
