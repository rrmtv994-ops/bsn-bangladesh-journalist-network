package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationAdd
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditLog
import com.example.data.model.EmergencyAlert
import com.example.data.model.Member
import com.example.data.model.NewsArticle
import com.example.data.model.Notice
import com.example.ui.theme.BSNGold
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert
import com.example.ui.theme.BSNRedContainer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminScreen(
    currentMember: Member,
    members: List<Member>,
    activeAlerts: List<EmergencyAlert>,
    allAlerts: List<EmergencyAlert>,
    allNews: List<NewsArticle>,
    notices: List<Notice>,
    auditLogs: List<AuditLog>,
    onApproveMember: (String) -> Unit,
    onDeleteMember: (String) -> Unit,
    onPromoteToAdmin: (String) -> Unit,
    onRevokeAdmin: (String) -> Unit,
    onRefreshMembers: () -> Unit,
    onApproveNews: (String) -> Unit,
    onRejectNews: (String, String) -> Unit,
    onCancelAlert: (String, String) -> Unit,
    onPublishNotice: (Notice) -> Unit,
    onUpdateAlertStatus: (String, String) -> Unit,
    onViewIdCard: (Member) -> Unit,
    onAddNewMember: () -> Unit,
    districtSeats: List<com.example.data.model.DistrictAdminSeat> = emptyList(),
    onAppointDistrictAdmin: (String, Member) -> Unit = { _, _ -> },
    onSuspendDistrictAdmin: (String, String) -> Unit = { _, _ -> },
    onRemoveDistrictAdmin: (String) -> Unit = {},
    onCancelMemberWithReason: (String, String) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val isSuperAdmin = currentMember.isSuperAdmin()
    val isDistrictAdmin = currentMember.isDistrictAdmin()

    if (!isSuperAdmin && !isDistrictAdmin && !currentMember.isAdmin) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFF0F4F1)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = BSNGreenDark, modifier = Modifier.size(32.dp))
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        "প্রশাসনিক চ্যানেল (Admin Channel)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = BSNGreenDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "এই সেকশনটি শুধুমাত্র BSN 001 (সুপার এডমিন) এবং ৬৪ জেলার অনুমোদিত District Admin-দের জন্য নির্ধারিত।\n\nআপনি একজন সাধারণ নিবন্ধিত সদস্য হিসেবে BSN User App ব্যবহার করছেন। জেলা এডমিন হিসেবে নিয়োগ পেলে আপনার একাউন্টে স্বয়ংক্রিয়ভাবে প্রশাসনিক চ্যানেল সক্রিয় হবে।",
                        fontSize = 13.sp,
                        color = Color.DarkGray,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 20.sp
                    )
                }
            }
        }
        return
    }

    if (isDistrictAdmin && !isSuperAdmin) {
        DistrictAdminChannelView(
            currentMember = currentMember,
            allMembers = members,
            allNews = allNews,
            activeAlerts = activeAlerts,
            onCancelMemberWithReason = onCancelMemberWithReason,
            onApproveNews = onApproveNews,
            onRejectNews = onRejectNews,
            onViewIdCard = onViewIdCard
        )
        return
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        "৬৫ এডমিন পদ (Admin Seats)",
        "সদস্য ব্যবস্থাপনা",
        "সংবাদ অনুমোদন",
        "জরুরি সংকেত মনিটরিং",
        "নোটিশ জারি",
        "অডিট লগ (Audit Log)",
        "BSN প্রশাসন ও নিরাপত্তা"
    )

    var searchQuery by remember { mutableStateOf("") }
    var selectedMemberForDelete by remember { mutableStateOf<Member?>(null) }
    var alertForCancelDialog by remember { mutableStateOf<EmergencyAlert?>(null) }
    var cancelReason by remember { mutableStateOf("") }

    var newsForRejectDialog by remember { mutableStateOf<NewsArticle?>(null) }
    var rejectNewsReason by remember { mutableStateOf("") }

    // Notice publishing states
    var noticeTitle by remember { mutableStateOf("") }
    var noticeBody by remember { mutableStateOf("") }
    var noticePriority by remember { mutableStateOf("সাধারণ") }

    val pendingNewsList = remember(allNews) {
        allNews.filter { it.status == NewsArticle.STATUS_PENDING }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Super Admin Status Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = if (isSuperAdmin) BSNGreenDark else Color(0xFF1E293B)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isSuperAdmin) Icons.Default.Shield else Icons.Default.Lock,
                        contentDescription = null,
                        tint = if (isSuperAdmin) BSNGold else Color.LightGray,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isSuperAdmin) "BSN 001 • সুপার এডমিন কন্ট্রোল" else "এডমিন প্যানেল • সীমিত এক্সেস",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = if (isSuperAdmin) "মোঃ রিমন শিকদার (সর্বোচ্চ সার্ভার নিয়ন্ত্রণ)" else "${currentMember.fullName} (${currentMember.id})",
                            color = if (isSuperAdmin) BSNGold else Color.LightGray,
                            fontSize = 11.sp
                        )
                    }
                }

                if (pendingNewsList.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = BSNRedAlert
                    ) {
                        Text(
                            text = "${pendingNewsList.size}টি সংবাদ অপেক্ষমাণ",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }

        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            edgePadding = 12.dp,
            divider = {}
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) BSNGreenPrimary else Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                )
            }
        }

        when (selectedTab) {
            0 -> {
                // Tab 0: 65 Admin Positions (BSN 001 + 64 District Admin Seats)
                DistrictAdminSeatsSection(
                    currentMember = currentMember,
                    allSeats = districtSeats,
                    allMembers = members,
                    onAppointAdmin = onAppointDistrictAdmin,
                    onSuspendAdmin = onSuspendDistrictAdmin,
                    onRemoveAdmin = onRemoveDistrictAdmin
                )
            }

            1 -> {
                // Tab 1: Member Management
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("নাম, ফোন বা আইডি দিয়ে খুঁজুন...", fontSize = 12.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("admin_member_search"),
                                shape = RoundedCornerShape(10.dp)
                            )

                            IconButton(
                                onClick = onRefreshMembers,
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(BSNGreenPrimary.copy(alpha = 0.12f))
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = BSNGreenDark)
                            }
                        }
                    }

                    val filtered = members.filter {
                        searchQuery.isBlank() ||
                                it.fullName.contains(searchQuery, ignoreCase = true) ||
                                it.phone.contains(searchQuery) ||
                                it.id.contains(searchQuery, ignoreCase = true)
                    }

                    items(filtered, key = { it.id }) { member ->
                        AdminMemberCard(
                            member = member,
                            isSuperAdmin = isSuperAdmin,
                            onApprove = { onApproveMember(member.id) },
                            onDelete = {
                                if (isSuperAdmin) {
                                    selectedMemberForDelete = member
                                } else {
                                    Toast.makeText(context, "শুধুমাত্র BSN 001 (সুপার এডমিন) সদস্য অপসারণ করতে পারবেন", Toast.LENGTH_LONG).show()
                                }
                            },
                            onPromote = {
                                if (isSuperAdmin) {
                                    onPromoteToAdmin(member.id)
                                } else {
                                    Toast.makeText(context, "শুধুমাত্র BSN 001 এডমিন নিয়োগ করতে পারবেন", Toast.LENGTH_LONG).show()
                                }
                            },
                            onRevoke = {
                                if (isSuperAdmin) {
                                    onRevokeAdmin(member.id)
                                } else {
                                    Toast.makeText(context, "শুধুমাত্র BSN 001 এডমিন ক্ষমতা প্রত্যাহার করতে পারবেন", Toast.LENGTH_LONG).show()
                                }
                            },
                            onViewCard = { onViewIdCard(member) }
                        )
                    }
                }
            }

            2 -> {
                // Tab 2: News Approvals
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF1F8F4),
                            border = BorderStroke(1.dp, BSNGreenPrimary.copy(alpha = 0.4f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "📰 ফিল্ড রিপোর্টারদের জমা দেওয়া সংবাদ অনুমোদন সেল",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = BSNGreenDark
                                )
                                Text(
                                    text = "সদস্যদের প্রেরিত সংবাদসমূহ এখানে অপেক্ষমাণ থাকে। BSN 001 অনুমোদন করলে মূল ফিডে প্রকাশিত হবে।",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }

                    if (pendingNewsList.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("বর্তমানে কোনো অপেক্ষমাণ সংবাদ নেই।", fontSize = 13.sp, color = Color.Gray)
                            }
                        }
                    } else {
                        items(pendingNewsList, key = { it.id }) { news ->
                            PendingNewsAdminCard(
                                news = news,
                                isSuperAdmin = isSuperAdmin,
                                onApprove = { onApproveNews(news.id) },
                                onReject = { newsForRejectDialog = news }
                            )
                        }
                    }
                }
            }

            3 -> {
                // Tab 3: High Alert Monitoring & Withdrawal
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = BSNRedAlert)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "🚨 হাই এলার্ট লাইভ মনিটর ও কমান্ড সেন্টার",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "বিপদ সংকেত ডিলিট করা নিষেধ (সার্ভারে হিস্টোরি সংরক্ষিত থাকে)। শুধুমাত্র BSN 001 প্রত্যাহার বা সমাধান করতে পারেন।",
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    items(allAlerts, key = { it.id }) { alert ->
                        AdminAlertCard(
                            alert = alert,
                            isSuperAdmin = isSuperAdmin,
                            onUpdateStatus = { status -> onUpdateAlertStatus(alert.id, status) },
                            onCancel = { alertForCancelDialog = alert }
                        )
                    }
                }
            }

            4 -> {
                // Tab 4: Publish Official Notice
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "কেন্দ্রীয় নোটিশ ও গাইডলাইন জারি",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BSNGreenDark
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = noticeTitle,
                                    onValueChange = { noticeTitle = it },
                                    label = { Text("নোটিশের শিরোনাম *") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = noticeBody,
                                    onValueChange = { noticeBody = it },
                                    label = { Text("নোটিশের বিবরণ *") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 4,
                                    shape = RoundedCornerShape(10.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("জরুরি", "সাধারণ", "সাংগঠনিক").forEach { prio ->
                                        OutlinedButton(
                                            onClick = { noticePriority = prio },
                                            shape = RoundedCornerShape(8.dp),
                                            border = BorderStroke(
                                                1.5.dp,
                                                if (noticePriority == prio) BSNGreenPrimary else Color.LightGray
                                            ),
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = if (noticePriority == prio) BSNGreenPrimary.copy(alpha = 0.1f) else Color.Transparent
                                            ),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(
                                                text = prio,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (noticePriority == prio) BSNGreenDark else Color.DarkGray
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        if (noticeTitle.isBlank() || noticeBody.isBlank()) {
                                            Toast.makeText(context, "শিরোনাম ও বিবরণ আবশ্যক", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }

                                        val notice = Notice(
                                            id = "NOT-" + UUID.randomUUID().toString().take(6).uppercase(),
                                            title = noticeTitle.trim(),
                                            body = noticeBody.trim(),
                                            priority = noticePriority,
                                            issuedBy = "${currentMember.fullName} (${if (isSuperAdmin) "Founder & Super Admin" else "কেন্দ্রীয় প্রশাসন"})",
                                            timestamp = System.currentTimeMillis(),
                                            isPinned = noticePriority == "জরুরি"
                                        )

                                        onPublishNotice(notice)
                                        noticeTitle = ""
                                        noticeBody = ""
                                        Toast.makeText(context, "নোটিশ সফলভাবে ফায়ারস্টোর ও অ্যাপে জারি করা হয়েছে", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BSNGreenDark),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.NotificationAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("নোটিশ প্রকাশ করুন", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            5 -> {
                // Tab 5: Audit Logs
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.History, contentDescription = null, tint = BSNGreenDark)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "প্রশাসনিক অডিট লগ (Audit Log Trail)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color(0xFF1E293B)
                                    )
                                    Text(
                                        text = "অনুমোদন, অপসারণ ও প্রত্যাহারের সকল কাজের সময় ও দায়িত্বপ্রাপ্ত ব্যক্তির অপরিবর্তনীয় রেকর্ড।",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }

                    if (auditLogs.isEmpty()) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                                Text("এখনও কোনো অডিট রেকর্ড নেই।", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    } else {
                        items(auditLogs, key = { it.id }) { log ->
                            AuditLogItemCard(log = log)
                        }
                    }
                }
            }

            6 -> {
                // Tab 6: BSN Administration & Security
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(shape = CircleShape, color = BSNGold, modifier = Modifier.size(36.dp)) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Color.White)
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "BSN 001 সুপার এডমিন ক্ষমতা ও সুরক্ষা",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = BSNGreenDark
                                        )
                                        Text(
                                            text = "প্রতিষ্ঠাতা: মোঃ রিমন শিকদার (BSN 001)",
                                            fontSize = 12.sp,
                                            color = Color(0xFF7A5900),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFF1F8F4),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("🔒 সার্ভার-সাইড সিকিউরিটি রুলস (Zero-Trust Security):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BSNGreenDark)
                                        Text("• শুধু নাম বা ID লিখে কেউ সুপার এডমিন ক্ষমতা পাবে না।", fontSize = 11.sp, color = Color.DarkGray)
                                        Text("• এডমিন নিয়োগ/অপসারণ, সদস্য অপসারণ, HIGH ALERT প্রত্যাহার ও সংবাদ অনুমোদন সার্ভার লেভেলে rrmrimonshikder@gmail.com একাউন্টের সাথে আবদ্ধ।", fontSize = 11.sp, color = Color.DarkGray)
                                        Text("• সার্ভিস একাউন্ট কি (Service Account Key) APK-তে রাখা নিষিদ্ধ।", fontSize = 11.sp, color = Color.DarkGray)
                                        Text("• দুটি ফোনে দুটি Gmail দিয়ে লগইন করলে রিয়েল-টাইমে সদস্য, সংবাদ ও হাই এলার্ট সার্ভার থেকে সিঙ্ক হয়।", fontSize = 11.sp, color = Color.DarkGray)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "সদস্য সংখ্যা: ${members.size} জন • সক্রিয় বিপদ সংকেত: ${activeAlerts.size}টি",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF333333)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Delete Member Confirmation Dialog (Super Admin Exclusive)
        selectedMemberForDelete?.let { member ->
            AlertDialog(
                onDismissRequest = { selectedMemberForDelete = null },
                icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = BSNRedAlert) },
                title = { Text("সদস্য অপসারণ নিশ্চিতকরণ", fontWeight = FontWeight.Bold) },
                text = {
                    Text("আপনি কি নিশ্চিত যে সদস্য ${member.fullName} (${member.id}) কে BSN প্ল্যাটফর্ম ও ফায়ারস্টোর ক্লাউড সার্ভার থেকে অপসারণ করতে চান? এই ক্রিয়াটি অপরিবর্তনীয় এবং অডিট লগে রেকর্ড হবে।")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onDeleteMember(member.id)
                            selectedMemberForDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert)
                    ) {
                        Text("অপসারণ করুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedMemberForDelete = null }) {
                        Text("বাতিল")
                    }
                }
            )
        }

        // Cancel/Withdraw High Alert Dialog (BSN 001 Super Admin Exclusive)
        alertForCancelDialog?.let { alert ->
            AlertDialog(
                onDismissRequest = { alertForCancelDialog = null },
                icon = { Icon(Icons.Default.Cancel, contentDescription = null, tint = BSNRedAlert) },
                title = { Text("HIGH ALERT প্রত্যাহার (BSN 001)", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("বিপদ: ${alert.alertType}\nস্থান: ${alert.spotAddress}, ${alert.district}\nরিপোর্টার: ${alert.reporterName}", fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = cancelReason,
                            onValueChange = { cancelReason = it },
                            label = { Text("প্রত্যাহারের কারণ / প্রশাসনিক নোট *") },
                            placeholder = { Text("যেমন: পরিস্থিতি নিয়ন্ত্রণে এসেছে / ভুল সংকেত") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (cancelReason.isBlank()) {
                                Toast.makeText(context, "প্রত্যাহারের কারণ আবশ্যক", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            onCancelAlert(alert.id, cancelReason)
                            alertForCancelDialog = null
                            cancelReason = ""
                            Toast.makeText(context, "সংকেত প্রত্যাহার সম্পন্ন হয়েছে", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert)
                    ) {
                        Text("সংকেত প্রত্যাহার করুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { alertForCancelDialog = null }) {
                        Text("ফিরে যান")
                    }
                }
            )
        }

        // Reject News Dialog
        newsForRejectDialog?.let { news ->
            AlertDialog(
                onDismissRequest = { newsForRejectDialog = null },
                title = { Text("সংবাদ প্রত্যাখ্যান নোট", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("শিরোনাম: ${news.title}\nরিপোর্টার: ${news.authorName}", fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = rejectNewsReason,
                            onValueChange = { rejectNewsReason = it },
                            label = { Text("প্রত্যাখ্যানের কারণ লিখুন *") },
                            placeholder = { Text("যেমন: সূত্রের ঘাটতি / নীতিমালার ব্যত্যয়") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (rejectNewsReason.isBlank()) {
                                Toast.makeText(context, "কারণ আবশ্যক", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            onRejectNews(news.id, rejectNewsReason)
                            newsForRejectDialog = null
                            rejectNewsReason = ""
                            Toast.makeText(context, "সংবাদ প্রত্যাখ্যাত হয়েছে", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert)
                    ) {
                        Text("প্রত্যাখ্যান নিশ্চিত করুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { newsForRejectDialog = null }) {
                        Text("বাতিল")
                    }
                }
            )
        }
    }
}

@Composable
private fun AdminMemberCard(
    member: Member,
    isSuperAdmin: Boolean,
    onApprove: () -> Unit,
    onDelete: () -> Unit,
    onPromote: () -> Unit,
    onRevoke: () -> Unit,
    onViewCard: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = member.fullName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (member.isSuperAdmin()) BSNGold else if (member.isAdmin) BSNGreenPrimary.copy(alpha = 0.2f) else Color(0xFFF1F5F9)
                    ) {
                        Text(
                            text = member.role,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (member.isSuperAdmin()) Color.White else if (member.isAdmin) BSNGreenDark else Color.DarkGray,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = member.id,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = BSNGreenDark
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "${member.profession} • ${member.organization}",
                fontSize = 12.sp,
                color = Color.DarkGray
            )
            Text(
                text = "এলাকা: ${member.upazila}, ${member.district} • ফোন: ${member.phone} • ইমেইল: ${member.email}",
                fontSize = 11.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFF1F5F9))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onViewCard,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("আইডি কার্ড", fontSize = 11.sp)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!member.isVerified) {
                        Button(
                            onClick = onApprove,
                            colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("ভেরিফাই", fontSize = 11.sp)
                        }
                    }

                    if (isSuperAdmin && !member.isSuperAdmin()) {
                        if (!member.isAdmin) {
                            Button(
                                onClick = onPromote,
                                colors = ButtonDefaults.buttonColors(containerColor = BSNGreenDark),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("+ এডমিন", fontSize = 11.sp)
                            }
                        } else {
                            OutlinedButton(
                                onClick = onRevoke,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("এডমিন প্রত্যাহার", fontSize = 10.sp, color = BSNRedAlert)
                            }
                        }

                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = BSNRedAlert)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PendingNewsAdminCard(
    news: NewsArticle,
    isSuperAdmin: Boolean,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, Color(0xFFFFE082))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFFFF8E1)
                ) {
                    Text(
                        text = "অপেক্ষমাণ সংবাদ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE65100),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = "রিপোর্টার আইডি: ${news.reporterId.ifBlank { "BSN" }}",
                    fontSize = 11.sp,
                    color = BSNGreenDark,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(text = news.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.Black)

            Spacer(modifier = Modifier.height(4.dp))

            Text(text = news.content, fontSize = 12.sp, color = Color(0xFF444444), maxLines = 4)

            if (news.aiReviewReport.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F8F4),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("🤖 AI বিশ্লেষণ রিপোর্ট:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BSNGreenDark)
                        Text(news.aiReviewReport, fontSize = 10.sp, color = Color.DarkGray)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFEEEEEE))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onReject,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("প্রত্যাখ্যান", fontSize = 11.sp, color = BSNRedAlert)
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("অনুমোদন করুন", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AdminAlertCard(
    alert: EmergencyAlert,
    isSuperAdmin: Boolean,
    onUpdateStatus: (String) -> Unit,
    onCancel: () -> Unit
) {
    val isResolved = alert.status == EmergencyAlert.STATUS_RESOLVED
    val isCancelled = alert.status == EmergencyAlert.STATUS_CANCELLED

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(
            1.dp,
            if (!isResolved && !isCancelled) BSNRedAlert.copy(alpha = 0.5f) else Color.LightGray
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = alert.alertType,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (!isResolved && !isCancelled) BSNRedAlert else Color.DarkGray
                )

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (!isResolved && !isCancelled) BSNRedAlert.copy(alpha = 0.12f) else Color(0xFFF1F5F9)
                ) {
                    Text(
                        text = alert.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (!isResolved && !isCancelled) BSNRedAlert else Color.Gray,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "রিপোর্টার: ${alert.reporterName} (${alert.reporterPhone}) • স্থান: ${alert.spotAddress}, ${alert.upazila}, ${alert.district}",
                fontSize = 11.sp,
                color = Color.DarkGray
            )

            Text(
                text = "বিবরণ: ${alert.description}",
                fontSize = 12.sp,
                color = Color.Black
            )

            if (alert.responderNotes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "নোট: ${alert.responderNotes}",
                    fontSize = 11.sp,
                    color = BSNGreenDark,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFF1F5F9))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (alert.status != EmergencyAlert.STATUS_COORDINATING) {
                        OutlinedButton(
                            onClick = { onUpdateStatus(EmergencyAlert.STATUS_COORDINATING) },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("সমন্বয় চলছে", fontSize = 10.sp)
                        }
                    }
                    if (alert.status != EmergencyAlert.STATUS_RESOLVED) {
                        Button(
                            onClick = { onUpdateStatus(EmergencyAlert.STATUS_RESOLVED) },
                            colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("সমাধান হয়েছে", fontSize = 10.sp)
                        }
                    }
                }

                if (isSuperAdmin && !isCancelled) {
                    Button(
                        onClick = onCancel,
                        colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("প্রত্যাহার (BSN 001)", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun AuditLogItemCard(log: AuditLog) {
    val formattedDate = remember(log.timestamp) {
        SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date(log.timestamp))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(0xFFE0F2FE)
                ) {
                    Text(
                        text = log.action,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color(0xFF0369A1),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = formattedDate,
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "সম্পাদনকারী: ${log.performedByName} (${log.performedById})",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.Black
            )

            Text(
                text = "বিস্তারিত: ${log.details}",
                fontSize = 11.sp,
                color = Color.DarkGray
            )
        }
    }
}
