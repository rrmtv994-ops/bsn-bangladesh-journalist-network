package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EmergencyAlert
import com.example.data.model.Member
import com.example.data.model.NewsArticle
import com.example.ui.theme.BSNGold
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert

@Composable
fun DistrictAdminChannelView(
    currentMember: Member,
    allMembers: List<Member>,
    allNews: List<NewsArticle>,
    activeAlerts: List<EmergencyAlert>,
    onCancelMemberWithReason: (memberId: String, reason: String) -> Unit,
    onApproveNews: (String) -> Unit,
    onRejectNews: (String, String) -> Unit,
    onViewIdCard: (Member) -> Unit
) {
    val context = LocalContext.current
    val assignedDistrict = currentMember.assignedDistrictSeat.ifBlank { currentMember.district }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("জেলা সদস্যবৃন্দ", "সংবাদ রিভিউ", "জেলা বিপদ সংকেত")

    // Cancellation Dialog
    var memberForCancelDialog by remember { mutableStateOf<Member?>(null) }
    var cancelReasonText by remember { mutableStateOf("") }

    val districtMembers = remember(allMembers, assignedDistrict) {
        allMembers.filter {
            it.district.trim().equals(assignedDistrict.trim(), ignoreCase = true)
        }
    }

    val districtNews = remember(allNews, assignedDistrict) {
        allNews.filter {
            it.district.trim().equals(assignedDistrict.trim(), ignoreCase = true)
        }
    }

    val districtAlerts = remember(activeAlerts, assignedDistrict) {
        activeAlerts.filter {
            it.district.trim().equals(assignedDistrict.trim(), ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // District Admin Banner
        Surface(
            color = BSNGreenDark,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(BSNGold),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = BSNGreenDark)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                "BSN জেলা প্রশাসনিক চ্যানেল",
                                color = BSNGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                "$assignedDistrict জেলা • এডমিন: ${currentMember.fullName} (${currentMember.id})",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "জেলা এডমিন",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "সীমাবদ্ধতা: শুধুমাত্র $assignedDistrict জেলার সদস্য ও সংবাদ পরিচালনা করতে পারবেন। BSN 001 এর সিদ্ধান্তে হস্তক্ষেপ করা যাবে না।",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 10.sp
                )
            }
        }

        // Channel Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = BSNGreenPrimary
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp
                        )
                    }
                )
            }
        }

        // Tab Contents
        when (selectedTab) {
            0 -> {
                // District Members List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text(
                            "মোট $assignedDistrict জেলার সদস্য: ${districtMembers.size} জন",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.DarkGray
                        )
                    }

                    items(districtMembers) { member ->
                        val isSelf = member.id == currentMember.id
                        val isSuperAdmin = member.isSuperAdmin()
                        val isRevoked = member.membershipStatus == Member.STATUS_REVOKED

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isRevoked) Color(0xFFFFEBEE) else Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(member.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("(${member.id})", fontSize = 11.sp, color = Color.Gray)
                                        }
                                        Text("${member.profession} • ${member.organization}", fontSize = 12.sp, color = Color.DarkGray)
                                        Text("উপজেলা: ${member.upazila} • ফোন: ${member.phone}", fontSize = 11.sp, color = Color.Gray)
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = when (member.membershipStatus) {
                                            Member.STATUS_REVOKED -> BSNRedAlert
                                            Member.STATUS_SUSPENDED -> Color(0xFFC07000)
                                            else -> BSNGreenPrimary
                                        }
                                    ) {
                                        Text(
                                            text = when (member.membershipStatus) {
                                                Member.STATUS_REVOKED -> "বাতিল"
                                                Member.STATUS_SUSPENDED -> "স্থগিত"
                                                else -> "সক্রিয়"
                                            },
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                if (isRevoked && member.cancellationReason.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "বাতিলের কারণ: ${member.cancellationReason}",
                                        color = BSNRedAlert,
                                        fontSize = 11.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    OutlinedButton(
                                        onClick = { onViewIdCard(member) },
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("আইডি কার্ড", fontSize = 11.sp)
                                    }

                                    if (!isSelf && !isSuperAdmin && !isRevoked) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Button(
                                            onClick = {
                                                memberForCancelDialog = member
                                                cancelReasonText = ""
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Text("সদস্যপদ বাতিল", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // District News Review
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (districtNews.isEmpty()) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                                Text("এই জেলায় কোনো সংবাদ জমা নেই", color = Color.Gray, fontSize = 13.sp)
                            }
                        }
                    }

                    items(districtNews) { news ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(news.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(news.content, maxLines = 3, fontSize = 12.sp, color = Color.DarkGray)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("প্রতিবেদক: ${news.authorName} (${news.reporterId})", fontSize = 11.sp, color = Color.Gray)

                                if (news.status == NewsArticle.STATUS_PENDING) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                        Button(
                                            onClick = { onApproveNews(news.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Text("অনুমোদন দিন", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // District Alerts
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (districtAlerts.isEmpty()) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                                Text("এই জেলায় বর্তমানে কোনো সক্রিয় বিপদ সংকেত নেই", color = Color.Gray, fontSize = 13.sp)
                            }
                        }
                    }

                    items(districtAlerts) { alert ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(alert.alertType, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BSNRedAlert)
                                Text(alert.description, fontSize = 12.sp, color = Color.DarkGray)
                                Text("রিপোর্টার: ${alert.reporterName} (${alert.reporterPhone})", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }

    // Cancel Member Dialog (with mandatory reason)
    memberForCancelDialog?.let { member ->
        AlertDialog(
            onDismissRequest = { memberForCancelDialog = null },
            icon = { Icon(Icons.Default.Block, contentDescription = null, tint = BSNRedAlert) },
            title = {
                Text(
                    text = "${member.fullName} এর সদস্যপদ বাতিল",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            },
            text = {
                Column {
                    Text(
                        "জেলা এডমিন হিসেবে আপনি শুধুমাত্র আপনার নিজ জেলার সদস্য বাতিল করতে পারবেন। সার্ভারে কারণ ও অডিট লগ সংরক্ষিত থাকবে।",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = cancelReasonText,
                        onValueChange = { cancelReasonText = it },
                        label = { Text("বাতিলের সুনির্দিষ্ট কারণ লিখুন (বাধ্যতামূলক)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (cancelReasonText.isNotBlank()) {
                            onCancelMemberWithReason(member.id, cancelReasonText.trim())
                            memberForCancelDialog = null
                            Toast.makeText(context, "${member.fullName} এর সদস্যপদ বাতিল করা হয়েছে", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "বাতিলের কারণ লেখা বাধ্যতামূলক", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert)
                ) {
                    Text("সদস্যপদ বাতিল করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { memberForCancelDialog = null }) {
                    Text("ফিরে যান")
                }
            }
        )
    }
}
