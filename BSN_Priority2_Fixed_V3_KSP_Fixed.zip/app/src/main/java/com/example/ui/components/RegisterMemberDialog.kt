package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.LocationData
import com.example.data.model.Member
import com.example.ui.theme.BSNGold
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterMemberDialog(
    initialEmail: String = "",
    initialName: String = "",
    suggestedId: String = "BSN 006",
    existingMembers: List<Member> = emptyList(),
    onDismiss: () -> Unit,
    onRegister: (Member) -> Unit
) {
    val context = LocalContext.current

    var fullName by remember { mutableStateOf(initialName) }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(initialEmail) }
    var profession by remember { mutableStateOf("সাংবাদিক") }
    var organization by remember { mutableStateOf("") }
    var selectedDivision by remember { mutableStateOf(LocationData.divisions[0]) }
    var selectedDistrict by remember { mutableStateOf("ঢাকা") }
    var upazila by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var bloodGroup by remember { mutableStateOf("B+") }
    var emergencyContact by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }

    var divisionExpanded by remember { mutableStateOf(false) }
    var districtExpanded by remember { mutableStateOf(false) }
    var bloodGroupExpanded by remember { mutableStateOf(false) }

    val bloodGroups = listOf("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")
    val availableDistricts = remember(selectedDivision) {
        LocationData.getDistrictsForDivision(selectedDivision)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 680.dp)
                .testTag("register_member_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Header Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BSNGreenDark)
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = null,
                                tint = BSNGold,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "সদস্য নিবন্ধন ও ডিজিটাল প্রেস আইডি",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "বাংলাদেশ সাংবাদিক নেটওয়ার্ক (BSN) ক্লাউড সার্ভার",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }

                Column(modifier = Modifier.padding(16.dp)) {
                    // Generated Unique BSN ID banner
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF1F8F4),
                        border = BorderStroke(1.dp, BSNGreenPrimary.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Badge, contentDescription = null, tint = BSNGreenDark)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "আপনার নির্ধারিত ইউনিক আইডি: $suggestedId",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = BSNGreenDark
                                )
                                Text(
                                    text = "নিবন্ধন সম্পন্ন হলে আইডিটি ক্লাউড সার্ভারে স্থায়ীভাবে বরাদ্দ হবে।",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("পূর্ণ নাম (বাংলায়) *") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reg_full_name"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Google একাউন্ট / Gmail *") },
                        readOnly = initialEmail.isNotBlank(),
                        supportingText = { Text("একই Gmail দিয়ে একাধিক সদস্য নিবন্ধন করা যাবে না", fontSize = 10.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reg_email"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("মোবাইল নম্বর *") },
                        placeholder = { Text("০১৭১১০০০০০০") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reg_phone"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = profession,
                        onValueChange = { profession = it },
                        label = { Text("পেশা / পদবি *") },
                        placeholder = { Text("যেমন: স্টাফ রিপোর্টার, জেলা প্রতিনিধি") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reg_profession"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = organization,
                        onValueChange = { organization = it },
                        label = { Text("মিডিয়া হাউস / প্রেস ক্লাব / প্রতিষ্ঠান *") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reg_organization"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Division Dropdown
                    ExposedDropdownMenuBox(
                        expanded = divisionExpanded,
                        onExpandedChange = { divisionExpanded = !divisionExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedDivision,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("বিভাগ *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = divisionExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable, true),
                            shape = RoundedCornerShape(10.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = divisionExpanded,
                            onDismissRequest = { divisionExpanded = false }
                        ) {
                            LocationData.divisions.forEach { div ->
                                DropdownMenuItem(
                                    text = { Text(div) },
                                    onClick = {
                                        selectedDivision = div
                                        val districts = LocationData.getDistrictsForDivision(div)
                                        if (districts.isNotEmpty()) {
                                            selectedDistrict = districts[0]
                                        }
                                        divisionExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // District Dropdown
                    ExposedDropdownMenuBox(
                        expanded = districtExpanded,
                        onExpandedChange = { districtExpanded = !districtExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedDistrict,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("জেলা *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = districtExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable, true),
                            shape = RoundedCornerShape(10.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = districtExpanded,
                            onDismissRequest = { districtExpanded = false }
                        ) {
                            availableDistricts.forEach { dist ->
                                DropdownMenuItem(
                                    text = { Text(dist) },
                                    onClick = {
                                        selectedDistrict = dist
                                        districtExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = upazila,
                        onValueChange = { upazila = it },
                        label = { Text("উপজেলা / থানা *") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reg_upazila"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("বর্তমান ঠিকানা / প্রেস ক্লাব ঠিকানা") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Blood Group Dropdown
                    ExposedDropdownMenuBox(
                        expanded = bloodGroupExpanded,
                        onExpandedChange = { bloodGroupExpanded = !bloodGroupExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = bloodGroup,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("রক্তের গ্রুপ") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = bloodGroupExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable, true),
                            shape = RoundedCornerShape(10.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = bloodGroupExpanded,
                            onDismissRequest = { bloodGroupExpanded = false }
                        ) {
                            bloodGroups.forEach { bg ->
                                DropdownMenuItem(
                                    text = { Text(bg) },
                                    onClick = {
                                        bloodGroup = bg
                                        bloodGroupExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = emergencyContact,
                        onValueChange = { emergencyContact = it },
                        label = { Text("জরুরি যোগাযোগের নম্বর") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text("সংক্ষিপ্ত পরিচিতি") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (fullName.isBlank() || phone.isBlank() || organization.isBlank() || upazila.isBlank()) {
                                Toast.makeText(context, "অনুগ্রহ করে সকল আবশ্যকীয় তথ্য (*) পূরণ করুন", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            // Check duplicate Gmail registration
                            val emailTrimmed = email.trim()
                            if (emailTrimmed.isNotBlank() && existingMembers.any { it.email.trim().equals(emailTrimmed, ignoreCase = true) }) {
                                Toast.makeText(context, "এই Gmail দিয়ে ইতোমধ্যে একজন সদস্য নিবন্ধিত রয়েছে। একই Gmail দিয়ে একাধিক সদস্য নিবন্ধন অনুমোদিত নয়।", Toast.LENGTH_LONG).show()
                                return@Button
                            }

                            val member = Member(
                                id = suggestedId,
                                fullName = fullName.trim(),
                                phone = phone.trim(),
                                email = emailTrimmed,
                                profession = profession.trim(),
                                organization = organization.trim(),
                                division = selectedDivision,
                                district = selectedDistrict.trim(),
                                upazila = upazila.trim(),
                                address = address.trim(),
                                bloodGroup = bloodGroup,
                                emergencyContact = emergencyContact.trim(),
                                bio = bio.trim(),
                                isVerified = false,
                                idCardStatus = Member.ID_STATUS_PENDING,
                                isExecutive = false,
                                isAdmin = false,
                                role = "সদস্য"
                            )

                            onRegister(member)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("submit_registration_button")
                    ) {
                        Text("নিবন্ধন সম্পন্ন করুন ও BSN সার্ভারে যুক্ত করুন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
