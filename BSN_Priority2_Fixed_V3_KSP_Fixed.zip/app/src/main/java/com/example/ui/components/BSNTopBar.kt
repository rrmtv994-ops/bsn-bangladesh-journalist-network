package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.BSNGold
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert

@Composable
fun BSNTopBar(
    activeAlertsCount: Int = 0,
    isAdminAppMode: Boolean = false,
    onToggleAppMode: () -> Unit = {},
    onAlertBadgeClick: () -> Unit = {},
    onEmergencyCallClick: () -> Unit = {}
) {
    val context = LocalContext.current

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = if (isAdminAppMode) Color(0xFF1E293B) else BSNGreenPrimary,
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .padding(2.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.bsn_logo),
                    contentDescription = "BSN Logo",
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isAdminAppMode) "BSN MAIN ADMIN" else "BSN",
                        color = BSNGold,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (isAdminAppMode) "৬৫ এডমিন কন্ট্রোল" else "বাংলাদেশ সাংবাদিক নেটওয়ার্ক",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Text(
                    text = if (isAdminAppMode) "Super Admin (BSN 001) + ৬৪ District Admin" else "Bangladesh Journalist Network • কর্ণধার: মোঃ রিমন শিকদার",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 10.sp,
                    maxLines = 1
                )
            }

            // Dual-App Quick Switcher Toggle
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onToggleAppMode() },
                color = if (isAdminAppMode) BSNGold else BSNGreenDark,
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = null,
                        tint = if (isAdminAppMode) Color.Black else BSNGold,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isAdminAppMode) "User App" else "Admin App",
                        color = if (isAdminAppMode) Color.Black else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = {
                    val intent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://rrmtv994-ops.github.io/bsn-bangladesh-journalist-network/")
                    )
                    context.startActivity(intent)
                },
                modifier = Modifier.size(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "BSN Official Website",
                    tint = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onEmergencyCallClick,
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(BSNRedAlert)
            ) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Call 999 Emergency",
                    tint = Color.White,
                    modifier = Modifier.size(17.dp)
                )
            }

            if (activeAlertsCount > 0) {
                Spacer(modifier = Modifier.width(4.dp))
                BadgedBox(
                    badge = {
                        Badge(containerColor = BSNRedAlert, contentColor = Color.White) {
                            Text(text = "$activeAlertsCount")
                        }
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onAlertBadgeClick() }
                        .padding(2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Active Emergency Alerts",
                        tint = BSNGold,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
