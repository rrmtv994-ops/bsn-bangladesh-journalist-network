package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddModerator
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DistrictAdminSeat
import com.example.data.model.LocationData
import com.example.data.model.Member
import com.example.ui.theme.BSNGold
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DistrictAdminSeatsSection(
    currentMember: Member,
    allSeats: List<DistrictAdminSeat>,
    allMembers: List<Member>,
    onAppointAdmin: (districtId: String, member: Member) -> Unit,
    onSuspendAdmin: (districtId: String, reason: String) -> Unit,
    onRemoveAdmin: (districtId: String) -> Unit
) {
    val context = LocalContext.current
    val isSuperAdmin = currentMember.isSuperAdmin()

    var searchQuery by remember { mutableStateOf("") }
    var selectedDivision by remember { mutableStateOf("সকল") }

    // Dialog states
    var seatForAppointDialog by remember { mutableStateOf<DistrictAdminSeat?>(null) }
    var seatForSuspendDialog by remember { mutableStateOf<DistrictAdminSeat?>(null) }
    var seatForRemoveDialog by remember { mutableStateOf<DistrictAdminSeat?>(null) }
    var suspendReason by remember { mutableStateOf("") }
    var selectedMemberToAppoint by remember { mutableStateOf<Member?>(null) }

    val filteredSeats = remember(allSeats, searchQuery, selectedDivision) {
        allSeats.filter { seat ->
            val matchDivision = selectedDivision == "সকল" || seat.divisionBn == selectedDivision
            val matchQuery = searchQuery.isBlank() ||
                    seat.districtNameBn.contains(searchQuery.trim(), ignoreCase = true) ||
                    seat.adminName.contains(searchQuery.trim(), ignoreCase = true) ||
                    seat.adminId.contains(searchQuery.trim(), ignoreCase = true)
            matchDivision && matchQuery
        }
    }

    val assignedCount = allSeats.count { it.status == DistrictAdminSeat.STATUS_ASSIGNED }
    val vacantCount = allSeats.count { it.status == DistrictAdminSeat.STATUS_VACANT }
    val suspendedCount = allSeats.count { it.status == DistrictAdminSeat.STATUS_SUSPENDED }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Super Admin Founder Card (BSN 001)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = BSNGreenDark),
                shape = RoundedCornerShape(14.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(BSNGold),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Shield, contentDescription = null, tint = BSNGreenDark, modifier = Modifier.size(28.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "পদবী ১: BSN 001 (Super Admin)",
                                        color = BSNGold,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = BSNGold,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            "স্থায়ী",
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 9.sp,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                Text("প্রতিষ্ঠাতা ও কর্ণধার: মোঃ রিমন শিকদার", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ফোন: 01989888856", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                        Text("ঠিকানা: ঢাকা, বাংলাদেশ", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                    }
                    Text(
                        "ক্ষমতা: সর্বোচ্চ নীতিনির্ধারণ, ৬৪ জেলা এডমিন নিয়োগ ও অপসারণ, আইডি কার্ড ও সংবাদ চূড়ান্ত অনুমোদন।",
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // 2. 64 District Admin Seats Statistics
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        "BSN মোট ৬৫টি এডমিন পদ কাঠামো (১ সুপার এডমিন + ৬৪ জেলা এডমিন)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = BSNGreenDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        SeatStatBadge("মোট জেলা আসন", "${allSeats.size}", Color.DarkGray)
                        SeatStatBadge("সক্রিয় এডমিন", "$assignedCount", BSNGreenDark)
                        SeatStatBadge("খালি আসন (Vacant)", "$vacantCount", Color(0xFFC07000))
                        SeatStatBadge("স্থগিত (Suspended)", "$suspendedCount", BSNRedAlert)
                    }
                }
            }
        }

        // 3. Search and Division Filter Chips
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("জেলা বা এডমিনের নাম দিয়ে খুঁজুন...", fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )
        }

        item {
            val divisions = listOf("সকল") + LocationData.divisions
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                divisions.forEach { div ->
                    FilterChip(
                        selected = selectedDivision == div,
                        onClick = { selectedDivision = div },
                        label = { Text(div, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BSNGreenPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // 4. District Admin Seat List (64 Seats)
        items(filteredSeats, key = { it.districtId }) { seat ->
            DistrictSeatCard(
                seat = seat,
                isSuperAdmin = isSuperAdmin,
                onAppointClick = {
                    seatForAppointDialog = seat
                    selectedMemberToAppoint = null
                },
                onSuspendClick = {
                    seatForSuspendDialog = seat
                    suspendReason = ""
                },
                onRemoveClick = {
                    seatForRemoveDialog = seat
                }
            )
        }
    }

    // Dialog 1: Appoint District Admin Dialog
    seatForAppointDialog?.let { seat ->
        val districtMembers = remember(allMembers, seat) {
            allMembers.filter {
                it.district.trim().equals(seat.districtNameBn.trim(), ignoreCase = true) ||
                        it.division.trim().equals(seat.divisionBn.trim(), ignoreCase = true)
            }
        }

        AlertDialog(
            onDismissRequest = { seatForAppointDialog = null },
            icon = { Icon(Icons.Default.PersonAdd, contentDescription = null, tint = BSNGreenPrimary) },
            title = {
                Text(
                    text = "${seat.districtNameBn} জেলায় এডমিন নিয়োগ",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "বিভাগ: ${seat.divisionBn} • আসন নং: ${seat.seatNumber}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "যাচাইকৃত সদস্য তালিকা থেকে জেলা এডমিন নির্বাচন করুন:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    if (districtMembers.isEmpty()) {
                        Text(
                            "এই জেলায় কোনো নিবন্ধিত সদস্য পাওয়া যায়নি। প্রথমে সদস্য নিবন্ধন করতে হবে।",
                            color = BSNRedAlert,
                            fontSize = 12.sp
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                        ) {
                            items(districtMembers) { member ->
                                val isSelected = selectedMemberToAppoint?.id == member.id
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) BSNGreenPrimary.copy(alpha = 0.15f) else Color.White
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) BSNGreenPrimary else Color(0xFFE0E0E0)
                                    ),
                                    onClick = { selectedMemberToAppoint = member }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(member.fullName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text("${member.id} • ${member.profession}", fontSize = 11.sp, color = Color.DarkGray)
                                            Text("ফোন: ${member.phone}", fontSize = 11.sp, color = Color.Gray)
                                        }
                                        if (isSelected) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BSNGreenPrimary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val member = selectedMemberToAppoint
                        if (member != null) {
                            onAppointAdmin(seat.districtId, member)
                            seatForAppointDialog = null
                            Toast.makeText(context, "${seat.districtNameBn} জেলা এডমিন হিসেবে ${member.fullName} কে নিয়োগ দেওয়া হয়েছে", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "অনুগ্রহ করে একজন সদস্য নির্বাচন করুন", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                    enabled = selectedMemberToAppoint != null
                ) {
                    Text("নিয়োগ নিশ্চিত করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { seatForAppointDialog = null }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Dialog 2: Suspend Admin Dialog
    seatForSuspendDialog?.let { seat ->
        AlertDialog(
            onDismissRequest = { seatForSuspendDialog = null },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = BSNRedAlert) },
            title = {
                Text("${seat.districtNameBn} জেলা এডমিন স্থগিতকরণ", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column {
                    Text(
                        "বর্তমান এডমিন: ${seat.adminName} (${seat.adminId})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = suspendReason,
                        onValueChange = { suspendReason = it },
                        label = { Text("স্থগিতের সুনির্দিষ্ট কারণ লিখুন") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (suspendReason.isNotBlank()) {
                            onSuspendAdmin(seat.districtId, suspendReason.trim())
                            seatForSuspendDialog = null
                            Toast.makeText(context, "এডমিন স্থগিত করা হয়েছে", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "স্থগিতের কারণ লেখা বাধ্যতামূলক", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert)
                ) {
                    Text("স্থগিত করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { seatForSuspendDialog = null }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Dialog 3: Remove Admin Dialog
    seatForRemoveDialog?.let { seat ->
        AlertDialog(
            onDismissRequest = { seatForRemoveDialog = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = BSNRedAlert) },
            title = {
                Text("${seat.districtNameBn} জেলা এডমিন পদ প্রত্যাহার", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Text(
                    "${seat.adminName} (${seat.adminId}) কে ${seat.districtNameBn} জেলার এডমিন পদ থেকে প্রত্যাহার করা হবে। আসনটি শূন্য (Vacant) হবে এবং তিনি সাধারণ সদস্য হিসেবে থাকবেন।",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRemoveAdmin(seat.districtId)
                        seatForRemoveDialog = null
                        Toast.makeText(context, "এডমিন পদ সফলভাবে প্রত্যাহার করা হয়েছে", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert)
                ) {
                    Text("অপসারণ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { seatForRemoveDialog = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
fun DistrictSeatCard(
    seat: DistrictAdminSeat,
    isSuperAdmin: Boolean,
    onAppointClick: () -> Unit,
    onSuspendClick: () -> Unit,
    onRemoveClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = BSNGreenDark.copy(alpha = 0.12f)
                    ) {
                        Text(
                            "আসন #${seat.seatNumber}",
                            color = BSNGreenDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "${seat.districtNameBn} জেলা",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = BSNGreenDark
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("(${seat.divisionBn})", fontSize = 11.sp, color = Color.Gray)
                }

                // Seat Status Badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = when (seat.status) {
                        DistrictAdminSeat.STATUS_ASSIGNED -> BSNGreenDark.copy(alpha = 0.15f)
                        DistrictAdminSeat.STATUS_SUSPENDED -> BSNRedAlert.copy(alpha = 0.15f)
                        else -> Color(0xFFF0F0F0)
                    }
                ) {
                    Text(
                        text = when (seat.status) {
                            DistrictAdminSeat.STATUS_ASSIGNED -> "● সক্রিয় এডমিন"
                            DistrictAdminSeat.STATUS_SUSPENDED -> "● স্থগিত"
                            else -> "○ খালি পদ (Vacant)"
                        },
                        color = when (seat.status) {
                            DistrictAdminSeat.STATUS_ASSIGNED -> BSNGreenDark
                            DistrictAdminSeat.STATUS_SUSPENDED -> BSNRedAlert
                            else -> Color.DarkGray
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (seat.status == DistrictAdminSeat.STATUS_ASSIGNED || seat.status == DistrictAdminSeat.STATUS_SUSPENDED) {
                Surface(
                    color = Color(0xFFF9FBF9),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "বর্তমান এডমিন: ${seat.adminName} (${seat.adminId})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF191C1A)
                        )
                        if (seat.adminPhone.isNotBlank()) {
                            Text("ফোন: ${seat.adminPhone} | ইমেইল: ${seat.adminEmail}", fontSize = 11.sp, color = Color.DarkGray)
                        }
                        if (seat.status == DistrictAdminSeat.STATUS_SUSPENDED && seat.suspensionReason.isNotBlank()) {
                            Text("স্থগিতের কারণ: ${seat.suspensionReason}", color = BSNRedAlert, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            } else {
                Text(
                    "এই জেলায় কোনো এডমিন এখনো নিয়োগ দেওয়া হয়নি। আসনটি খালি রয়েছে।",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            // Super Admin Action Buttons
            if (isSuperAdmin) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (seat.status == DistrictAdminSeat.STATUS_VACANT) {
                        Button(
                            onClick = onAppointClick,
                            colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.AddModerator, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("এডমিন নিয়োগ দিন", fontSize = 11.sp)
                        }
                    } else {
                        OutlinedButton(
                            onClick = onAppointClick,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("পরিবর্তন", fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.width(6.dp))

                        if (seat.status == DistrictAdminSeat.STATUS_ASSIGNED) {
                            OutlinedButton(
                                onClick = onSuspendClick,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = BSNRedAlert),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("স্থগিত", fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                        }

                        Button(
                            onClick = onRemoveClick,
                            colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text("অপসারণ", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SeatStatBadge(label: String, count: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(count, fontWeight = FontWeight.Black, fontSize = 16.sp, color = color)
        Text(label, fontSize = 10.sp, color = Color.Gray)
    }
}
