package com.example.ui.components

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.Member
import com.example.ui.theme.BSNGold
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert

@Composable
fun DigitalIdCardDialog(
    member: Member,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .testTag("digital_id_card_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header Bar (Green gradient with Gold accents)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(BSNGreenDark, BSNGreenPrimary)
                            )
                        )
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.bsn_logo),
                                contentDescription = "BSN Logo",
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, BSNGold, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "BSN DIGITAL PRESS ID",
                                    color = BSNGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "বাংলাদেশ সাংবাদিক নেটওয়ার্ক",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White
                            )
                        }
                    }
                }

                // ID Card Body
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Profile Photo with Verified Ring
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(BSNGreenPrimary.copy(alpha = 0.1f))
                            .border(2.5.dp, if (member.isVerified) BSNGold else BSNRedAlert, CircleShape)
                            .padding(4.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.bsn_logo),
                            contentDescription = "Member Photo",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = member.fullName,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = BSNGreenDark,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "${member.profession} • ${member.organization}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF404943),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // ID Badge & Verification Status
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = BSNGreenPrimary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "আইডি নং: ${member.id}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = BSNGreenDark,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (member.idCardStatus == Member.ID_STATUS_APPROVED || member.isVerified) BSNGold.copy(alpha = 0.2f) else BSNRedAlert.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (member.idCardStatus == Member.ID_STATUS_APPROVED || member.isVerified) BSNGreenDark else BSNRedAlert,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = if (member.idCardStatus == Member.ID_STATUS_APPROVED || member.isVerified) "যাচাইকৃত প্রেস মেম্বার (Approved)" else "অপেক্ষমাণ (Pending Verification)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (member.idCardStatus == Member.ID_STATUS_APPROVED || member.isVerified) BSNGreenDark else BSNRedAlert
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Details Grid Card
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFF7FBF8),
                        border = BorderStroke(1.dp, Color(0xFFE0E5E1))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            IdInfoRow(label = "বিভাগ ও জেলা", value = "${member.division} • ${member.district} (${member.upazila})")
                            IdInfoRow(label = "মোবাইল নম্বর", value = member.phone)
                            IdInfoRow(label = "রক্তের গ্রুপ", value = member.bloodGroup.ifBlank { "O+" })
                            IdInfoRow(label = "জরুরি যোগাযোগ", value = member.emergencyContact.ifBlank { "01989888856" })
                            IdInfoRow(label = "ঠিকানা", value = member.address.ifBlank { "${member.upazila}, ${member.district}" })
                            if (member.isDistrictAdmin()) {
                                IdInfoRow(label = "প্রশাসনিক পদবী", value = "${member.assignedDistrictSeat} জেলা এডমিন (BSN Admin)")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Realistic Verification QR Code Box
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF0F4F1),
                        border = BorderStroke(1.dp, Color(0xFFDDE3DF))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Canvas QR Code
                            androidx.compose.foundation.Canvas(
                                modifier = Modifier
                                    .size(60.dp)
                                    .background(Color.White, RoundedCornerShape(4.dp))
                                    .padding(4.dp)
                            ) {
                                val s = size.minDimension
                                val step = s / 7f

                                // Top-Left Finder
                                drawRect(Color.Black, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Size(step * 3, step * 3))
                                drawRect(Color.White, androidx.compose.ui.geometry.Offset(step * 0.5f, step * 0.5f), androidx.compose.ui.geometry.Size(step * 2, step * 2))
                                drawRect(Color.Black, androidx.compose.ui.geometry.Offset(step, step), androidx.compose.ui.geometry.Size(step, step))

                                // Top-Right Finder
                                drawRect(Color.Black, androidx.compose.ui.geometry.Offset(s - step * 3, 0f), androidx.compose.ui.geometry.Size(step * 3, step * 3))
                                drawRect(Color.White, androidx.compose.ui.geometry.Offset(s - step * 2.5f, step * 0.5f), androidx.compose.ui.geometry.Size(step * 2, step * 2))
                                drawRect(Color.Black, androidx.compose.ui.geometry.Offset(s - step * 2, step), androidx.compose.ui.geometry.Size(step, step))

                                // Bottom-Left Finder
                                drawRect(Color.Black, androidx.compose.ui.geometry.Offset(0f, s - step * 3), androidx.compose.ui.geometry.Size(step * 3, step * 3))
                                drawRect(Color.White, androidx.compose.ui.geometry.Offset(step * 0.5f, s - step * 2.5f), androidx.compose.ui.geometry.Size(step * 2, step * 2))
                                drawRect(Color.Black, androidx.compose.ui.geometry.Offset(step, s - step * 2), androidx.compose.ui.geometry.Size(step, step))

                                // Random looking data points
                                drawRect(Color.Black, androidx.compose.ui.geometry.Offset(step * 4, step * 3), androidx.compose.ui.geometry.Size(step, step))
                                drawRect(Color.Black, androidx.compose.ui.geometry.Offset(step * 3, step * 4), androidx.compose.ui.geometry.Size(step, step))
                                drawRect(Color.Black, androidx.compose.ui.geometry.Offset(step * 5, step * 5), androidx.compose.ui.geometry.Size(step, step))
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "🔒 BSN QR SECURITY TOKEN",
                                    fontSize = 9.sp,
                                    color = BSNGreenDark,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "টোকেন: ${if (member.qrToken.isNotBlank()) member.qrToken else "BSN-SEC-${member.id}"}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.Black
                                )
                                Text(
                                    text = "যাচাই লিংক: bsn-network.web.app/v/${member.id}",
                                    fontSize = 9.sp,
                                    color = Color.Gray,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Share button
                    Button(
                        onClick = {
                            val shareText = """
                                🪪 BSN বাংলাদেশ সাংবাদিক নেটওয়ার্ক - ডিজিটাল প্রেস কার্ড
                                নাম: ${member.fullName}
                                সদস্য আইডি: ${member.id}
                                পদবি: ${member.profession} (${member.organization})
                                জেলা: ${member.district}, ${member.division}
                                ফোন: ${member.phone} | রক্তের গ্রুপ: ${member.bloodGroup}
                                অনলাইন যাচাইকরণ: https://rrmtv994-ops.github.io/bsn-bangladesh-journalist-network/
                            """.trimIndent()

                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, shareText)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "ডিজিটাল আইডি শেয়ার করুন"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share ID",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ডিজিটাল প্রেস কার্ড শেয়ার করুন",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IdInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = Color.Gray,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF191C1A)
        )
    }
}
