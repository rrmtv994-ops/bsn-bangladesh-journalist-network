package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatMessage
import com.example.data.model.Member
import com.example.data.repository.BSNRepository
import com.example.ui.theme.BSNGold
import com.example.ui.theme.BSNGreenDark
import com.example.ui.theme.BSNGreenPrimary
import com.example.ui.theme.BSNRedAlert
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
    currentMember: Member,
    allMembers: List<Member>,
    repository: BSNRepository
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedPersonalMember by remember { mutableStateOf<Member?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (selectedPersonalMember != null) {
            PersonalChatConversationView(
                currentMember = currentMember,
                chatPartner = selectedPersonalMember!!,
                repository = repository,
                onBack = { selectedPersonalMember = null }
            )
        } else {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = BSNGreenPrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Group, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("BSN গ্রুপ চ্যাট", fontWeight = FontWeight.Bold)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ব্যক্তিগত বার্তা (Direct)", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            when (selectedTab) {
                0 -> GroupChatView(currentMember = currentMember, repository = repository)
                1 -> PersonalChatMembersListView(
                    currentMember = currentMember,
                    allMembers = allMembers,
                    onSelectPartner = { selectedPersonalMember = it }
                )
            }
        }
    }
}

@Composable
fun GroupChatView(
    currentMember: Member,
    repository: BSNRepository
) {
    val messages by repository.groupMessages.collectAsStateWithLifecycle(initialValue = emptyList())
    var messageText by remember { mutableStateOf("") }
    var isEmergencyChecked by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Group Header Info
        Surface(
            color = BSNGreenDark,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Group, contentDescription = null, tint = BSNGold, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        "বাংলাদেশ সাংবাদিক নেটওয়ার্ক — কেন্দ্রীয় বার্তা চ্যানেল",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        "সকল সদস্য, জেলা এডমিন ও BSN 001 সমন্বয় চ্যানেল",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "কোনো বার্তা নেই। প্রথম বার্তা পাঠান!",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            items(messages) { msg ->
                val isMe = msg.senderId == currentMember.id
                ChatMessageBubble(msg = msg, isMe = isMe)
            }
        }

        // Message Input
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                if (isEmergencyChecked) {
                    Surface(
                        color = BSNRedAlert.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = BSNRedAlert, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("🚨 জরুরি সংকেত মোড সক্রিয় — এই বার্তাটি বিশেষ গুরুত্ব পাবে", color = BSNRedAlert, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { isEmergencyChecked = !isEmergencyChecked },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "জরুরি ফ্ল্যাগ",
                            tint = if (isEmergencyChecked) BSNRedAlert else Color.Gray
                        )
                    }

                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it },
                        placeholder = { Text("বার্তা লিখুন...", fontSize = 13.sp) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BSNGreenPrimary,
                            unfocusedBorderColor = Color(0xFFD0D7D2)
                        ),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = {
                            if (messageText.isNotBlank()) {
                                val newMsg = ChatMessage(
                                    type = ChatMessage.TYPE_GROUP,
                                    chatId = ChatMessage.GLOBAL_CHAT_ID,
                                    senderId = currentMember.id,
                                    senderName = currentMember.fullName,
                                    senderRole = when {
                                        currentMember.isSuperAdmin() -> "BSN 001"
                                        currentMember.isDistrictAdmin() -> "${currentMember.assignedDistrictSeat} এডমিন"
                                        else -> currentMember.role
                                    },
                                    senderDistrict = currentMember.district,
                                    text = messageText.trim(),
                                    isEmergency = isEmergencyChecked,
                                    timestamp = System.currentTimeMillis()
                                )
                                scope.launch {
                                    repository.sendChatMessage(newMsg)
                                    messageText = ""
                                    isEmergencyChecked = false
                                }
                            }
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (messageText.isNotBlank()) BSNGreenPrimary else Color.LightGray)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "পাঠান", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatMessageBubble(msg: ChatMessage, isMe: Boolean) {
    val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val formattedTime = remember(msg.timestamp) { timeFormat.format(Date(msg.timestamp)) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 14.dp,
                topEnd = 14.dp,
                bottomStart = if (isMe) 14.dp else 2.dp,
                bottomEnd = if (isMe) 2.dp else 14.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = when {
                    msg.isEmergency -> BSNRedAlert.copy(alpha = 0.12f)
                    isMe -> BSNGreenPrimary
                    else -> Color(0xFFE8ECE9)
                }
            ),
            modifier = Modifier.fillMaxWidth(0.82f)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (!isMe) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "${msg.senderName} (${msg.senderId})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (msg.senderRole == "BSN 001") BSNRedAlert else BSNGreenDark
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (msg.senderRole == "BSN 001") BSNGold else Color.White
                        ) {
                            Text(
                                text = msg.senderRole,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (msg.senderRole == "BSN 001") Color.Black else Color.DarkGray,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Text(
                    text = msg.text,
                    fontSize = 14.sp,
                    color = if (isMe && !msg.isEmergency) Color.White else Color(0xFF191C1A)
                )

                Spacer(modifier = Modifier.height(3.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (msg.senderDistrict.isNotBlank()) {
                        Text(
                            text = "${msg.senderDistrict} • ",
                            fontSize = 10.sp,
                            color = if (isMe && !msg.isEmergency) Color.White.copy(alpha = 0.75f) else Color.Gray
                        )
                    }
                    Text(
                        text = formattedTime,
                        fontSize = 10.sp,
                        color = if (isMe && !msg.isEmergency) Color.White.copy(alpha = 0.75f) else Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
fun PersonalChatMembersListView(
    currentMember: Member,
    allMembers: List<Member>,
    onSelectPartner: (Member) -> Unit
) {
    val partners = remember(allMembers, currentMember) {
        allMembers.filter { it.id != currentMember.id }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                "সদস্য নির্বাচন করে সরাসরি ব্যক্তিগত বার্তা শুরু করুন",
                fontSize = 12.sp,
                color = Color.DarkGray,
                modifier = Modifier.padding(12.dp)
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            items(partners) { partner ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onSelectPartner(partner) },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(BSNGreenPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = BSNGreenDark)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(partner.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("(${partner.id})", fontSize = 11.sp, color = Color.Gray)
                            }
                            Text("${partner.profession} • ${partner.district}", fontSize = 12.sp, color = Color.DarkGray)
                        }

                        if (partner.isSuperAdmin()) {
                            Surface(
                                color = BSNGold,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    "BSN 001",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        } else if (partner.isDistrictAdmin()) {
                            Surface(
                                color = BSNGreenDark,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    "জেলা এডমিন",
                                    fontSize = 10.sp,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PersonalChatConversationView(
    currentMember: Member,
    chatPartner: Member,
    repository: BSNRepository,
    onBack: () -> Unit
) {
    val chatId = remember(currentMember.id, chatPartner.id) {
        ChatMessage.createPersonalChatId(currentMember.id, chatPartner.id)
    }
    val messages by repository.getPersonalMessages(chatId).collectAsStateWithLifecycle(initialValue = emptyList())
    var messageText by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Chat Header
        Surface(
            color = BSNGreenDark,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        "${chatPartner.fullName} (${chatPartner.id})",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        "${chatPartner.profession} • ${chatPartner.district}",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Messages list
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "এই সদস্যের সাথে কোনো বার্তা বিনিময় হয়নি। সালাম দিন!",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            items(messages) { msg ->
                val isMe = msg.senderId == currentMember.id
                ChatMessageBubble(msg = msg, isMe = isMe)
            }
        }

        // Input Box
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = messageText,
                    onValueChange = { messageText = it },
                    placeholder = { Text("বার্তা লিখুন...", fontSize = 13.sp) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BSNGreenPrimary,
                        unfocusedBorderColor = Color(0xFFD0D7D2)
                    ),
                    maxLines = 3
                )

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = {
                        if (messageText.isNotBlank()) {
                            val newMsg = ChatMessage(
                                type = ChatMessage.TYPE_PERSONAL,
                                chatId = chatId,
                                senderId = currentMember.id,
                                senderName = currentMember.fullName,
                                senderRole = currentMember.role,
                                senderDistrict = currentMember.district,
                                receiverId = chatPartner.id,
                                receiverName = chatPartner.fullName,
                                text = messageText.trim(),
                                timestamp = System.currentTimeMillis()
                            )
                            scope.launch {
                                repository.sendChatMessage(newMsg)
                                messageText = ""
                            }
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (messageText.isNotBlank()) BSNGreenPrimary else Color.LightGray)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "পাঠান", tint = Color.White)
                }
            }
        }
    }
}
