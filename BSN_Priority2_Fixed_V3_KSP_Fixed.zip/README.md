<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/b7f03b7a-c00e-40aa-be56-4e5a0add6868

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## Firestore security rules (V3)

The root `firestore.rules` file uses a default-deny policy for signed-out users. After login:

- Members can read the member directory and read news/chat messages.
- A member can create their own profile using the same email as their Firebase Authentication account, and update only their own basic profile fields. Admin/verification/ID-card/member-status fields are protected.
- A member can create news and chat messages only when the referenced `reporterId` / `senderId` belongs to their authenticated email. They can update or delete only their own news/messages.
- The optional `registration_requests` collection supports create/read/update for the request owner's email; only the Super Admin can delete requests.
- The verified Firebase account `rrmrimonshikder@gmail.com` has full access to all collections. Other unlisted collections (including notices, audit logs, alerts and district admin seats) are Super-Admin-only.

**Important app integration note:** `members/{memberId}.email` must match the signed-in Firebase Auth email. News must store the member document ID in `reporterId`; chat must store it in `senderId`. Deploy the rules in Firebase Console → Firestore Database → Rules, then click **Publish**. Rules in the ZIP do not deploy themselves.

## Android SHA-1 guide

See `SHA1_ANDROID_STUDIO_GUIDE_BN.md` for step-by-step Bengali instructions to find the debug/release SHA-1 from Android Studio's Gradle `signingReport` task.
