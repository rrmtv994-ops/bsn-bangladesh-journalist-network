package com.bsn.admin

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.AddModerator
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationAdd
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// BSN Official Palette
val BSNGreenPrimary = Color(0xFF006A4E)
val BSNGreenDark = Color(0xFF004D38)
val BSNRedAlert = Color(0xFFDA291C)
val BSNGold = Color(0xFFF4B400)

data class AdminSeatData(
    val districtId: String = "",
    val seatNumber: Int = 0,
    val districtNameBn: String = "",
    val divisionBn: String = "",
    val adminId: String = "",
    val adminName: String = "",
    val adminPhone: String = "",
    val adminEmail: String = "",
    val status: String = "Vacant", // Vacant, Assigned, Suspended
    val suspensionReason: String = ""
)

data class AdminMemberData(
    val id: String = "",
    val fullName: String = "",
    val phone: String = "",
    val email: String = "",
    val district: String = "",
    val profession: String = "",
    val organization: String = "",
    val role: String = "সদস্য",
    val isAdmin: Boolean = false,
    val isVerified: Boolean = false,
    val membershipStatus: String = "Active", // Active, Suspended, Revoked
    val idCardStatus: String = "Pending",   // Pending, Approved, Rejected
    val cancellationReason: String = ""
)

data class AdminNewsData(
    val id: String = "",
    val title: String = "",
    val content: String = "",
    val authorName: String = "",
    val district: String = "",
    val status: String = "Pending", // Pending, Approved, Rejected
    val timestamp: Long = System.currentTimeMillis()
)

data class AdminAlertData(
    val id: String = "",
    val memberName: String = "",
    val memberPhone: String = "",
    val district: String = "",
    val emergencyType: String = "",
    val message: String = "",
    val status: String = "ACTIVE",
    val timestamp: Long = System.currentTimeMillis()
)

data class AuditLogEntry(
    val id: String = "",
    val action: String = "",
    val performedBy: String = "BSN 001 (Super Admin)",
    val details: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

class AdminMainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = BSNGreenPrimary,
                    background = Color(0xFFF8FAF8),
                    surface = Color.White
                )
            ) {
                AdminAccessGate {
                    MainAdminApp()
                }
            }
        }
    }
}

@Composable
private fun AdminAccessGate(onAuthorized: @Composable () -> Unit) {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    val credentialManager = remember { CredentialManager.create(context) }
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("rrmrimonshikder@gmail.com") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var signedInUser by remember { mutableStateOf(auth.currentUser) }

    val founderEmail = "rrmrimonshikder@gmail.com"
    val currentEmail = signedInUser?.email
    if (signedInUser != null && currentEmail.equals(founderEmail, ignoreCase = true) && signedInUser?.isEmailVerified == true) {
        onAuthorized()
        return
    }

    if (signedInUser != null) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF8FAF8)) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.Block, contentDescription = null, tint = BSNRedAlert, modifier = Modifier.size(48.dp))
                Text("প্রবেশাধিকার নেই", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = BSNRedAlert)
                Text("এই Main Admin App-এ শুধু BSN 001 (মোঃ রিমন শিকদার) প্রবেশ করতে পারবেন।", color = Color.DarkGray)
                Text("বর্তমান অ্যাকাউন্ট: ${currentEmail ?: "অজানা"}", color = Color.Gray)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { auth.signOut(); signedInUser = null }, colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary)) {
                    Text("অন্য অ্যাকাউন্ট দিয়ে প্রবেশ করুন")
                }
            }
        }
        return
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF8FAF8)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(painter = painterResource(id = R.drawable.bsn_logo), contentDescription = "BSN Logo", modifier = Modifier.size(84.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            Spacer(Modifier.height(14.dp))
            Text("BSN Main Admin", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = BSNGreenDark)
            Text("শুধুমাত্র BSN 001 Super Admin-এর জন্য", color = BSNGreenPrimary)
            Spacer(Modifier.height(20.dp))
            if (loading) CircularProgressIndicator(color = BSNGreenPrimary)
            Button(
                enabled = !loading,
                onClick = {
                    scope.launch {
                        loading = true
                        try {
                            val option = GetSignInWithGoogleOption.Builder(
                                serverClientId = "320796438662-pft9mntftp3j53n9mf7cq5vrqr2k59ab.apps.googleusercontent.com"
                            ).build()
                            val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                            val response = credentialManager.getCredential(request, context as Activity)
                            val credential = response.credential
                            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                val google = GoogleIdTokenCredential.createFrom(credential.data)
                                val firebaseCredential = GoogleAuthProvider.getCredential(google.idToken, null)
                                val user = auth.signInWithCredential(firebaseCredential).await().user
                                if (user?.email.equals(founderEmail, ignoreCase = true) && user?.isEmailVerified == true) signedInUser = user
                                else { auth.signOut(); Toast.makeText(context, "শুধুমাত্র যাচাইকৃত BSN 001 অ্যাকাউন্ট অনুমোদিত", Toast.LENGTH_LONG).show() }
                            }
                        } catch (e: Exception) {
                            Toast.makeText(context, "Google/Firebase সাইন-ইন ব্যর্থ: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        } finally { loading = false }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BSNGreenDark),
                modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(12.dp)
            ) { Text("Google দিয়ে BSN 001 প্রবেশ") }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Founder Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                enabled = !loading,
                onClick = {
                    if (!email.equals(founderEmail, ignoreCase = true)) {
                        Toast.makeText(context, "শুধুমাত্র BSN 001 ইমেইল অনুমোদিত", Toast.LENGTH_LONG).show()
                        return@OutlinedButton
                    }
                    scope.launch {
                        loading = true
                        try {
                            val user = auth.signInWithEmailAndPassword(email.trim(), password).await().user
                            if (user?.email.equals(founderEmail, ignoreCase = true) && user?.isEmailVerified == true) signedInUser = user
                            else { auth.signOut(); Toast.makeText(context, "BSN 001-এর যাচাইকৃত ইমেইল প্রয়োজন", Toast.LENGTH_LONG).show() }
                        } catch (e: Exception) {
                            Toast.makeText(context, "Firebase লগইন ব্যর্থ: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        } finally { loading = false }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(12.dp)
            ) { Text("ইমেইল ও পাসওয়ার্ড দিয়ে প্রবেশ") }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainAdminApp() {
    val context = LocalContext.current
    val firestore = remember { FirebaseFirestore.getInstance() }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        "৬৫ এডমিন পদ",
        "সদস্য পরিচালনা",
        "আইডি কার্ড অনুমোদন",
        "সংবাদ নিয়ন্ত্রণ",
        "HIGH ALERT",
        "অডিট লগ"
    )

    var seats by remember { mutableStateOf<List<AdminSeatData>>(emptyList()) }
    var members by remember { mutableStateOf<List<AdminMemberData>>(emptyList()) }
    var newsList by remember { mutableStateOf<List<AdminNewsData>>(emptyList()) }
    var alertList by remember { mutableStateOf<List<AdminAlertData>>(emptyList()) }
    var auditLogs by remember { mutableStateOf<List<AuditLogEntry>>(emptyList()) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedDivision by remember { mutableStateOf("সকল") }

    // Dialog state
    var seatToAppoint by remember { mutableStateOf<AdminSeatData?>(null) }
    var selectedMemberForSeat by remember { mutableStateOf<AdminMemberData?>(null) }
    var seatToSuspend by remember { mutableStateOf<AdminSeatData?>(null) }
    var suspendReason by remember { mutableStateOf("") }
    var seatToVacate by remember { mutableStateOf<AdminSeatData?>(null) }

    var memberToCancel by remember { mutableStateOf<AdminMemberData?>(null) }
    var cancelReason by remember { mutableStateOf("") }

    // Realtime listeners
    DisposableEffect(Unit) {
        val seatsListener = firestore.collection("district_admin_seats")
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null && !snapshot.isEmpty) {
                    seats = snapshot.documents.mapNotNull { it.toObject(AdminSeatData::class.java) }
                        .sortedBy { it.seatNumber }
                }
            }

        val membersListener = firestore.collection("members")
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null && !snapshot.isEmpty) {
                    members = snapshot.documents.mapNotNull { it.toObject(AdminMemberData::class.java) }
                }
            }

        val newsListener = firestore.collection("news")
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null && !snapshot.isEmpty) {
                    newsList = snapshot.documents.mapNotNull { it.toObject(AdminNewsData::class.java) }
                        .sortedByDescending { it.timestamp }
                }
            }

        val alertsListener = firestore.collection("emergency_alerts")
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null && !snapshot.isEmpty) {
                    alertList = snapshot.documents.mapNotNull { it.toObject(AdminAlertData::class.java) }
                        .sortedByDescending { it.timestamp }
                }
            }

        val auditListener = firestore.collection("audit_logs")
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null && !snapshot.isEmpty) {
                    auditLogs = snapshot.documents.mapNotNull { it.toObject(AuditLogEntry::class.java) }
                        .sortedByDescending { it.timestamp }
                }
            }

        onDispose {
            seatsListener.remove()
            membersListener.remove()
            newsListener.remove()
            alertsListener.remove()
            auditListener.remove()
        }
    }

    Scaffold(
        topBar = {
            Surface(
                color = Color(0xFF1E293B),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.bsn_logo),
                            contentDescription = "BSN Logo",
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("BSN MAIN ADMIN APP", color = BSNGold, fontWeight = FontWeight.Black, fontSize = 15.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(shape = RoundedCornerShape(4.dp), color = BSNGold) {
                                    Text("BSN 001", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black, modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp))
                                }
                            }
                            Text("প্রতিষ্ঠাতা ও কর্ণধার: মোঃ রিমন শিকদার • সর্বোচ্চ নিয়ন্ত্রণ", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                        }
                    }

                    IconButton(
                        onClick = {
                            scope.launch {
                                try {
                                    val seatsSnap = firestore.collection("district_admin_seats").get().await()
                                    seats = seatsSnap.documents.mapNotNull { it.toObject(AdminSeatData::class.java) }
                                    val membersSnap = firestore.collection("members").get().await()
                                    members = membersSnap.documents.mapNotNull { it.toObject(AdminMemberData::class.java) }
                                    Toast.makeText(context, "সার্ভার ডাটা রিফ্রেশ সম্পন্ন", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "রিফ্রেশে ত্রুটি: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "রিফ্রেশ", tint = Color.White)
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 8.dp,
                containerColor = Color.White,
                contentColor = BSNGreenPrimary
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == index) BSNGreenPrimary else Color.Gray
                            )
                        }
                    )
                }
            }

            when (selectedTab) {
                0 -> {
                    // 65 Admin Seats
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            // Super Admin Card (Seat 1 - Permanent)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                border = BorderStroke(2.dp, BSNGold)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = BSNGold
                                        ) {
                                            Text(
                                                "পদবী ১ / ৬৫ • SUPER ADMIN",
                                                color = Color.Black,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Black,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                        Text("স্থায়ী ও অপরিবর্তনীয়", color = BSNGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("মোঃ রিমন শিকদার", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text("প্রতিষ্ঠাতা ও কর্ণধার • বাংলাদেশ সাংবাদিক নেটওয়ার্ক", color = BSNGold, fontSize = 13.sp)
                                    Text("আইডি: BSN 001 | ফোন: 01989888856 | ঠিকানা: ঢাকা, বাংলাদেশ", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)

                                    Spacer(modifier = Modifier.height(8.dp))
                                    HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "• সমগ্র বাংলাদেশের ৬৪ জেলার সাংবাদিক নেটওয়ার্ক ও ৬৫ জন এডমিনের একমাত্র সর্বোচ্চ নিয়ন্ত্রণকারী।\n• এই পদ কোনো অবস্থাতেই বাতিল বা বরখাস্তযোগ্য নয়।",
                                        color = Color(0xFFE2E8F0),
                                        fontSize = 11.sp,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }

                        item {
                            // Filter section
                            Text("৬৪ জেলা এডমিন পদসমূহ (পদ ২ থেকে ৬৫)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BSNGreenDark)

                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("জেলা বা এডমিনের নাম দিয়ে খুঁজুন...") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp)
                            )

                            Spacer(modifier = Modifier.height(8.dp))
                            val divisions = listOf("সকল", "ঢাকা", "চট্টগ্রাম", "রাজশাহী", "খুলনা", "বরিশাল", "সিলেট", "রংপুর", "ময়মনসিংহ")
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                divisions.forEach { div ->
                                    FilterChip(
                                        selected = selectedDivision == div,
                                        onClick = { selectedDivision = div },
                                        label = { Text(div, fontSize = 11.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = BSNGreenPrimary,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }
                        }

                        val filteredSeats = seats.filter { seat ->
                            (selectedDivision == "সকল" || seat.divisionBn == selectedDivision) &&
                            (searchQuery.isBlank() || seat.districtNameBn.contains(searchQuery) || seat.adminName.contains(searchQuery))
                        }

                        items(filteredSeats) { seat ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(
                                    1.dp,
                                    when (seat.status) {
                                        "Assigned" -> BSNGreenPrimary
                                        "Suspended" -> BSNRedAlert
                                        else -> Color.LightGray
                                    }
                                )
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = Color(0xFFF1F5F9)
                                            ) {
                                                Text(
                                                    "পদ #${seat.seatNumber}",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF334155),
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(seat.districtNameBn, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("(${seat.divisionBn} বিভাগ)", fontSize = 12.sp, color = Color.Gray)
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = when (seat.status) {
                                                "Assigned" -> BSNGreenPrimary.copy(alpha = 0.15f)
                                                "Suspended" -> BSNRedAlert.copy(alpha = 0.15f)
                                                else -> Color.LightGray.copy(alpha = 0.3f)
                                            }
                                        ) {
                                            Text(
                                                when (seat.status) {
                                                    "Assigned" -> "দায়িত্বপ্রাপ্ত"
                                                    "Suspended" -> "সাময়িক বরখাস্ত"
                                                    else -> "খালি পদ"
                                                },
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when (seat.status) {
                                                    "Assigned" -> BSNGreenPrimary
                                                    "Suspended" -> BSNRedAlert
                                                    else -> Color.DarkGray
                                                },
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    if (seat.status == "Assigned" || seat.status == "Suspended") {
                                        Text("এডমিন: ${seat.adminName}", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                        Text("আইডি: ${seat.adminId} | ফোন: ${seat.adminPhone}", fontSize = 12.sp, color = Color.Gray)
                                        if (seat.status == "Suspended") {
                                            Text("বরখাস্তের কারণ: ${seat.suspensionReason}", fontSize = 11.sp, color = BSNRedAlert)
                                        }
                                    } else {
                                        Text("এই জেলায় এখনো কোনো এডমিন নিয়োগ দেওয়া হয়নি।", fontSize = 12.sp, color = Color.Gray)
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (seat.status == "Vacant") {
                                            Button(
                                                onClick = {
                                                    seatToAppoint = seat
                                                    selectedMemberForSeat = null
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary)
                                            ) {
                                                Icon(Icons.Default.AddModerator, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("এডমিন নিয়োগ দিন", fontSize = 12.sp)
                                            }
                                        } else {
                                            if (seat.status == "Assigned") {
                                                OutlinedButton(
                                                    onClick = {
                                                        seatToSuspend = seat
                                                        suspendReason = ""
                                                    },
                                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BSNRedAlert)
                                                ) {
                                                    Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("বরখাস্ত", fontSize = 12.sp)
                                                }
                                            } else {
                                                Button(
                                                    onClick = {
                                                        scope.launch {
                                                            firestore.collection("district_admin_seats")
                                                                .document(seat.districtId)
                                                                .update(
                                                                    mapOf(
                                                                        "status" to "Assigned",
                                                                        "suspensionReason" to ""
                                                                    )
                                                                ).await()
                                                            Toast.makeText(context, "${seat.districtNameBn} এডমিনের বরখাস্ত প্রত্যাহার হয়েছে", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary)
                                                ) {
                                                    Text("বহাল করুন", fontSize = 12.sp)
                                                }
                                            }

                                            Spacer(modifier = Modifier.width(6.dp))

                                            OutlinedButton(
                                                onClick = { seatToVacate = seat },
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.DarkGray)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("পদ শূন্য করুন", fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // Members Management
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text("সারাদেশের নিবন্ধিত সাংবাদিক সদস্যবৃন্দ (${members.size} জন)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BSNGreenDark)
                        }

                        items(members) { member ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(member.fullName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                            Text("${member.profession} • ${member.organization}", fontSize = 12.sp, color = Color.Gray)
                                            Text("জেলা: ${member.district} | ফোন: ${member.phone}", fontSize = 12.sp, color = Color.DarkGray)
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = when (member.membershipStatus) {
                                                "Active" -> BSNGreenPrimary.copy(alpha = 0.15f)
                                                else -> BSNRedAlert.copy(alpha = 0.15f)
                                            }
                                        ) {
                                            Text(
                                                when (member.membershipStatus) {
                                                    "Active" -> "সক্রিয়"
                                                    "Suspended" -> "স্থগিত"
                                                    "Revoked" -> "বাতিলকৃত"
                                                    else -> member.membershipStatus
                                                },
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (member.membershipStatus == "Active") BSNGreenPrimary else BSNRedAlert,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    if (member.cancellationReason.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("বাতিল/স্থগিতের কারণ: ${member.cancellationReason}", fontSize = 11.sp, color = BSNRedAlert)
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        if (member.id != "BSN_001" && member.phone != "01989888856") {
                                            if (member.membershipStatus == "Active") {
                                                OutlinedButton(
                                                    onClick = {
                                                        memberToCancel = member
                                                        cancelReason = ""
                                                    },
                                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BSNRedAlert)
                                                ) {
                                                    Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("সদস্যপদ বাতিল/স্থগিত", fontSize = 11.sp)
                                                }
                                            } else {
                                                Button(
                                                    onClick = {
                                                        scope.launch {
                                                            firestore.collection("members")
                                                                .document(member.id)
                                                                .update(
                                                                    mapOf(
                                                                        "membershipStatus" to "Active",
                                                                        "cancellationReason" to ""
                                                                    )
                                                                ).await()
                                                            Toast.makeText(context, "${member.fullName}-এর সদস্যপদ পুনর্বহাল করা হয়েছে", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary)
                                                ) {
                                                    Text("পুনর্বহাল করুন", fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // ID Card Approval
                    val pendingMembers = members.filter { it.idCardStatus == "Pending" || !it.isVerified }
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text("ডিজিটাল আইডি কার্ড আবেদন অনুমোদন (${pendingMembers.size} টি অপেক্ষমাণ)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BSNGreenDark)
                        }

                        if (pendingMembers.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("কোনো আবেদন অপেক্ষমাণ নেই। সব কার্ড অনুমোদিত।", color = Color.Gray, fontSize = 13.sp)
                                }
                            }
                        }

                        items(pendingMembers) { member ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(member.fullName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text("পদবী: ${member.profession} | প্রতিষ্ঠান: ${member.organization}", fontSize = 12.sp, color = Color.DarkGray)
                                    Text("জেলা: ${member.district} | ফোন: ${member.phone}", fontSize = 12.sp, color = Color.Gray)

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                scope.launch {
                                                    firestore.collection("members")
                                                        .document(member.id)
                                                        .update("idCardStatus", "Rejected").await()
                                                    Toast.makeText(context, "আইডি কার্ড আবেদন নাকচ করা হয়েছে", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = BSNRedAlert)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("প্রত্যাখ্যান", fontSize = 12.sp)
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Button(
                                            onClick = {
                                                scope.launch {
                                                    firestore.collection("members")
                                                        .document(member.id)
                                                        .update(
                                                            mapOf(
                                                                "idCardStatus" to "Approved",
                                                                "isVerified" to true,
                                                                "qrToken" to "BSN-${UUID.randomUUID().toString().take(8).uppercase()}"
                                                            )
                                                        ).await()
                                                    Toast.makeText(context, "${member.fullName}-এর কার্ড অনুমোদিত হয়েছে", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("অনুমোদন দিন", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // News Moderation
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text("সংবাদ ও প্রতিবেদন নিয়ন্ত্রণ (${newsList.size} টি)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BSNGreenDark)
                        }

                        if (newsList.isEmpty()) {
                            item {
                                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    Text("কোনো সংবাদ জমা পড়েনি।", color = Color.Gray, fontSize = 13.sp)
                                }
                            }
                        }

                        items(newsList) { item ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = if (item.status == "Approved") BSNGreenPrimary.copy(alpha = 0.15f) else Color(0xFFFFF3CD)
                                        ) {
                                            Text(
                                                item.status,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (item.status == "Approved") BSNGreenPrimary else Color(0xFF856404),
                                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(item.content, fontSize = 12.sp, color = Color.DarkGray, maxLines = 3)
                                    Text("লেখক: ${item.authorName} (${item.district})", fontSize = 11.sp, color = Color.Gray)

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                        if (item.status != "Approved") {
                                            Button(
                                                onClick = {
                                                    scope.launch {
                                                        firestore.collection("news").document(item.id).update("status", "Approved").await()
                                                        Toast.makeText(context, "সংবাদ প্রকাশিত হয়েছে", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary)
                                            ) {
                                                Text("প্রকাশ করুন", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                4 -> {
                    // HIGH ALERT Command
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = BSNRedAlert.copy(alpha = 0.1f),
                                border = BorderStroke(1.dp, BSNRedAlert),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = BSNRedAlert, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text("জরুরি রেসকিউ ও হাই এলার্ট কমান্ড", fontWeight = FontWeight.Bold, color = BSNRedAlert, fontSize = 14.sp)
                                        Text("সরাসরি ঘটনাস্থলে থাকা বিপন্ন সাংবাদিকদের সতর্কবার্তা নিয়ন্ত্রণ করুন", fontSize = 11.sp, color = Color.DarkGray)
                                    }
                                }
                            }
                        }

                        items(alertList) { alert ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, BSNRedAlert)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(alert.memberName, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BSNRedAlert)
                                        Text(alert.emergencyType, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BSNRedAlert)
                                    }
                                    Text("জেলা: ${alert.district} | ফোন: ${alert.memberPhone}", fontSize = 12.sp, color = Color.DarkGray)
                                    Text("বিবরণ: ${alert.message}", fontSize = 12.sp, color = Color.Black)
                                }
                            }
                        }
                    }
                }

                5 -> {
                    // Audit Trail
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text("অপরিবর্তনীয় অডিট ট্রেইল (Audit Logs)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = BSNGreenDark)
                        }

                        if (auditLogs.isEmpty()) {
                            item {
                                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    Text("কোনো লগ রেকর্ড নেই।", color = Color.Gray, fontSize = 13.sp)
                                }
                            }
                        }

                        items(auditLogs) { log ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(6.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(log.action, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0F172A))
                                        val dateStr = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(log.timestamp))
                                        Text(dateStr, fontSize = 10.sp, color = Color.Gray)
                                    }
                                    Text("কর্তা: ${log.performedBy}", fontSize = 11.sp, color = BSNGreenDark)
                                    Text("বিবরণ: ${log.details}", fontSize = 11.sp, color = Color.DarkGray)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Appoint Admin Dialog
    seatToAppoint?.let { seat ->
        AlertDialog(
            onDismissRequest = { seatToAppoint = null },
            title = { Text("${seat.districtNameBn} জেলার এডমিন নিয়োগ", fontWeight = FontWeight.Bold) },
            text = {
                val eligibleMembers = members.filter { it.district == seat.districtNameBn && it.membershipStatus == "Active" }
                Column {
                    Text("এই জেলার সক্রিয় সদস্যদের তালিকা থেকে এডমিন নির্বাচন করুন:", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    if (eligibleMembers.isEmpty()) {
                        Text("এই জেলায় এখনো কোনো সক্রিয় সদস্য নিবন্ধিত নেই।", color = BSNRedAlert, fontSize = 12.sp)
                    } else {
                        LazyColumn(modifier = Modifier.height(180.dp)) {
                            items(eligibleMembers) { mem ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    FilterChip(
                                        selected = selectedMemberForSeat?.id == mem.id,
                                        onClick = { selectedMemberForSeat = mem },
                                        label = { Text("${mem.fullName} (${mem.phone})", fontSize = 12.sp) }
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val chosen = selectedMemberForSeat
                        if (chosen != null) {
                            scope.launch {
                                firestore.collection("district_admin_seats")
                                    .document(seat.districtId)
                                    .update(
                                        mapOf(
                                            "status" to "Assigned",
                                            "adminId" to chosen.id,
                                            "adminName" to chosen.fullName,
                                            "adminPhone" to chosen.phone,
                                            "adminEmail" to chosen.email,
                                            "suspensionReason" to ""
                                        )
                                    ).await()

                                firestore.collection("members")
                                    .document(chosen.id)
                                    .update(
                                        mapOf(
                                            "isAdmin" to true,
                                            "role" to "${seat.districtNameBn} জেলা এডমিন",
                                            "assignedDistrictSeat" to seat.seatNumber
                                        )
                                    ).await()

                                firestore.collection("audit_logs").document(UUID.randomUUID().toString()).set(
                                    AuditLogEntry(
                                        id = UUID.randomUUID().toString(),
                                        action = "DISTRICT_ADMIN_APPOINTED",
                                        details = "${seat.districtNameBn} জেলা এডমিন হিসেবে ${chosen.fullName} (${chosen.phone}) কে নিয়োগ প্রদান করা হয়েছে।"
                                    )
                                ).await()

                                Toast.makeText(context, "${chosen.fullName} কে ${seat.districtNameBn} জেলা এডমিন নিয়োগ দেওয়া হয়েছে", Toast.LENGTH_LONG).show()
                                seatToAppoint = null
                            }
                        }
                    },
                    enabled = selectedMemberForSeat != null,
                    colors = ButtonDefaults.buttonColors(containerColor = BSNGreenPrimary)
                ) {
                    Text("অনুমোদন দিন")
                }
            },
            dismissButton = {
                TextButton(onClick = { seatToAppoint = null }) { Text("বাতিল") }
            }
        )
    }

    // Suspend Admin Dialog
    seatToSuspend?.let { seat ->
        AlertDialog(
            onDismissRequest = { seatToSuspend = null },
            title = { Text("${seat.districtNameBn} জেলা এডমিন বরখাস্ত", color = BSNRedAlert, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("এডমিন: ${seat.adminName}", fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = suspendReason,
                        onValueChange = { suspendReason = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("বরখাস্তের সুনির্দিষ্ট কারণ লিখুন (বাধ্যতামূলক)...") },
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (suspendReason.isNotBlank()) {
                            scope.launch {
                                firestore.collection("district_admin_seats")
                                    .document(seat.districtId)
                                    .update(
                                        mapOf(
                                            "status" to "Suspended",
                                            "suspensionReason" to suspendReason
                                        )
                                    ).await()

                                firestore.collection("audit_logs").document(UUID.randomUUID().toString()).set(
                                    AuditLogEntry(
                                        id = UUID.randomUUID().toString(),
                                        action = "DISTRICT_ADMIN_SUSPENDED",
                                        details = "${seat.districtNameBn} জেলা এডমিন ${seat.adminName} কে সাময়িক বরখাস্ত করা হয়েছে। কারণ: $suspendReason"
                                    )
                                ).await()

                                Toast.makeText(context, "এডমিন বরখাস্ত কার্যকর করা হয়েছে", Toast.LENGTH_SHORT).show()
                                seatToSuspend = null
                            }
                        }
                    },
                    enabled = suspendReason.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert)
                ) {
                    Text("বরখাস্ত করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { seatToSuspend = null }) { Text("বাতিল") }
            }
        )
    }

    // Vacate Admin Dialog
    seatToVacate?.let { seat ->
        AlertDialog(
            onDismissRequest = { seatToVacate = null },
            title = { Text("${seat.districtNameBn} পদ শূন্য ঘোষণা", fontWeight = FontWeight.Bold) },
            text = { Text("আপনি কি নিশ্চিতভাবে এই জেলা এডমিন পদটি খালি ও শূন্য করতে চান? পূর্ববর্তী এডমিনের ক্ষমতা বাতিল হবে।") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            val previousAdminId = seat.adminId
                            firestore.collection("district_admin_seats")
                                .document(seat.districtId)
                                .update(
                                    mapOf(
                                        "status" to "Vacant",
                                        "adminId" to "",
                                        "adminName" to "",
                                        "adminPhone" to "",
                                        "adminEmail" to "",
                                        "suspensionReason" to ""
                                    )
                                ).await()

                            if (previousAdminId.isNotBlank()) {
                                firestore.collection("members")
                                    .document(previousAdminId)
                                    .update(
                                        mapOf(
                                            "isAdmin" to false,
                                            "role" to "সদস্য",
                                            "assignedDistrictSeat" to 0
                                        )
                                    ).await()
                            }

                            firestore.collection("audit_logs").document(UUID.randomUUID().toString()).set(
                                AuditLogEntry(
                                    id = UUID.randomUUID().toString(),
                                    action = "DISTRICT_ADMIN_SEAT_VACATED",
                                    details = "${seat.districtNameBn} জেলা এডমিন পদ শূন্য ঘোষণা করা হয়েছে।"
                                )
                            ).await()

                            Toast.makeText(context, "${seat.districtNameBn} পদ শূন্য করা হয়েছে", Toast.LENGTH_SHORT).show()
                            seatToVacate = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert)
                ) {
                    Text("পদ খালি করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { seatToVacate = null }) { Text("বাতিল") }
            }
        )
    }

    // Member Cancel Dialog
    memberToCancel?.let { member ->
        AlertDialog(
            onDismissRequest = { memberToCancel = null },
            title = { Text("সদস্যপদ বাতিল বা স্থগিত", color = BSNRedAlert, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("সদস্য: ${member.fullName} (${member.phone})", fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = cancelReason,
                        onValueChange = { cancelReason = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("বাতিল বা স্থগিতের কারণ লিখুন (বাধ্যতামূলক)...") },
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (cancelReason.isNotBlank()) {
                            scope.launch {
                                firestore.collection("members")
                                    .document(member.id)
                                    .update(
                                        mapOf(
                                            "membershipStatus" to "Revoked",
                                            "cancellationReason" to cancelReason
                                        )
                                    ).await()

                                firestore.collection("audit_logs").document(UUID.randomUUID().toString()).set(
                                    AuditLogEntry(
                                        id = UUID.randomUUID().toString(),
                                        action = "MEMBER_REVOKED",
                                        details = "সদস্য ${member.fullName} (${member.phone}) এর সদস্যপদ বাতিল করা হয়েছে। কারণ: $cancelReason"
                                    )
                                ).await()

                                Toast.makeText(context, "সদস্যপদ বাতিল করা হয়েছে", Toast.LENGTH_SHORT).show()
                                memberToCancel = null
                            }
                        }
                    },
                    enabled = cancelReason.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = BSNRedAlert)
                ) {
                    Text("সদস্যপদ বাতিল করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { memberToCancel = null }) { Text("বাতিল") }
            }
        )
    }
}
