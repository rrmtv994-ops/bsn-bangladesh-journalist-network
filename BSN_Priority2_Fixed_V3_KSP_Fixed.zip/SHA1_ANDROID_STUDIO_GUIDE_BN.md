# Android Studio থেকে SHA-1 বের করার সহজ নিয়ম

এই নিয়মে BSN Android project-এর **debug SHA-1** দেখা যাবে। Google Sign-In / Firebase-এ যে অ্যাপটি ব্যবহার করবেন, সেই অ্যাপের সঠিক Gradle project খুলে কাজ করুন।

## পদ্ধতি ১: Android Studio-এর Gradle প্যানেল থেকে

1. Android Studio চালু করুন।
2. **File → Open** থেকে BSN project-এর মূল folder খুলুন—যে folder-এ `settings.gradle.kts` আছে।
3. ডান পাশে **Gradle** প্যানেল খুলুন। না দেখালে **View → Tool Windows → Gradle** নির্বাচন করুন।
4. Gradle প্যানেলে project-এর নামের পাশের তীর (▶/▼) চাপুন।
5. **Tasks → android → signingReport** খুঁজে বের করুন। এই প্রজেক্টে `app` (User App) এবং `admin` (Main Admin App)—দুই module-এর জন্য আলাদা signing report থাকতে পারে।
6. যে অ্যাপের SHA-1 দরকার, সেই module-এর `signingReport`-এ ডাবল-ক্লিক করুন।
7. নিচের **Run** বা **Build Output** উইন্ডোতে রিপোর্ট আসবে।
8. রিপোর্টে `Variant: debug` অংশটি খুঁজুন। তার নিচে `SHA1:` লেখা লাইনের অক্ষর-সংখ্যার মানটি কপি করুন।
9. একই রিপোর্টে `Variant: release` থাকলে সেটির SHA-1 আলাদা। আপনি যে build ব্যবহার করছেন, সেই variant-এর SHA-1 নেবেন।

## পদ্ধতি ২: Gradle টার্মিনাল দিয়ে (প্যানেলে Task না পেলে)

1. Android Studio-তে project খুলুন।
2. নিচের **Terminal** ট্যাব খুলুন।
3. Windows হলে লিখুন:

   ```powershell
   .\gradlew signingReport
   ```

   macOS/Linux হলে লিখুন:

   ```bash
   ./gradlew signingReport
   ```

4. Enter চাপুন। রিপোর্টে `Variant: debug` এবং তার `SHA1:` লাইন দেখুন।

## SHA-1 কোথায় ব্যবহার করবেন

- Firebase Console → Project settings → Your apps → সংশ্লিষ্ট Android app → **Add fingerprint**-এ SHA-1 যোগ করুন।
- BSN User App এবং BSN Main Admin App-এর Android package আলাদা; তাই যে অ্যাপের SHA-1 দরকার, তার সংশ্লিষ্ট Android app-এ fingerprint যোগ করুন।
- Google Sign-In OAuth সেটআপে প্রয়োজন হলে সংশ্লিষ্ট Android OAuth client-এর জন্যও একই package name ও SHA-1 ব্যবহার করুন।
- Debug ও release signing key আলাদা হতে পারে। Play Store-এ প্রকাশের জন্য release/upload বা Play App Signing certificate-এর SHA-1-ও প্রয়োজন হতে পারে।

**মনে রাখবেন:** SHA-1 কোনো পাসওয়ার্ড নয়। তবে আপনার `.jks` keystore ফাইল এবং তার password/alias গোপন রাখবেন; কাউকে পাঠাবেন না।
